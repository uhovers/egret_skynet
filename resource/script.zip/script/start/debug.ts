class Debug {
    constructor() {
        
    }
    log(str: string){
        cc.log("debug: ",str);
    }
}

export default new Debug();