import g from "../g";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Tips extends cc.Component {

    @property(cc.Node)
    private box: cc.Node = undefined;

    @property(cc.Label)
    private tipLb: cc.Label = undefined;
    
    showTip(info: string){
        this.box.stopAllActions();
        this.box.scaleY = 0;

        this.node.active = true;
        this.tipLb.node.active = true;

        // let lang = i18n.languages[g.language];
        // if (lang[info]) {
            this.tipLb.node.getComponent(LocalizedLabel).dataID = info;
        // } else {
            // this.tipLb.string = info;
        // }

        this.box.runAction(cc.sequence(cc.scaleTo(0.1, 1, 1), cc.delayTime(2), cc.callFunc(() => {
            this.node.active = false;
            this.box.scaleY = 0;
        })))
    }

}
