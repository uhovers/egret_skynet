window._i18n = require("LanguageData");
window.LocalizedLabel = require("LocalizedLabel");

if (!window.i18n) window.i18n = {};

if (!window.i18n.languages) window.i18n.languages = {};

let lKey = [
    "en_us",
    "ko_kr",
    "zh_cn",
];

class Languages {
    constructor() {
    }

    /**
     * 加载当前语言
     * @param txt 
     */
    loadLanguageTxt(txt: string) {
        // console.log('key : ', txt);
        return new Promise(resolve => {
            cc.loader.loadRes("Language/"+txt, (err, con) => {
                if (err) {
                    console.error(err);
                    resolve();
                    return
                }
                // console.log('111111', con.text);
                i18n.languages[txt] = JSON.parse(con.text);
                // console.log(window.i18n.languages[txt]);
                // setTimeout(() => {
                    resolve();
                // }, 100);
            });
        });
    }
}

export default new Languages()