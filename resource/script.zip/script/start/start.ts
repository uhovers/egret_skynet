import NetProxy from "../common/net/NetProxy";
import GameData from "../common/net/GameData";
import g, { LoginConfig } from "../g";
import { showLoading, showTip, hideLoading, showConfirm } from "../common/ui";
import { fitCanvas, GetRequest, getUrlData } from "../common/util";
import languages from "./languages";
import { numToBigNum } from "../common/Helper";
import { SupportLang } from "../common/cfg";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Start extends cc.Component {

    @property(cc.Node)
    canvas: cc.Node = undefined;

    @property(cc.Label)
    progressLb: cc.Label = undefined;

    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = undefined;

    @property(cc.Label)
    lbVersion: cc.Label = undefined;

    @property(cc.Node)
    launch: cc.Node = undefined;

    @property(cc.Node)
    login: cc.Node = undefined;

    @property(cc.Label)
    money: cc.Label = undefined;

    @property(cc.Node)
    backBtn: cc.Node = undefined;

    login_ip = '';

    onLoad(){
        console.log('BrowserInfo: ', navigator.userAgent, window.location.protocol);
        console.log('屏幕方向：', window.settings_orientation);
        
        if (window.settings_orientation) {
            g.isLandscape = window.settings_orientation === 'landscape'
        }else{
            g.isLandscape = cc.winSize.width > cc.winSize.height;
        }
        cc.log('当前是否横屏：', g.isLandscape);
        g.setScene();

        fitCanvas(this.canvas);

        this.lbVersion.string = g.hotVer;

        let url = window.location.href;
        console.log('url: ', url);
        let cfg = <LoginConfig>GetRequest(url);
        cc.log('获得cfg: ', cfg);

        g.thirdConfig = <LoginConfig>cfg;
        if (g.thirdConfig && g.thirdConfig.channelId) {
            g.thirdConfig.channelId = +g.thirdConfig.channelId;
        }
        if (g.thirdConfig && g.thirdConfig.subchannelId) {
            g.thirdConfig.subchannelId = +g.thirdConfig.subchannelId
        }
        if (g.thirdConfig && g.thirdConfig.isSingleGame) {
            g.thirdConfig.isSingleGame = +g.thirdConfig.isSingleGame
        }
        cc.log('解析cfg: ', g.thirdConfig);

        // 钱包
        let wallet: string[] = [];
        if (g.thirdConfig && g.thirdConfig.wallet) {
            wallet = g.thirdConfig.wallet.split(',');
        }
        let commonMoney = +wallet[0] || 0
        let eMoney = +wallet[2] || 0
        this.money.string = numToBigNum(commonMoney + eMoney)

        // 语言
        if (g.thirdConfig && g.thirdConfig.lang) {
            let isSupport = !!SupportLang[g.thirdConfig.lang]
            g.language = isSupport ? g.thirdConfig.lang : (g.thirdConfig.lang=='zh_tw' || g.thirdConfig.lang=='zh_hk' ? 'zh_cn' : g.defaultLang);
        }

        this.backBtn.active = !g.thirdConfig || !g.thirdConfig.isSingleGame;
        this.backBtn.parent.zIndex = 2000;
        this.progressBar.progress = 0;
        this.progressLb.string = ""
    }

    async start(){
        await languages.loadLanguageTxt(g.language);
        _i18n.init(g.language);

        if (!g.thirdConfig || g.thirdConfig.channelId==NaN || g.thirdConfig.subchannelId==NaN || !g.thirdConfig.userId || !g.thirdConfig.token || !g.thirdConfig.wallet) {
            let str: string = i18n.languages[g.language]['g_net_error'] || '';
            let conf = showConfirm({content: str, sure: true});
            conf.sureHandler = () => {
                g.postBackToLobby();
            }
            return;
        }

        NetProxy.init();
        await this.loadLangRes();
        await this.loadRes();
        let ipData = await getUrlData('https://api.ipify.org?format=json');
        console.log(ipData);
        this.login_ip = ipData ? ipData.ip : null
        
        //异常捕捉
        GameData.errorCatch()
        
        let str = i18n.languages[g.language]['g_loading_res'] || '';
        this.progressLb.string = str;

        cc.tween(this.launch)
        .delay(0.5)
        .to(0.5, {opacity: 0})
        .call(() =>{
            this.launch.active = false;
            this.login.active = true;
            this.login.opacity = 0;
            cc.tween(this.login)
            .to(0.5, {opacity: 255})
            .call(() => {
                this.onClickStart();
            })
            .start();
        })
        .start();
    }

    loadLangRes(){
        return new Promise(resolve => {
            cc.resources.loadDir(`font/${g.language}/`, resolve);
        });
    }

    update(){
        _i18n.updateSceneRenderers()
    }

    loginReq(){
        // GameData.tbThirdPartInfo.strUID = g.udid;
        GameData.tbThirdPartInfo.uidtype = 1;
        return new Promise( (resolve: (code:number) => void) => {
            NetProxy.LoginReq(this.login_ip, (data: GameMsg.LoginRes)=>{
                if (data.errcode==null) {
                    let tbGameSer = data.gatesvrs;
                    GameData.tbGameSer = [];
                    tbGameSer.forEach( ser => {
                        cc.log(ser.ip, ser.port);
                        let tbGS = {strIP: ser.ip, iPort: ser.port};
                        GameData.tbGameSer.push(tbGS);
                    });
    
                    GameData.tbThirdPartInfo.uidtype = data.uidtype
                    //保存游戏基本数据
                    GameData.strUID = data.uid;
                    GameData.strRID = data.rid;
                    GameData.strLoginToken = data.logintoken;
                    GameData.iTokenExpTime = data.expiretime;
                    resolve(200);
                } else {
                    // showTip(data.errcodedes);
                    resolve(500);
                }
            });
        });
    }

    enterGameReq() {
        return new Promise<GameMsg.EnterGameRes>( resolve => {
            NetProxy.closeSocket()
            //连接游戏服务器
            NetProxy.initSocket(GameData.tbGameSer[0].strIP, ''+GameData.tbGameSer[0].iPort)
            //等待连接游戏服标志
            NetProxy.EnterGameReq( data => {
                resolve(data);
            });
        });
    }

    reEnterTable(roomId: string, roomAddress: number){
        let params = {roomsvr_id: roomId, roomsvr_table_address: roomAddress};
        NetProxy.ReenterTableReq(params, (data: GameMsg.ReenterTableRes) => {
            if (data.errcode===null) {
                NetProxy.stopReceiveMsg();
                GameData.gameInfo = data.gameinfo;
                GameData.reEnterFlag = true;
                g.postEnterRoom();
                cc.director.loadScene(g.GAME_SCENE, () => {hideLoading();});
            } else if(data.errcode===17){
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => {hideLoading();});
            } else {
                this.leaveBlackjack();
            }
        });
    }

    async updateRes(){
        let sec = 0.1;
        return new Promise( resolve => {
            NetProxy.init();
            this.progressBar.progress = 0;
            this.progressLb.string = "资源更新"
            let time = 0;
            let interval = setInterval(async () => {
                time += 50*sec;
                // console.log(time);
                if (time>=sec*1000) {
                    clearInterval(interval);
                    // this.progressLb.string = "开始登录"
                    // let code = await this.loginReq()
                    // if (code===200) {
                    //     code = await this.enterGameReq();
                    // }
                    // this.progressLb.string = "登录成功"
                    // if (code===200) resolve();
                    resolve();
                };
                this.progressBar.progress = time / (sec*1000) / 2;
            }, 50*sec);
        });
    }

    async loadRes(){
        let scenes = g.isLandscape ? ['lobby_landscape'] : ['lobby'];
        for (let i = 0; i < scenes.length; i++) {
            await this.preloadScene(scenes[i], scenes.length);
        }
    }

    preloadScene(scene: string, count: number){
        return new Promise( resolve => {
            let str = i18n.languages[g.language]['g_loading_res'] || '';
            this.progressLb.string = str;
            let pro = this.progressBar.progress;
            cc.director.preloadScene(scene, (c, t) => {
                let _pro = c/t/count;
                // cc.log('=== ',pro, _pro);
                this.progressBar.progress = pro + _pro;
            }, (err) => {
                if (err) {
                    console.log(err);
                }
                resolve();
            });
        });
    }

    private async onClickStart() {
        showLoading();
        this.progressLb.string = ""
        let code = await this.loginReq()
        if (code!==200) {
            this.leaveBlackjack();
            return;
        }

        let data = await this.enterGameReq();
        if (data.errcode==null) {
            this.progressLb.string = ""
            GameData.tbBaseInfo = data.baseinfo;
            let roomId = data.roomsvr_id;
            let roomAddress = data.roomsvr_table_address;
            if (roomId && roomId.length>0 && roomAddress>0) {
                this.reEnterTable(roomId, roomAddress);
            } else {
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => {
                    hideLoading();
                });
            }
        } else {
            this.leaveBlackjack();
        }
    }

    leaveBlackjack(){
        NetProxy.isRepeatNtc = true;
        NetProxy.closeSocket();
        let str: string = i18n.languages[g.language]['g_net_error'] || '';
        let conf = showConfirm({content: str, sure: true});
        conf.sureHandler = () => {
            g.postBackToLobby();
        }
    }

    private onClickBack() {
        g.postBackToLobby();
    }

    onDestroy(){
    }
}
