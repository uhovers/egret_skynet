import Debug from "./debug";
import { showConfirm } from "../common/ui";
import g from "../g";
import { SAVEKEY } from "../common/enum";

enum HANDLER_STATUS {
    Failure = 0,
    Newest,
    Do,
}

export class UpdateTool {
    private relativePath: string;
    private updating: boolean;
    private assetsMgr: jsb.AssetsManager;
    private canRetry: boolean;
    systemUpdateVersion: number;

    /** 更新流程结束 */
    overHandler: Function;
    /** 显示版本号 */
    showVer: (ver: string) => void;
    /** 更新信息显示 */
    infoHandler: (info: string) => void;
    /** 更新进度显示 */
    progressHandler: (num: number) => void;

    private _progress = 0;
    get progress(){
        if (isNaN(this._progress)) {
            return 0;
        }
        return this._progress;
    }

    private _valid = true;
    get valid(){
        return this._valid;
    }

    /**
     * 创建UpdateTool
     * @param manifestUrl 更新文件路径
     * @param mainGame 
     * @param autoRetry 自动重试
     */
    constructor(private manifestUrl: string, private mainGame = false, private autoRetry = false) {
        this.relativePath = "game";
        this.hotInit();
    }

    get storagePath() {
        return (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + this.relativePath;
    }

    private hotInit() {
        cc.log("***** hotInit *****");
        this.canRetry = false;
        if (!cc.sys.isNative) {
            cc.log("仅原生APP可热更新");
            return;
        }

        cc.log('Storage path for remote asset : ' + this.storagePath);
        
        // 强更新检测
        // 之前保存在 local Storage 中的版本号，如果没有，则认为是新版本
        let previousVersion = cc.sys.localStorage.getItem('currentSystemVersion');
        if (previousVersion == undefined || previousVersion == "") {
            cc.sys.localStorage.setItem('currentSystemVersion', ""+this.systemUpdateVersion);
            previousVersion = this.systemUpdateVersion;
        }else{
            previousVersion = parseFloat(previousVersion);
        }
        if (previousVersion < this.systemUpdateVersion) {
            cc.sys.localStorage.setItem('currentSystemVersion',this.systemUpdateVersion+"")
            // 热更新的储存路径，如果旧版本中有多个，可能需要记录在列表中，全部清理
            jsb.fileUtils.removeDirectory(this.storagePath+"/");
        }


        // 热更新初始化
        // Init with empty manifest url for testing custom manifest
        this.assetsMgr = new jsb.AssetsManager('', this.storagePath, this.versionCompareHandle.bind(this));
        // Setup the verification callback, but we don't have md5 check function yet, so only print some message
        // Return true if the verification passed, otherwise return false
        this.assetsMgr.setVerifyCallback((path, asset) =>{
            // When asset is compressed, we don't need to check its md5, because zip file have been deleted.
            let compressed = asset.compressed;
            // Retrieve the correct md5 value.
            let expectedMD5 = asset.md5;
            // asset.path is relative path and path is absolute.
            let relativePath = asset.path;
            // The size of asset file, but this value could be absent.
            let size = asset.size;
            if (compressed) {
                // Debug.log("Verification passed : " + relativePath);
                return true;
            }else {
                // Debug.log("Verification passed : " + relativePath + ' (' + expectedMD5 + ')');
                return true;
            }
        });
        
        Debug.log('Hot update is ready, please check or directly update.');
        if (cc.sys.os === cc.sys.OS_ANDROID) {
            // Some Android device may slow down the download process when concurrent tasks is too much.
            // The value may not be accurate, please do more test and find what's most suitable for your game.
            this.assetsMgr.setMaxConcurrentTask(2);
            Debug.log("Max concurrent tasks count have been limited to 2");
        }
        Debug.log("热更新准备好了")
        this.showInfo("热更新准备好了");
    }

    /**
     * 检查是否有热更新资源 undefined:有错误;true:有更新需要更新;false:已经最新.
     * @returns undefined:有错误;true:有更新需要更新;false:已经最新.
     */
    start(){
        cc.log("*****hotCheck");
        if (!cc.sys.isNative) {
            cc.warn("no native, no check");
            return;
        }
        if (this.updating) {
            this.showInfo("正在更新中…");
            Debug.log("** 正在更新中 0 …")
            return;
        }

        this.showInfo("检查版本");
        Debug.log("** 检查版本 1 start")

        if (this.assetsMgr.getState() === jsb.AssetsManager.State.UNINITED) {
            this.showInfo("载入清单文件");
            Debug.log("** 载入清单文件")
            // Resolve md5 url
            let url = this.manifestUrl;
            if (cc.loader.md5Pipe) {
                url = cc.loader.md5Pipe.transformURL(url);
            }
            this.assetsMgr.loadLocalManifest(url);
        }

        let localManifest = this.assetsMgr.getLocalManifest();
        g.hotVer = localManifest.getVersion();
        Debug.log("g.hotVer = " + g.hotVer)
        Debug.log("** 热更新地址 = " + localManifest.getPackageUrl())
        this.showVer(g.hotVer)

        if (!localManifest || !localManifest.isLoaded()) {
            this.showInfo("** 载入清单文件失败了");
            Debug.log("** 载入清单文件失败了")
            return;
        }

        this.assetsMgr.setEventCallback(this.checkHandler.bind(this));
        this.assetsMgr.checkUpdate();

        this.showInfo("检查更新资源");
        Debug.log("** 检查更新资源 2 ready")
    }

    private hotUpdate() {
        cc.log("*****hotUpdate");
        if (this.updating) {
            Debug.log("** 已经在更新中，不能反复更新！（UPDATE）")
            return;
        }
        this.showProgress(0);

        this.showInfo("资源更新中…");
        cc.log("UPDATE START(1)==State: ", this.assetsMgr.getState())

        if (this.assetsMgr.getState() === jsb.AssetsManager.State.UNINITED) {
            // Resolve md5 url
            let url = this.manifestUrl;
            if (cc.loader.md5Pipe) {
                url = cc.loader.md5Pipe.transformURL(url);
            }
            cc.log("url: ", url)
            this.assetsMgr.loadLocalManifest(url);
        }

        this.assetsMgr.setEventCallback(this.updateHandler.bind(this));

        this.assetsMgr.update();
        this.updating = true;
        Debug.log("UPDATE START(2)!!! ready")
    }

    private async hotRetry() {
        cc.log("*****hotRetry");
        if (!cc.sys.isNative) {
            return;
        }
        if (!this.updating) {
            if (this.canRetry) {
                this.showInfo("重试资源更新");
                Debug.log("** 重试资源更新！")
                await this.showRetry();
                this.assetsMgr.downloadFailedAssets();
            } else {
                // 没有发现本地清单文件或下载清单文件失败
                Debug.log("** 更新重试，加载清单错造成。")
            }
        }
    }

    private showRetry() {
        cc.log("show retry");
        if (this.autoRetry) {
            return;
        }
        return new Promise(resolve => {
            let str = `亲，当前网络环境稍差，点击确定重试。\n${g.errorMsg}`;
            let confirm = showConfirm({title: '重试', content: str, sure: true});
            confirm.sureHandler = () => {
                resolve();
            };
        });
    }

    private async checkHandler(event: jsb.EventAssetsManager) {
        cc.log("*****checkHandler");
        let code = event.getEventCode();
        let ret: HANDLER_STATUS;
        Debug.log("** checkHandler code = " + code)
        switch (code) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.showInfo("没有找到本地文件列表");
                Debug.log("** 没有找到本地文件列表")
                ret = HANDLER_STATUS.Failure;
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
                this.showInfo("下载清单文件错。");
                Debug.log("** 下载清单文件错")
                ret = HANDLER_STATUS.Failure;
                break;
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.showInfo("解析清单文件错。");
                Debug.log("** 解析清单文件错")
                ret = HANDLER_STATUS.Failure;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.showInfo("已经是最新版本了。");
                Debug.log("** 已经是最新版本了。")
                ret = HANDLER_STATUS.Newest;
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                this.showInfo("检测到新版本");
                Debug.log("** 检测到新版本")
                ret = HANDLER_STATUS.Do;
                break;
            default:
                Debug.log("** CHECK UPDATE Code(没处理):" + code)
                return;
        }

        Debug.log("** checkCompleted1")
        if (ret !== HANDLER_STATUS.Failure) {
            this.assetsMgr.setEventCallback(null);
        }

        if (ret === HANDLER_STATUS.Failure) {
            await this.showRetry();
            // this.start();
        } else if (ret === HANDLER_STATUS.Newest) {
            this.beginLogin();
        } else if (ret === HANDLER_STATUS.Do) {
            this.hotUpdate();
        }
        Debug.log("** checkCompleted2")
    }

    private updateHandler(event: jsb.EventAssetsManager) {
        // cc.log("*****updateHandler");
        let code = event.getEventCode();
        let ret: HANDLER_STATUS;
        switch (code) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                this.showInfo("没有发现本地清单文件！");
                ret = HANDLER_STATUS.Failure;
                break;
            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                if (event.getPercent())
                    this.showProgress(event.getPercent());
                let msg = event.getMessage();
                if (msg) {
                    setTimeout(() => {
                        Debug.log("Updated Total files: " + event.getTotalFiles() + "  Total size: " + event.getTotalBytes())
                    }, 0);
                }
                return;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                this.showInfo("下载清单文件失败.");
                Debug.log("下载清单文件失败")
                ret = HANDLER_STATUS.Failure;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                this.showInfo("已经最新版本了.");
                Debug.log("** 已经最新版本了")
                ret = HANDLER_STATUS.Newest;
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                this.showInfo("更新完成。");
                Debug.log("** 更新完成" + event.getMessage())
                ret = HANDLER_STATUS.Do;
                this.showProgress(1);
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                this.showInfo("更新失败。");
                Debug.log("** 更新失败 " + event.getMessage())
                this.canRetry = true;
                ret = HANDLER_STATUS.Failure;
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                Debug.log("ERROR_UPDATING " + event.getAssetId() + ", " + event.getMessage())
                g.errorMsg = event.getAssetId() + ", " + event.getMessage();
                return;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                Debug.log( "ERROR_DECOMPRESS " + event.getMessage())
                return;
            default:
                return;
        }

        Debug.log("** updated end1")
        if (ret === HANDLER_STATUS.Failure) {
            Debug.log("** 更新 失败")
            this.updating = false;
            this.hotRetry();
        } else if (ret === HANDLER_STATUS.Newest || (!this.mainGame && ret === HANDLER_STATUS.Do)) {
            this.beginLogin();
        } else if (ret === HANDLER_STATUS.Do) {
            this.assetsMgr.setEventCallback(null);

            if (this.mainGame) {
                this.showInfo("准备重启游戏");
                Debug.log("准备重启游戏")
                // Prepend the manifest's search path
                let searchPaths = jsb.fileUtils.getSearchPaths();
                let newPaths = this.assetsMgr.getLocalManifest().getSearchPaths();
                cc.log(JSON.stringify(newPaths));
                Array.prototype.unshift.apply(searchPaths, newPaths);
                // This value will be retrieved and appended to the default search path during game startup,
                // please refer to samples/js-tests/main.js for detailed usage.
                // !!! Re-add the search paths in main.js is very important, otherwise, new scripts won't take effect.
                cc.sys.localStorage.setItem('HotUpdateSearchPaths', JSON.stringify(searchPaths));
                jsb.fileUtils.setSearchPaths(searchPaths);
                cc.sys.localStorage.setItem(SAVEKEY.hotUpdateTime, (new Date()).getTime().toString());

                cc.audioEngine.stopAll();
                cc.game.restart();
            }
            this.release();
        }
        Debug.log("** updated end2")
    }

    // Setup your own version compare handler, versionA and B is versions in string
    // if the return value greater than 0, versionA is greater than B,
    // if the return value equals 0, versionA equals to B,
    // if the return value smaller than 0, versionA is smaller than B.
    versionCompareHandle(versionA: string, versionB: string) {
        cc.log("JS Custom Version Compare: version A is " + versionA + ', version B is ' + versionB);
        let vA = versionA.split('.');
        let vB = versionB.split('.');
        for (let i = 0; i < vA.length; ++i) {
            let a = parseInt(vA[i]);
            let b = parseInt(vB[i] || '0');
            if (a === b) {
                continue;
            }
            else {
                return a - b;
            }
        }
        if (vB.length > vA.length) {
            return -1;
        }
        else {
            return 0;
        }
    }

    private beginLogin() {
        this.release();
        cc.log("over");
        this.showInfo("更新完成")
        this.showProgress(1);
        if (typeof this.overHandler === "function") {
            this.overHandler();
        }
    }

    private showInfo(info: string) {
        if (typeof this.infoHandler === "function") {
            this.infoHandler(info);
        }
    }

    private showProgress(pro: number) {
        this._progress = pro;
        if (typeof this.progressHandler === "function") {
            this.progressHandler(pro);
        }
    }

    private release() {
        cc.log("*****hotRelease");
        Debug.log("hot release")
        if (!cc.sys.isNative) {
            return;
        }
        this._valid = false;
        this.assetsMgr.setEventCallback(null);
    }
}