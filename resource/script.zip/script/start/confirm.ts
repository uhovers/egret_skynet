import popActionBox from "../g-share/popActionBox";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Confirm extends popActionBox {

    @property(cc.Label)
    private title: cc.Label = undefined;

    @property(cc.Label)
    private lb: cc.Label = undefined;

    @property(cc.Sprite)
    private sp: cc.Sprite = undefined;

    @property(cc.Button)
    private cancel: cc.Button = undefined;

    @property(cc.Button)
    private sure: cc.Button = undefined;

    /**
     * 取消回调
     * @type {Function}
     * @memberof Confirm
     */
    cancelHandler: Function = undefined;

    /**
     * 确定回调
     * @type {Function}
     * @memberof Confirm
     */
    sureHandler: Function = undefined;

    initPosCancel:cc.Vec2 = null;
    initPosOk:cc.Vec2 = null;
    initPosMid:cc.Vec2 = null;

    onLoad() {
        this.initPosCancel = cc.v2(this.cancel.node.position)
        this.initPosOk = cc.v2(this.sure.node.position)
        this.initPosMid = cc.v2((this.initPosOk.x + this.initPosCancel.x) / 2, (this.initPosOk.y + this.initPosCancel.y) / 2)
    }

    showConfirm(data: {title?: string, content: string, icon?: number, cancel?: boolean, sure?: boolean}){
        this.openAnim();
        // this.title.string = '';
        this.lb.node.getComponent(LocalizedLabel).dataID = data.content;
        let buttonNum = 0
        this.cancel.node.active = !!data.cancel;
        if(this.cancel.node.active){
            buttonNum += 1
        }
        this.sure.node.active = !!data.sure;
        if(this.sure.node.active){
            buttonNum += 1
        }
        if(buttonNum==2){
            this.cancel.node.x = this.initPosCancel.x
            this.sure.node.x = this.initPosOk.x
        }else if(buttonNum==1){
            if(this.cancel.node.active){
                this.cancel.node.x = this.initPosMid.x
            } else if (this.sure.node.active) {
                this.sure.node.x = this.initPosMid.x
            }
        }
    }

    private onClickCancel() {
        if (this.cancelHandler) {
            this.cancelHandler();
        }
        this.closeAnim()
    }

    private onClickSure() {
        if (this.sureHandler) {
            this.sureHandler();
        }
        this.closeAnim();
    }

}
