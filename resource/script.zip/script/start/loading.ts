const {ccclass, property} = cc._decorator;

@ccclass
export default class Loading extends cc.Component {

    @property(cc.Node)
    private sp: cc.Node = undefined;

    private initLoading() {
        this.sp.angle = 0;
        this.sp.stopAllActions();
    }

    showLoading(){
        this.initLoading();
        this.node.active = true;
        this.sp.runAction(cc.repeatForever(cc.rotateBy(1, 360)));
    }

    hideLoading(){
        this.initLoading();
        this.node.active = false;
    }
}
