import { toj, loadEffectCfg, fitCanvas } from "../common/util";
import AppEventManager from "../common/AppEventManager";
import { EVENTTYPE } from "../common/enum";
// import { setAppDurationStatistics } from "../common/app";

const {ccclass, property, executionOrder} = cc._decorator;

const FRAME_RATE = 60;

@ccclass
@executionOrder(0)
export default class Main extends cc.Component {

    @property(cc.Prefab)
    loading:cc.Prefab = undefined;

    @property(cc.Prefab)
    tips: cc.Prefab = undefined;

    @property(cc.Prefab)
    confirm: cc.Prefab = undefined;

    private nowtime: number = undefined;

    onLoad () {
        // 声明常驻根节点，该节点不会被在场景切换中被销毁。<br/> 目标节点必须位于为层级的根节点，否则无效。
        cc.game.addPersistRootNode(this.node);
        // 设置游戏帧率
        cc.game.setFrameRate(FRAME_RATE);

        cc.view.setResizeCallback(() => {
            let scene = cc.director.getScene();
            let nodeCanvas: cc.Node = cc.find('Canvas');
            // console.log(nodeCanvas);
            fitCanvas(nodeCanvas);
            scene.getComponentsInChildren(cc.Widget).forEach(wg => {
                wg.updateAlignment();
            });
        });

        this.nowtime = 0;
        cc.game.on(cc.game.EVENT_SHOW, () => {
            let dt = Date.now()-this.nowtime;
            console.error('切到后台的间隔', dt/1000);
            AppEventManager.notifyEvent(EVENTTYPE.EVENT_PLAYER_TEMPLEAVE_BACK, dt/1000);
        });
        cc.game.on(cc.game.EVENT_HIDE, () => {
            this.nowtime = Date.now();
        });

        // Decimal
        let Decimal = window.Decimal;
        Decimal.set({
            precision: 20,
            rounding: Decimal.ROUND_HALF_UP,
            toExpNeg: -7,
            toExpPos: 21
        });

        loadEffectCfg();
    }

    start () {
    }
    
    

}
