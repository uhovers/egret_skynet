import Base from "../../common/Base";
import * as Enum from "../../common/enum";
import AppEventManager from "../../common/AppEventManager";
import GameData from "../../common/net/GameData";
import NetProxy from "../../common/net/NetProxy";
import { showTip, hideLoading, showLoading, showConfirm } from "../../common/ui";
import g from "../../g";

const {ccclass, property} = cc._decorator;

@ccclass
export default class HeartCtrl extends Base {

    start(){
        AppEventManager.addEventHandler(this);
        this.beginHeart();
    }

    onDestroy(){
        AppEventManager.removeEventHandler(this);
        this.unscheduleAllCallbacks();
    }

    onAppEvent(eventType, data) {
        if (eventType === Enum.EVENTTYPE.EVENT_EnterGameRes){
            if (data.errcode == null || data.errcode == 0) {
                this.unscheduleAllCallbacks();
                this.beginHeart();
            }
        }else if (eventType===Enum.EVENTTYPE.EVENT_PLAYER_TEMPLEAVE_BACK) {
            if (NetProxy.isRepeatNtc) {
                return;
            }
            if (data && data>20) {
                this.reconnect(true);
            } else {
                this.reconnect();
            }
        }
    }

    // called every frame
    update(dt) {
        let offTime = GameData.msgUpdate(dt)
        if(offTime>15){
            if (NetProxy.isRepeatNtc) {
                return;
            }
            cc.log('强制重连=====', offTime);
            this.reconnect(true);
        }
    }

    reconnect(isForce = false){
        this.unscheduleAllCallbacks();
        cc.log('=====reconnect===== isNetworkClosed: ', NetProxy.isNetworkClosed());
        if (isForce && NetProxy.isNetworkClosed()) {
            // 强制重连
            NetProxy.closeSocket()
            // //连接游戏服务器
            NetProxy.initSocket(GameData.tbGameSer[0].strIP, ''+GameData.tbGameSer[0].iPort)
        } else {
            NetProxy.reconnectSocket();
        }
        
        //15秒都没有收到消息，就重连一次
        GameData.msgRes()
        //等待连接游戏服标志
        showLoading();
        NetProxy.EnterGameReq((data: GameMsg.EnterGameRes) => {
            //进入游戏
            cc.log("重连游戏===EnterGameReq");
            if ((data.errcode===null || data.errcode === 0) && data.baseinfo != null) {
                GameData.tbBaseInfo = data.baseinfo;
                let roomId = data.roomsvr_id;
                let roomAddress = data.roomsvr_table_address;
                if (roomId && roomId.length>0 && roomAddress>0) {
                    this.reEnterTable(roomId, roomAddress);
                } else {
                    g.postLeaveRoom();
                    cc.director.loadScene(g.LOBBY_SCENE, () => {
                        hideLoading();
                        // showTip('重连游戏成功');
                    });
                }
            }else{
                g.postLeaveRoom();
                cc.director.loadScene(g.START_SCENE, () =>{
                    hideLoading();
                    // showTip('重连游戏失败')
                });
            }
        });
    }

    reEnterTable(roomId: string, roomAddress: number){
        let params = {roomsvr_id: roomId, roomsvr_table_address: roomAddress};
        NetProxy.ReenterTableReq(params, (data: GameMsg.ReenterTableRes) => {
            if (data.errcode===null) {
                NetProxy.stopReceiveMsg();
                GameData.gameInfo = data.gameinfo;
                GameData.reEnterFlag = true;
                g.postEnterRoom();
                cc.director.loadScene(g.GAME_SCENE, () => {
                    hideLoading();
                    // showTip('重连游戏成功');
                });
            } else if(data.errcode===17){
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => {
                    hideLoading();
                    // showTip('重连游戏成功');
                });
            } else {
                hideLoading();
                NetProxy.isRepeatNtc = true;
                NetProxy.closeSocket();
                let str: string = i18n.languages[g.language]['g_net_error'] || '';
                let conf = showConfirm({content: str, sure: true});
                conf.sureHandler = () => {
                    g.postBackToLobby();
                }
            }
        });
    }

    beginHeart() {
        cc.log("心跳准备")
        this.scheduleOnce(this.sendHeart,5)
    }

    sendHeart() {
        NetProxy.HeartReq(function () {
            this.beginHeart();
        }.bind(this))
    }
}
