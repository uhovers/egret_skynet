import AnimPlist from "../g-share/animPlist";
import HjkGame from "./hjkGame";
import { AnimName } from "../common/enum";

const {ccclass, property} = cc._decorator;

@ccclass
export default class HjkHandMgr extends cc.Component {

    @property(AnimPlist)
    animPlist: AnimPlist = undefined;

    @property(cc.Node)
    leftHand: cc.Node = undefined;

    @property(cc.Node)
    rightHand: cc.Node = undefined;

    private leftFrame: cc.SpriteFrame = undefined;
    private rightFrame: cc.SpriteFrame = undefined;
    private rightPos: cc.Vec3 = undefined;

    game: HjkGame;

    onLoad () {
        this.game = cc.find('game').getComponent(HjkGame);
    }

    start () {
        this.leftFrame = this.leftHand.getComponent(cc.Sprite).spriteFrame;
        this.rightFrame = this.rightHand.getComponent(cc.Sprite).spriteFrame;
        this.rightPos = this.rightHand.position;
        this.animPlist.initAnims();
    }

    /**
     * 左手动画
     * @param name 
     */
    playLeftAnim(name: AnimName){
        let anim = this.leftHand.getComponent(cc.Animation);
        let clip = this.getClipByName(name, anim);
        if (!clip) {
            clip = this.animPlist.getAnim(name);
            if (!clip) {
                cc.warn('播放的动画不存在');
                return;
            }
            anim.addClip(clip);
        }
        anim.play(clip.name);
        anim.on('finished', () => {
            this.leftHand.getComponent(cc.Sprite).spriteFrame = this.leftFrame;
            anim.off('finished');
        });
    }

    /**
     * 右手动画（双手动画也用右手播放）
     * @param name 
     */
    playRightAnim(name: AnimName){
        if (name===AnimName.BlackJack_shou8) {
            this.leftHand.active = false;
            this.rightHand.position = cc.v3(0, this.rightPos.y);
        }
        let anim = this.rightHand.getComponent(cc.Animation);
        let clip = this.getClipByName(name, anim);
        if (!clip) {
            clip = this.animPlist.getAnim(name);
            if (!clip) {
                cc.warn('播放的动画不存在');
                return;
            }
            anim.addClip(clip);
        }
        anim.play(clip.name);
        anim.on('finished', () => {
            this.rightHand.getComponent(cc.Sprite).spriteFrame = this.rightFrame;
            this.rightHand.position = this.rightPos;
            this.leftHand.active = true;
            anim.off('finished');
        });
    }

    private getClipByName(name: string, anim: cc.Animation){
        let clips = anim.getClips();
        let clip: cc.AnimationClip = undefined;
        for (let i = 0; i < clips.length; i++) {
            if (clips[i].name===name) {
                clip = clips[i];
                break;
            }
        }
        return clip;
    }

}
