import popActionBox from "../g-share/popActionBox";
import HjkGame from "./hjkGame";

const {ccclass, property} = cc._decorator;

@ccclass
export default class HjkRoad extends popActionBox {

    @property(cc.Node)
    private dContent: cc.Node = undefined;

    @property(cc.Node)
    private pContent: cc.Node = undefined;

    @property(cc.SpriteFrame)
    private bjSpriteFrame: cc.SpriteFrame[] = [];

    private game: HjkGame = undefined;
    private dCConPos: cc.Vec3;
    private pConPos: cc.Vec3;

    onLoad(){
        super.onLoad();
        this.game = cc.find('game').getComponent(HjkGame);
        this.dCConPos = this.dContent.position;
        this.pConPos = this.pContent.position;
    }
    
    initUI(){
        super.start();
        this.dContent.position = this.dCConPos;
        this.showRoad();
    }

    async showRoad(){
        if (!this.node.active) return;
        
        let data = await this.game.hjkEvent.blackjackWayReq();
        if (data.errcode!==null) {
            return;
        }
        let dRoad = data.banker_way_list;
        let pRoad = data.players_way_list;

        this.updateDRoad(dRoad);

        let d :GameMsg.PlayerWayInfo = {obj_seat: 0, player_way_list: dRoad};
        pRoad.unshift(d);
        this.updatePRoad(pRoad);
    }

    updateDRoad(list: string[]){
        this.dContent.children.forEach(n => { n.active = false; });
        let len = Math.ceil(list.length/8);
        if (len>20) {
            this.dContent.getComponent(cc.Layout).resizeMode = cc.Layout.ResizeMode.CONTAINER;
            this.dContent.width = len*23;
        }else{
            this.dContent.getComponent(cc.Layout).resizeMode = cc.Layout.ResizeMode.NONE;
            this.dContent.width = 20*23;
        }
        for (let i = 0; i < list.length; i++) {
            let n: cc.Node;
            if (i<=this.dContent.children.length-1) {
                n = this.dContent.children[i]
            } else {
                n = cc.instantiate(this.dContent.children[0]);
                n.parent = this.dContent;
            }
            n.active = true;
            let sp = n.getChildByName('sp');
            let lb = n.getChildByName('lb');
            if (list[i]==='BJ' || list[i]==='B') {
                sp.active = true;
                sp.getComponent(cc.Sprite).spriteFrame = list[i]==='B' ? this.bjSpriteFrame[1] : this.bjSpriteFrame[0]; 
                lb.active = false;
            } else {
                sp.active = false;
                lb.active = true;
                lb.getComponent(cc.Label).string = list[i];
            }
            if (i===list.length-1) {
                let l = len>20 ? len : 0;
                this.pContent.position = cc.v3(-218.5-l*23, 0);
            }
        }
    }

    updatePRoad(list: GameMsg.PlayerWayInfo[]){
        for (let idx = 0; idx < 8; idx++) {
            let pNode = this.pContent.children[idx];
            pNode.children.forEach(n => { n.active = false;});
        }

        for (let i = 0; i < list.length; i++) {
            let tab = list[i];
            let pNode = this.pContent.children[tab.obj_seat];
            pNode.children.forEach(n => { n.active = false;});
            let pdata = tab.player_way_list;
            pNode.width = pdata.length>18 ? (pdata.length+1)*23 : 19*23;
            this.pContent.width = pNode.width;
            for (let j = 0; j < pdata.length; j++) {
                let n: cc.Node;
                if (j<=pNode.children.length-1) {
                    n = pNode.children[j]
                } else {
                    n = cc.instantiate(pNode.children[0]);
                    n.parent = pNode;
                }
                n.active = true;
                let sp = n.getChildByName('sp');
                let lb = n.getChildByName('lb');
                if (tab.obj_seat===0 && (pdata[j]==='BJ' || pdata[j]==='B')) {
                    sp.active = true;
                    sp.getComponent(cc.Sprite).spriteFrame = pdata[j]==='B' ? this.bjSpriteFrame[1] : this.bjSpriteFrame[0]; 
                    lb.active = false;
                } else {
                    sp.active = false;
                    lb.active = true;
                    lb.getComponent(cc.Label).string = pdata[j].toUpperCase();
                    lb.color = cc.Color.BLACK;
                    if (pdata[j]==='L') {
                        lb.color = cc.Color.RED;
                    } else if (pdata[j]==='W') {
                        lb.color = cc.Color.GREEN;
                    }else if (pdata[j]==='P') {
                        lb.color = cc.Color.ORANGE;
                    }
                }
            }
            let len = pdata.length>18 ? pdata.length-16 : 0;
            this.pContent.position = cc.v3(this.pConPos.x-len*23, this.pConPos.y)
        }
    }

}
