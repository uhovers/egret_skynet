import PlayerMgr from "../g-share/playerMgr";
import HjkPlayer, { PlayerState } from "./hjkPlayer";
import HjkGame from "./hjkGame";

const {ccclass, property} = cc._decorator;

@ccclass
export default class HjkPlayerMgr extends PlayerMgr<HjkPlayer, HjkGame> {

    @property(cc.SpriteFrame)
    pointBgSp: cc.SpriteFrame[] = [];

    @property(cc.Prefab)
    blackjack: cc.Prefab = undefined;

    // 0 输， 1 赢
    @property(cc.Font)
    winlbFont: cc.Font[] = []

    // 多语言0 中文，1 韩文
    @property(cc.Font)
    pointFont: cc.Font[] = []

    @property(cc.SpriteFrame)
    setindexSp: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    seatNormal: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    seatHightlight: cc.SpriteFrame[] = [];

    /**
     *玩家总数
     * @memberof HjkPlayerMgr
     */
    playerSum = 7;

    private plyPosArr: cc.Vec2[] = [];

    setGame(g: HjkGame){
        super.setGame(g);
        this.players.forEach(ply => {
            this.plyPosArr.push(cc.v2(ply.node.position.x, ply.node.position.y));
            ply.initPly();
        });
    }

    updateTablePlys(){
        let plyInfos = this.game.hjkEvent.playerInfos;
        for (let i = 0; i < plyInfos.length; i++) {
            let player = plyInfos[i].player;
            let seat = plyInfos[i].seat;
            let localPos = this.game.hjkEvent.getLocalPos(seat.index);
            // cc.log('localPos: ', localPos)
            let p = this.getPlayerByPos(localPos);
            p.updatePly(player, seat);
            if (p.isDealer) continue;
            if (this.game.hjkEvent.isSitdown) {
                p.setBtnInteractable(false);
                p.updateSeatIcon(false);
            }
        }
    }

    updatePlayersBet(){
        let plyInfos = this.game.hjkEvent.playerInfos;
        for (let i = 0; i < plyInfos.length; i++) {
            let seat = plyInfos[i].seat;
            let localPos = this.game.hjkEvent.getLocalPos(seat.index);
            let p = this.getPlayerByPos(localPos);
            if (seat && seat.betScores_1) {
                p.betnum = seat.betScores_1;
                p.addChipToTable(false, 0);
            }
        }
    }

    updateStart(){
        // cc.error('updateStart')
        this.players.forEach(ply => {
            if (!ply.isDealer && ply.isReady) {
                ply.handCards = [];
                ply.handCards2 = [];
                ply.state = PlayerState.STARTED;
            }
        });
    }

    clearBets(){
        this.players.forEach(ply => {
            if (!ply.isDealer && ply.isReady) {
                ply.betnum = 0;
                ply.betnum1 = 0;
                ply.clearBet()
            }
        });
    }

    /**
     * 自己坐下的动画
     * @param data 
     * @param doAnim 
     */
    sitDownAnim(data: GameMsg.SitdownTableNtc, doAnim=true){
        return new Promise( resolve => {
            let target = 3;
            let idx = data.seatinfo.index-1;
            let posArr = this.rotatePosArr(idx);
            // cc.log('posArr: ', posArr);
            for (let i = 0; i < this.playerSum; i++) {
                let player = this.players[i];
                if (posArr[i].length===0){
                    if (i===this.playerSum-1) {
                        resolve();
                    }
                    continue;
                };
                player.isTurning = true;
                let node = player.node;
                let cnode = cc.instantiate(node);
                cnode.position = node.position;
                cnode.parent = node.parent;
                node.active = false;
                let act = cc.cardinalSplineTo(Math.abs(idx-target)/6, posArr[i], 0)
                cc.tween(cnode)
                .then(act)
                .call(() => {
                    cnode.removeFromParent()
                    node.active = true;
                    player.isTurning = false;
                })
                .call(()=>{
                    if (i===this.playerSum-1) {
                        resolve();
                    }
                })
                .start()
            }
        } );
    }

    /**
     * 玩家坐下刷新
     * @param data 
     */
    sitdownTable(data: GameMsg.SitdownTableNtc){
        let player = data.tableplayerinfo;
        let seat = data.seatinfo;
        let localPos = this.game.hjkEvent.getLocalPos(seat.index);
        cc.log('=====localPos: ', localPos)
        let p = this.getPlayerByPos(localPos);
        p.updatePly(player, seat);
    }

    leaveTable(index: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        p.updatePly(undefined, {index: index});
        if (this.game.hjkEvent.isSitdown) {
            p.setBtnInteractable(false);
            p.updateSeatIcon(false);
        }
    }

    private rotatePosArr(seatIdx: number){
        let target = 3;
        let posArr = [];
        let sum = this.playerSum;
        let count = Math.abs(seatIdx - target);
        count = count > 0 ? count + 1 : count;
        for (let i = 0; i < sum; i++) {
            posArr[i] = [];
            for (let j = 0; j < count; j++) {
                let idx;
                if (seatIdx<target) {   // 顺时针旋转
                    idx = i+j>=sum ? i+j-sum : i+j
                } else {    // 逆时针旋转
                    idx = i-j<0 ? i-j+sum : i-j
                }
                posArr[i][j] = this.plyPosArr[idx];
            }
        }
        return posArr;
    }

    dealCard(seats: GameMsg.card_21[]){
        return new Promise(async resolve => {
            for (let i = 0; i < 2; i++) {
                for (let idx = 0; idx < seats.length; idx++) {
                    let cards = seats[idx];
                    let localPos = this.game.hjkEvent.getLocalPos(cards.obj_seat);
                    let p = this.getPlayerByPos(localPos);
                    if (i===1 && cards.is_reach_yellow_card) {
                        this.game.showYellowCard(true);
                    }
                    this.game.udpateDeal(cards.remain_cards_count);
                    if (cards.obj_seat===8) {   // 庄家发牌
                        p.handCards = [cards.cards[0]]
                        if (i===0) {
                            cc.log('庄家：'+cards.obj_seat + ' 手牌：', p.handCards)
                            for (let dIdx = 0; dIdx < 1; dIdx++) {
                                p.cardsBg.active = true;
                                await p.addCards(dIdx, p.handCards[dIdx]).then(()=>{
                                    if (dIdx===0) {
                                        if (this.isBlackJack(p.handCards)) {
                                            p.showBlackJack();
                                            this.game.hjkAudio.playBlackJack();
                                        } else {
                                            p.showPoint(this.game.calcPoint(p.handCards));
                                        }
                                        // resolve();
                                    }
                                });
                            }
                        }else{
                            resolve();
                        }
                    }else{  // 玩家发牌
                        p.handCards = cards.cards
                        p.cardsBg.active = true;
                        await p.addCards(i, p.handCards[i]).then(()=>{
                            if (i===1) {
                                cc.log('玩家：'+cards.obj_seat + ' 手牌：', p.handCards)
                                if (this.isBlackJack(p.handCards)) {
                                    p.showBlackJack();
                                    this.game.hjkAudio.playBlackJack();
                                } else {
                                    p.showPoint(this.game.calcPoint(p.handCards));
                                }
                            }
                        });
                    }
                }
            }
        });
    }

    private isBlackJack(cards: number[]){
        let isBJ = false;
        if (cards.length===2) {
            let points = this.game.calcPoint(cards);
            if (points[1]===21) {
                isBJ = true;
            }
        }
        return isBJ;
    }

    getPlayerByPos(seat: number){
        return this.players[seat];
    }

    startCountdown(time: number, index?: number){
        if (index!==null) {
            for (let i = 0; i < this.players.length; i++) {
                let ply = this.players[i];
                if (!ply.isDealer) {
                    ply.stopCountdown();
                }
            }
            let localPos = this.game.hjkEvent.getLocalPos(index);
            let p = this.getPlayerByPos(localPos);
            p.stopCountdown();
            p.countDown(time);
        }else{
            for (let i = 0; i < this.players.length; i++) {
                let ply = this.players[i];
                if (!ply.isDealer && !ply.isLooker && !ply.isReady && !ply.isSurrender) {
                    ply.stopCountdown();
                    if (!this.game.isBlackJack(ply.handCards)) {
                        ply.countDown(time);
                    }   
                }
            }
        }
    }

    stopCountdown(index?: number){
        if (index!==null) {
            let localPos = this.game.hjkEvent.getLocalPos(index);
            let p = this.getPlayerByPos(localPos);
            p.stopCountdown();
        }
    }

    // 下注、加倍（bet自己乘以2）
    async betToTable(index: number, bet?: number, doAnim?: boolean, betIdx?: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p) {
            if (bet===null) {
                if (betIdx===0) {
                    p.betnum = p.betnum*2;
                }else{
                    p.betnum1 = p.betnum1*2;
                }
            }else{
                p.betnum = bet;
            }
            this.game.hjkAudio.playChipFly();
            p.addChipToTable(doAnim, betIdx);
        }
    }

    myBeting(beting: boolean, bet?: number){
        let p = this.getPlayerByPos(3);
        if (p) {
            if (beting) {
                p.betnum = p.betnum+bet
                this.game.hjkAudio.playChipFly();
                p.addChipToTable(true, 0, bet);
            } else {
                p.betnum = 0;
                p.clearBet();
            }
        }
    }

    showInsure(index: number, insure: number, score?: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p && insure===1) {
            let insure = score || p.betnum/2
            p.updateInsure(insure);
        }
    }

    async splitCard(index: number, card1: number[], card2: number[], isEnd=false){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p) {
            p.handCards = card1;
            p.handCards2 = card2;
            await p.splitCards(false, isEnd);
            // p.showPoint(this.game.calcPoint(p.handCards), 0, isEnd);
            // p.showPoint(this.game.calcPoint(p.handCards2), 1, isEnd);
        }
    }

    updateEndPoint(index: number, handIdx: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p) {
            let cards = handIdx===0 ? p.handCards : p.handCards2;
            p.showPoint(this.game.calcPoint(cards), handIdx, true);
            p.hideSplitTip(handIdx);
        }
    }

    updatePlayerCoins(index: number, coins: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p && coins!==null) {
            p.updatePlyCoins(coins);
        }
    }

    showSurrender(index: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p) {
            p.showResultSp(1);
        }
    }

    showSplitTip(index: number, handIdx: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p && p.scardsBg) {
            p.showSplitTip(handIdx);
        }
    }

    hideSplitTip(index: number, handIdx: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        let p = this.getPlayerByPos(localPos);
        if (p && p.scardsBg) {
            p.hideSplitTip(handIdx);
        }
    }

    getMyBetnum(){
        let p = this.getPlayerByPos(3);
        if (p) {
            return p.betnum;
        }
        return 0;
    }

    showBetState(isSuccess: boolean){
        let p = this.getPlayerByPos(3);
        if (p) {
            p.showBetingSp(isSuccess);
        }
    }

    setPlyStateReady(index: number){
        let localPos = this.game.hjkEvent.getLocalPos(index);
        if (localPos===3) {
            this.myBeting(false);
        }
        let p = this.getPlayerByPos(localPos);
        if (p) {
            p.setStateReady();
        }
    }

}
