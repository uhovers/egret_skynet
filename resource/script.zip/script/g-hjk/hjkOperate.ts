import g from "../g";
import { ActionType } from "../common/enum";
import HjkGame from "./hjkGame";
import GameData from "../common/net/GameData";
import { loadSprite, nullToZero, toj, tos } from "../common/util";
import { numToBigNum } from "../common/Helper";
import { showTip } from "../common/ui";
import { LangSprite } from "../g-share/resCfg";

const {ccclass, property} = cc._decorator;

let Decimal = window.Decimal;
let decimal = function (val:any) {
    return new Decimal(val);
}

enum ActionName {
    HIT = 'hit',
    STAND = 'stand',
    DOUBLE = 'double',
    SPLIT = 'split',
    SURRENDER = 'surrender',
}

@ccclass
export default class HjkOperate extends cc.Component {
    @property(cc.Node)
    chipMenu: cc.Node = undefined;

    @property(cc.Node)
    operateNode: cc.Node = undefined;

    @property(cc.Node)
    insure: cc.Node = undefined;

    @property(cc.Node)
    surrender: cc.Node = undefined;

    @property(cc.SpriteFrame)
    private chipBgFrame: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    private chipLightFrame: cc.SpriteFrame[] = [];

    private game: HjkGame = undefined;

    addBetnum = 0;

    chipVals = [0.5, 1, 5, 10, 20, 50];

    onLoad () {
        this.game = cc.find('game').getComponent(HjkGame);
    }

    start(){
        this.hideAll();
    }

    init(bets: number[]){
        this.hideAll();
        this.chipVals = bets;
        cc.log('下注筹码： ', this.chipVals);
    }

    /**
     * 玩家总金额
     */
    public get totalMoney() : number {
        return nullToZero(GameData.tbBaseInfo.coins)+nullToZero(GameData.tbBaseInfo.e_wallet);
    }

    hideAll(){
        this.chipMenu.active = false;
        this.operateNode.active = false;
        this.insure.active = false;
        this.surrender.active = false;
    }

    /**
     * 展示操作按钮
     */
    showOperate(actionType: ActionType){
        this.game.hjkAudio.playBtn3();
        this.hideAll();
        this.operateNode.active = true;
        for (const key in ActionName) {
            let name = ActionName[key];
            let btn = this.operateNode.getChildByName(name);
            if (btn) {
                btn.active = !!(actionType & ActionType[key])
            }
            let frame;
            if (name==='split') {
                frame = LangSprite.split_btn1;
                btn.getComponent(cc.Button).interactable = this.totalMoney >= this.game.playerMgr.getMyBetnum();
            } else if(name==='double') {
                frame = LangSprite.double_btn1;
                btn.getComponent(cc.Button).interactable = this.totalMoney >= this.game.playerMgr.getMyBetnum();
            } else if (name=='hit') {
                frame = LangSprite.hit_btn1;
            }else if (name=='stand') {
                frame = LangSprite.stand_btn1;
            }
            if (btn) {
                loadSprite(btn.getChildByName('Background').getComponent(cc.Sprite), frame);
            }
        }
    }

    /**
     * 展示是否购买保险
     */
    showInsure(num: number,time:number){
        this.game.hjkAudio.playBxtk();
        this.hideAll();
        this.insure.active = true;
        let lb = this.insure.getChildByName('layout').getChildByName('lb').getComponent(LocalizedLabel);
        // let desStr = `你想花费${num.toFixed(2)}购买保险吗？`
        let str: string = i18n.languages[g.language]['g_purchase_insurance'] || '';
        let spStr = str.split('*')[0].length>0 ? '\n' : ''
        let desStr = str.replace(/\*/g, spStr+numToBigNum(num));

        lb.dataID = desStr +" " + time;
        lb.unscheduleAllCallbacks();
        lb.schedule(function() {
            time = time -1
            lb.dataID = desStr +" " + time;
        },1)
    }

    /**
     * 是否投降
     */
    showSurrender(){
        this.game.hjkAudio.playBtn3();
        this.hideAll();
        this.surrender.active = true;
        let sp = this.surrender.getChildByName('tx').getChildByName('Background').getComponent(cc.Sprite)
        loadSprite(sp, LangSprite.tx_1);
    }

    /**
     * 展示下注筹码
     */
    showChipMenu(){
        this.game.hjkAudio.playBtn3();
        this.hideAll();
        this.addBetnum = 0;
        this.chipMenu.active = true;
        let chipList = this.chipMenu.getChildByName('chipBtns').children
        for (let i = 0; i < chipList.length; i++) {
            let val = this.chipVals[i];
            let chipBg = chipList[i];
            if (!val) {
                chipBg.active = false;
                continue;
            }
            chipBg.getComponent(cc.Sprite).spriteFrame = val < 100000 ? this.chipBgFrame[0] : this.chipBgFrame[1];
            chipBg.getChildByName('light').active = false;

            let chip = chipBg.getChildByName('chip');
            if (chip) {
                chip.getChildByName('frame').getComponent(cc.Sprite).spriteFrame = this.game.chipMgr.getChipSpByVal(val);
            }else{
                chip = this.game.chipMgr.getChipBtn(val);
                chip.position = cc.v3(0, 0);
                chipBg.addChild(chip, 1, 'chip');
            }

            let handler = new cc.Component.EventHandler();
            handler.target = this.node;
            handler.component = cc.js.getClassName(this);
            handler.handler = "onClickChip";
            handler.customEventData = tos({idx: i, value: val});
            chip.getComponent(cc.Button).clickEvents[0] = handler;
            chip.getComponent(cc.Button).interactable = this.totalMoney>=val;
        }

        this.updateBetBtns();
    }

    private onClickChip(event, customEventData){
        // this.hideAll();
        let obj = <{idx: number, value: number}>toj(customEventData);
        let val = obj.value;
        cc.log(this.addBetnum, val);
        this.game.hjkAudio.playChipBtn();
        let mySeatinfo = this.game.hjkEvent.mySeatInfo

        if (this.addBetnum+val > mySeatinfo.limit_range[1]) {
            let str = i18n.languages[g.language]['g_bet_outlimit'] || '';
            showTip(str)
            return;
        }

        this.addBetnum = this.addBetnum+val;
        this.game.playerMgr.myBeting(true, val)
        let chips = this.chipMenu.getChildByName('chipBtns').children;
        for (let i = 0; i < chips.length; i++) {
            let chipBg = chips[i];
            if (!chipBg.active) {
                continue;
            }

            if (obj.idx === i) {
                chipBg.getChildByName('light').active = true;
                chipBg.getChildByName('light').getComponent(cc.Sprite).spriteFrame = val < 100000 ? this.chipLightFrame[0] : this.chipLightFrame[1];
            } else {
                chipBg.getChildByName('light').active = false
            }
            let chipVal = this.chipVals[i];
            let isTouch = false;
            if (this.addBetnum+chipVal <= this.totalMoney) {
                isTouch = true;
            }
            let chip = chipBg.getChildByName('chip');
            chip.getComponent(cc.Button).interactable = isTouch;
        }

        this.updateBetBtns();
    }

    updateBetBtns(){
        let num = this.addBetnum;

        let btns = this.chipMenu.getChildByName('btns');
        let cancel = btns.getChildByName('cancel');
        cancel.getComponent(cc.Button).interactable = num>0;

        let isTouch = this.game.lastBet && this.game.lastBet+num <= this.totalMoney
        // cc.error(this.game.lastBet+num, this.game.lastBet && this.game.lastBet+num <= this.totalMoney)
        let repeat = btns.getChildByName('repeat');
        repeat.getComponent(cc.Button).interactable = isTouch;

        let sure = btns.getChildByName('sure');
        sure.getComponent(cc.Button).interactable = num>0;
    }

    private onClickBetBtn(event: cc.Event.EventCustom, customEventData){
        let data = customEventData;
        if (data=='1') {    // 取消
            this.game.playerMgr.myBeting(false)
            this.addBetnum = 0;
            this.updateBetBtns();
            let chips = this.chipMenu.getChildByName('chipBtns').children;
            for (let i = 0; i < chips.length; i++) {
                let chipBg = chips[i];
                if (!chipBg.active) {
                    continue;
                }

                let chipVal = this.chipVals[i];
                let chip = chipBg.getChildByName('chip');
                chip.getComponent(cc.Button).interactable = this.totalMoney>=chipVal;
            }
        } else if (data=='2') {     // 重复下注
            let mySeatinfo = this.game.hjkEvent.mySeatInfo
            if (this.addBetnum+this.game.lastBet > mySeatinfo.limit_range[1]) {
                let str = i18n.languages[g.language]['g_bet_outlimit'] || '';
                showTip(str)
                return;
            }
            this.addBetnum = this.addBetnum + this.game.lastBet;
            
            let chips = this.chipMenu.getChildByName('chipBtns').children;
            for (let i = 0; i < chips.length; i++) {
                let chipBg = chips[i];
                if (!chipBg.active) {
                    continue;
                }

                let chipVal = this.chipVals[i];
                let chip = chipBg.getChildByName('chip');
                chip.getComponent(cc.Button).interactable = (this.totalMoney-this.addBetnum) >=chipVal;
            }

            this.game.playerMgr.myBeting(true, this.game.lastBet)
            this.updateBetBtns();
        } else {    // 确认下注
            let mySeatinfo = this.game.hjkEvent.mySeatInfo
            if (this.addBetnum < mySeatinfo.limit_range[0]) {
                let str = i18n.languages[g.language]['g_bet_lowlimit'] || '';
                showTip(str)
                return;
            }
            if (this.addBetnum > mySeatinfo.limit_range[1]) {
                let str = i18n.languages[g.language]['g_bet_outlimit'] || '';
                showTip(str)
                return;
            }
            this.hideAll();
            this.game.gameBet(this.addBetnum)
            this.addBetnum = 0;
        }
    }

    private onClickOperate(event: cc.Event.EventCustom, customEventData){
        let name = event.target.name
        cc.log('onClickOperate: ', name)
        this.game.hjkAudio.playBtn2();
        switch (name) {
            case ActionName.STAND:
                cc.log('停牌')
                this.hideAll();
                this.game.standPoker();
                break;
            case ActionName.HIT:
                cc.log('要牌')
                this.game.hitPoker();
                break;
            case ActionName.SPLIT:
                cc.log('分牌')
                // this.hideAll();
                this.game.splitPoker();
                break;
            case ActionName.DOUBLE:
                cc.log('加倍')
                // this.hideAll();
                this.game.doublePoker();
                break;
            default:
                break;
        }
    }

    private onClickInsure(event, str){
        this.hideAll();
        this.insure.getChildByName('layout').getChildByName('lb').getComponent(cc.Label).unscheduleAllCallbacks();

        this.game.hjkAudio.playBtn2();
        if (str==='0') {    // 不买保险
            this.game.gameInsure(2);
        } else {
            this.game.gameInsure(1);
        }
    }

    private onClickSurrender(event, str) {
        this.hideAll();
        this.game.hjkAudio.playBtn2();
        if (str==='0') {    // 不投降
            this.game.gameSurrender(2);
        } else {
            this.game.gameSurrender(1);
        }
    }
}
