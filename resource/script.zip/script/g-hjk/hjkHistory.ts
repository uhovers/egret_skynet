import { formatTimeStr, tos, toj, nullToZero } from "../common/util";
import { showLoading, showTip } from "../common/ui";
import TableView from "./TableView";
import { numToBigNum } from '../common/Helper';
import NetProxy from "../common/net/NetProxy";
import PokerMgr from "../g-share/pokerMgr";
import { CardsPoint } from "../common/enum";
import g from "../g";

const {ccclass, property} = cc._decorator;

enum LayerTag {
    History = 1,
    HistoryDetail,
    Date,
    SelectDate
}

enum EnumDate {
    YEAR = 1,
    MONTH,
    DAY,
    YEAR2,
    MONTH2,
    DAY2,
}
const sum_upperlimit = 21;

@ccclass
export default class HjkHistory extends cc.Component {

    @property(cc.Node)
    bg1: cc.Node = undefined;

    @property(cc.Label)
    title: cc.Label = undefined;

    @property(cc.Label)
    datelb: cc.Label = undefined;

    @property(cc.ScrollView)
    historyScroll: cc.ScrollView = undefined;

    @property(cc.Node)
    historyContent: cc.Node = undefined;

    @property(cc.ScrollView)
    detailScroll: cc.ScrollView = undefined;

    @property(cc.Node)
    historyItem: cc.Node[] = [];

    @property(cc.SpriteFrame)
    pointSp: cc.SpriteFrame[] = [];

    @property(cc.Node)
    bg2: cc.Node = undefined;

    @property(cc.Label)
    bg2Title: cc.Label = undefined;

    @property(cc.Node)
    dateNode: cc.Node = undefined;

    @property(cc.Node)
    selectNode: cc.Node = undefined;

    @property(cc.ScrollView)
    selScrollView: cc.ScrollView = undefined;

    @property(cc.Node)
    private dateItem: cc.Node = undefined;

    @property(cc.Node)
    private dateBtns: cc.Node[] = [];

    @property(PokerMgr)
    pokerMgr: PokerMgr = undefined;

    private curLayerTag = LayerTag.History;
    private curDate: Date;
    private startDate: number[] = [0, 0, 0];
    private endDate: number[] = [0, 0, 0];
    private _endDate: number[] = [0, 0, 0];
    private pageIdx = 1;
    private historyType = 1;
    private endId = undefined;

    private startTime = undefined;
    private endTime = undefined;

    tableView: TableView = undefined;

    onLoad(){
    }

    init(){
        this.curLayerTag = LayerTag.History;
        let today = i18n.languages[g.language]['history_date_today'] || '';
        this.datelb.getComponent(cc.Label).string = today;
        // this.datelb.node.getComponent(LocalizedLabel).dataID = today;
        this.pageIdx = 1
        this.historyType = 1
        this.getHistoryData(true, undefined, undefined, this.pageIdx);
    }

    async getHistoryData(isRemove: boolean, startTime?: number, endTime?: number, pageIdx?: number, count?: number){
        let data = await this.blackjackHistoryReq(this.historyType, startTime, endTime, pageIdx, count);
        if (!data.errcode===null) {
            return;
        }
        this.endId = data.id;
        this.pageIdx++;
        if (isRemove) {
            this.historyContent.removeAllChildren();
        }
        let summary = this.bg1.getChildByName('summary').getChildByName('lb');
        summary.getChildByName('bet').getComponent(cc.Label).string = numToBigNum(nullToZero(data.total_bet));
        summary.getChildByName('payout').getComponent(cc.Label).string = numToBigNum(nullToZero(data.total_payout));
        summary.getChildByName('win').getComponent(cc.Label).string = numToBigNum(nullToZero(data.total_win));

        this.showHistoryList(data.players_rounds_list, isRemove);
    }

    /**
     * 查询历史记录
     * @param typeId 1今天 2最近7天 3最近30天 4自定义
     * @param startTime 
     * @param endTime 
     */
    blackjackHistoryReq(typeId: number, startTime?: number, endTime?: number, pageIdx?: number, count=50){
        cc.log(pageIdx, count);
        return new Promise<GameMsg.BlackjackHistoryRes>( resolve => {
            NetProxy.BlackjackHistoryReq({type_id: typeId, begin_time: startTime, end_time: endTime, page_index: pageIdx, page_size: count, id: this.endId}, data => {
                resolve(data);
            });
        });
    }

    getMax(arr: number[]){
        let num = arr[0];
        for (let i = 0; i < arr.length; i++) {
            if (arr[i]>num && arr[i]<= sum_upperlimit) {
                num = arr[i]
            }
        }
        return num;
    }
    
    /**
     * 计算点数并返回 return [min, max]
     * @param cards 
     */
    calcPoint(cards: number[]){
        let points: number[][] = [];
        let min = 0, max = 0, score = 0;
        if (cards==null || cards.length===0) {
            return [min, max];
        }
        for (let i = 0; i < cards.length; i++) {
            let p = CardsPoint[cards[i]];
            if (!p) continue;
            if (p instanceof Array) {
                points.push(p);
            }else{
                score += p;
            }
        }
        min = score, max = score;
        for (let i = 0; i < points.length; i++) {
            let A_points = points[i];
            if (sum_upperlimit - max >= A_points[1]) {
                max += A_points[1];
            }else{
                max += A_points[0];
            }
            min += A_points[0];
        }
        // cc.log([min, max])
        return [min, max];
    }

    showHistoryList(data: GameMsg.BlackjackRoundsInfo[], isRemove: boolean){
        this.historyScroll.node.active = true;
        this.detailScroll.node.active = false;

        let list = data;
        for (let i = 0; i < list.length; i++) {
            let tab = list[i];
            let item = cc.instantiate(this.historyItem[0]);
            // item.active = true;
            this.historyContent.addChild(item);
            this.buildItem(tab, item);
        }
        if (isRemove) {
            this.historyScroll.scrollToTop();
        }
        // if (!this.tableView) {
        //     this.tableView.destroy();
        // }
        // this.tableView = new TableView();
        // this.tableView.buildItem = this.buildItem.bind(this);
        // this.tableView.init(list, this.historyScroll, this.historyItem[0], 3, true);
    }

    buildItem(data, item){
        item.active = true;
        item.getChildByName('time').getComponent(cc.Label).string = formatTimeStr('s', data.update_time*1000);
        item.getChildByName('round').getComponent(cc.Label).string = data.round_id;
        item.getChildByName('bet').getComponent(cc.Label).string = numToBigNum(nullToZero(data.bet_num));
        // let winNum = nullToZero(data.win_num) > 0 ? '+'+nullToZero(data.win_num).toFixed(2) : nullToZero(data.win_num).toFixed(2)
        let winNum = nullToZero(data.win_num)
        item.getChildByName('win').getComponent(cc.Label).string = (winNum > 0 ? "+" : "") + numToBigNum(winNum);;
        item.getChildByName('win').color = nullToZero(data.win_num)>0 ? cc.Color.GREEN : cc.Color.RED;

        let handler = new cc.Component.EventHandler();
        handler.target = this.node;
        handler.component = cc.js.getClassName(this);
        handler.handler = "showHistoryDetail";
        handler.customEventData = tos(data);
        item.getComponent(cc.Button).clickEvents[0] = handler;
    }

    scrollViewEvent(scrollview: cc.ScrollView, eventType: cc.ScrollView.EventType, customEventData: string){
        if (scrollview.isScrolling() && eventType === cc.ScrollView.EventType.SCROLL_TO_BOTTOM) {
            cc.log("------滚动到最下方------", this.endId);
            if (!this.endId) {
                return
            }
            if (this.historyType===4) {
                this.getHistoryData( false, this.startTime, this.endTime, this.pageIdx);   
            } else {
                this.getHistoryData( false, undefined, undefined, this.pageIdx); 
            }
        }
    }

    showHistoryDetail(event, data){
        this.curLayerTag = LayerTag.HistoryDetail;
        this.detailScroll.content.removeAllChildren();
        this.historyScroll.node.active = false;
        this.detailScroll.node.active = true;
        let round: GameMsg.BlackjackRoundsInfo = toj(data);
        // cc.log(round);
        let top = this.detailScroll.node.getChildByName('top').getChildByName('lb');
        top.getChildByName('id').getComponent(cc.Label).string = round.round_id;
        top.getChildByName('bet').getComponent(cc.Label).string = numToBigNum(nullToZero(round.bet_num));
        // let winNum = nullToZero(round.win_num) > 0 ? '+'+nullToZero(round.win_num).toFixed(2) : nullToZero(round.win_num).toFixed(2);
        let winNum = nullToZero(round.win_num)
        top.getChildByName('win').getComponent(cc.Label).string = (winNum>0?"+":"") + numToBigNum(winNum);
        top.getChildByName('win').color = nullToZero(round.win_num)>0 ? cc.Color.GREEN : cc.Color.RED;

        top.getChildByName('yue').getComponent(cc.Label).string = numToBigNum(nullToZero(round.coins));
        for (let i = 0; i < round.win_info_list.length; i++) {
            let tab = round.win_info_list[i];
            let n = cc.instantiate(this.historyItem[1]);
            n.active = true;
            n.parent = this.detailScroll.content;
            let n1 = n.getChildByName('n1');
            let n0 = n1.getChildByName('n0');
            let n2 = n.getChildByName('n2');
            let n3 = n.getChildByName('n3');
            n1.active = false;
            n2.active = false;
            n3.active = false;
            if (tab.obj_seat===8) {// 庄家
                let zj = i18n.languages[g.language]['road_player_lb'] || '';
                n0.getChildByName('name').getComponent(LocalizedLabel).dataID = zj;
                n0.getChildByName('winnum').active = false;
                if (tab.cards_1.length>0) {
                    n1.active = true;
                    for (let idx = 0; idx < tab.cards_1.length; idx++) {
                        let c = this.pokerMgr.getPoker(tab.cards_1[idx]);
                        c.scale = 0.7;
                        n1.getChildByName('cards').addChild(c);
                    }
                    let info = n1.getChildByName('info');
                    info.active = true;
                    let pointStr = ''
                    if (this.isBlackJack(tab.cards_1)) {
                        pointStr = 'BlackJack';
                    } else {
                        let point = this.getMax(this.calcPoint(tab.cards_1));
                        pointStr = point>21 ? "Bust" : ''+point;
                        info.getChildByName('r1').getChildByName('pointbg').getComponent(cc.Sprite).spriteFrame = point>21 ? this.pointSp[1] : this.pointSp[0];
                    }
                    info.getChildByName('r1').getChildByName('pointbg').getChildByName('point').getComponent(cc.Label).string = pointStr;

                    info.getChildByName('r1').getChildByName('win').getComponent(cc.Label).string = '';
                    info.getChildByName('r3').active = false;
                    info.getChildByName('r2').active = false;
                }
            }else{
                let str = i18n.languages[g.language]['history_player'] || '';
                n0.getChildByName('name').getComponent(LocalizedLabel).dataID = str + tab.obj_seat;
                n0.getChildByName('winnum').active = true;
                // let winNum = nullToZero(tab.win_num) > 0 ? '+'+nullToZero(tab.win_num).toFixed(2) : nullToZero(tab.win_num).toFixed(2);
                let winNum = nullToZero(tab.win_num)
                n0.getChildByName('winnum').getComponent(cc.Label).string = (winNum > 0 ? "+" : "") + numToBigNum(winNum);
                n0.getChildByName('winnum').color = nullToZero(tab.win_num)>0 ? cc.Color.GREEN : cc.Color.RED;
                if (tab.cards_1.length>0) {
                    n1.active = true;
                    for (let idx = 0; idx < tab.cards_1.length; idx++) {
                        let c = this.pokerMgr.getPoker(tab.cards_1[idx]);
                        c.scale = 0.7;
                        n1.getChildByName('cards').addChild(c);
                    }
                    let info = n1.getChildByName('info');
                    info.active = true;
                    let pointStr = ''
                    //没有分牌才能算黑杰克
                    if (this.isBlackJack(tab.cards_1) && (tab.cards_2.length <= 0)) {
                        pointStr = 'BlackJack';
                    } else {
                        let point = this.getMax(this.calcPoint(tab.cards_1));
                        pointStr = point>21 ? "Bust" : ''+point;
                        info.getChildByName('r1').getChildByName('pointbg').getComponent(cc.Sprite).spriteFrame = point>21 ? this.pointSp[1] : this.pointSp[0];
                    }
                    info.getChildByName('r1').getChildByName('pointbg').getChildByName('point').getComponent(cc.Label).string = pointStr;
                    let res = ''
                    if (tab.victory_1==='0') {
                        // res = '和';
                        res = i18n.languages[g.language]['history_push'] || '';
                    } else if(tab.victory_1==='1') { 
                        // res = '赢';
                        res = i18n.languages[g.language]['history_win'] || '';
                    } else if(tab.victory_1==='-1') {
                        // res = '输'
                        res = i18n.languages[g.language]['history_lose'] || '';
                    } else if (tab.victory_1 === '2') {
                        // res = '投降'
                        res = i18n.languages[g.language]['history_sunderen'] || '';
                    }
                    info.getChildByName('r1').getChildByName('win').getComponent(LocalizedLabel).dataID = res;

                    info.getChildByName('r3').active = true;
                    let tze = i18n.languages[g.language]['history_bet_num'] || '';
                    let double = tab.is_double_bet1 ? `(x2${i18n.languages[g.language]['history_double']})` : '';
                    // 投注额:100（*2加倍）
                    info.getChildByName('r3').getChildByName('betlb').getComponent(LocalizedLabel).dataID = `${tze}：${numToBigNum(parseFloat(nullToZero(tab.bet_num_1).toFixed(2)))}`;
                    info.getChildByName('r3').getChildByName('num').active = !!tab.is_double_bet1;
                    info.getChildByName('r3').getChildByName('num').getComponent(LocalizedLabel).dataID = `${double}`;

                    let winNum1 = nullToZero(tab.hand_win_num_1)
                    let payc = i18n.languages[g.language]['history_payout'] || '';
                    info.getChildByName('r2').active = true;
                    info.getChildByName('r2').getChildByName('result').getComponent(LocalizedLabel).dataID = payc+'：'
                    info.getChildByName('r2').getChildByName('num').getComponent(cc.Label).string = (winNum1 > 0 ? "+" : "") + numToBigNum(winNum1);
                    info.getChildByName('r2').getChildByName('num').color = nullToZero(tab.hand_win_num_1)>0 ? cc.Color.GREEN : cc.Color.RED;
                }
                if (tab.cards_2.length>0) {
                    n2.active = true;
                    for (let idx = 0; idx < tab.cards_2.length; idx++) {
                        let c = this.pokerMgr.getPoker(tab.cards_2[idx]);
                        c.scale = 0.7;
                        n2.getChildByName('cards').addChild(c);
                    }
                    let info = n2.getChildByName('info');
                    let pointStr = ''
                    let point = this.getMax(this.calcPoint(tab.cards_2));
                    pointStr = point>21 ? "Bust" : ''+point;
                    info.getChildByName('r1').getChildByName('pointbg').getComponent(cc.Sprite).spriteFrame = point>21 ? this.pointSp[1] : this.pointSp[0];
 
                    info.getChildByName('r1').getChildByName('pointbg').getChildByName('point').getComponent(cc.Label).string = pointStr;
                    let res = ''
                    if (tab.victory_2==='0') {
                        // res = '和';
                        res = i18n.languages[g.language]['history_push'] || '';
                    } else if(tab.victory_2==='1') { 
                        // res = '赢';
                        res = i18n.languages[g.language]['history_win'] || '';
                    } else if(tab.victory_2==='-1') {
                        // res = '输'
                        res = i18n.languages[g.language]['history_lose'] || '';
                    } else if (tab.victory_2==='2') {
                        // res = '投降'
                        res = i18n.languages[g.language]['history_sunderen'] || '';
                    }
                    info.getChildByName('r1').getChildByName('win').getComponent(LocalizedLabel).dataID = res;

                    info.getChildByName('r3').active = true;
                    let tze = i18n.languages[g.language]['history_bet_num'] || '';
                    let double = tab.is_double_bet2 ? `(*2${i18n.languages[g.language]['history_double']})` : '';
                    // 投注额:100（*2加倍）
                    info.getChildByName('r3').getChildByName('betlb').getComponent(LocalizedLabel).dataID = `${tze}：${numToBigNum(parseFloat(nullToZero(tab.bet_num_2).toFixed(2)))}`;
                    info.getChildByName('r3').getChildByName('num').active = !!tab.is_double_bet2;
                    info.getChildByName('r3').getChildByName('num').getComponent(LocalizedLabel).dataID = `${double}`;

                    let winNum2 = nullToZero(tab.hand_win_num_2)
                    let payc = i18n.languages[g.language]['history_payout'] || '';
                    info.getChildByName('r2').active = true;
                    info.getChildByName('r2').getChildByName('result').getComponent(LocalizedLabel).dataID = payc+'：';
                    info.getChildByName('r2').getChildByName('num').getComponent(cc.Label).string = (winNum2 > 0 ? "+" : "") + numToBigNum(winNum2);;
                    info.getChildByName('r2').getChildByName('num').color = nullToZero(tab.hand_win_num_2)>0 ? cc.Color.GREEN : cc.Color.RED;
                }
                // 保险
                if (tab.bet_insurance_num>0) {
                    n3.active = true;
                    let bxe = i18n.languages[g.language]['history_insure_num'] || '';
                    n3.getChildByName('betlb').getComponent(LocalizedLabel).dataID = `${bxe}：` + numToBigNum(nullToZero(tab.bet_insurance_num));
                    // let bxNum = nullToZero(tab.win_insurance_nums) > 0 ? '+'+nullToZero(tab.win_insurance_nums).toFixed(2) : nullToZero(tab.win_insurance_nums).toFixed(2);
                    let bxNum = nullToZero(tab.win_insurance_nums)
                    let payc = i18n.languages[g.language]['history_payout'] || '';
                    n3.getChildByName('r2').getChildByName('result').getComponent(LocalizedLabel).dataID = payc+'：'
                    n3.getChildByName('r2').getChildByName('num').getComponent(cc.Label).string = (bxNum > 0 ? "+" : "") + numToBigNum(bxNum);
                    n3.getChildByName('r2').getChildByName('num').color = nullToZero(tab.win_insurance_nums)>0 ? cc.Color.GREEN : cc.Color.RED;
                }
            }
        }
    }

    private isBlackJack(cards: number[]){
        let isBJ = false;
        if (cards.length===2) {
            let points = this.calcPoint(cards);
            if (points[1]===21) {
                isBJ = true;
            }
        }
        return isBJ;
    }

    setSelectDate(){
        this.bg2.active = true
        this.dateNode.active = false;
        this.selectNode.active = false;
        if (this.curLayerTag===LayerTag.Date) {
            let str = i18n.languages[g.language]['history_select_date'] || '';
            this.bg2Title.node.getComponent(LocalizedLabel).dataID = str
            this.dateNode.active = true;
            this.curDate = new Date();
            this.startDate = this.getStartDate();
            this.endDate = this.getEndDate();
            this._endDate = this.endDate;
            this.selScrollView.node.active = false;

            let dateArr = this.startDate.concat(this.endDate);
            for (let idx = 0; idx < this.dateBtns.length; idx++) {
                let node = this.dateBtns[idx];
                node.getChildByName('lb').getComponent(cc.Label).string = ''+dateArr[idx]
            }
        } else {
            // this.bg2Title.string = '自定义'
            let str = i18n.languages[g.language]['history_date_custom'] || '';
            this.bg2Title.node.getComponent(LocalizedLabel).dataID = str
            this.selectNode.active = true;
            this.startDate = this.getStartDate();
            this.endDate = this.getEndDate();
        }
    }

    private getStartDate(){
        let date = this.curDate;
        let year = date.getFullYear();
        let month = date.getMonth()+1;
        let day = date.getDate();
        year = month-6 > 0 ? year : year-1;
        month = month-6 > 0 ? month-6 : 12+(month-6);
        return [year, month, day];
    }

    private getEndDate(){
        let date = this.curDate;
        let year = date.getFullYear();
        let month = date.getMonth()+1;
        let day = date.getDate();
        return [year, month, day];
    }

    showCustomDate(type: EnumDate, flag: number){
        let start = 0, end = 0;
        if (type===EnumDate.YEAR || type===EnumDate.YEAR2) {
            start = this.getStartDate()[flag];
            end = this.getEndDate()[flag];
        } else if (type===EnumDate.MONTH) {
            start = 1;
            end = this.endDate[1];
        } else if (type === EnumDate.MONTH2){
            start = this.startDate[1];
            end = this.getEndDate()[1];
        } else if (type===EnumDate.DAY) {
            start = 1;
            end = this.getDays(this.startDate[0], this.startDate[1]);
            if(this.startDate[1]==this.endDate[1]){
                if(this.endDate[2]<end){
                    end = this.endDate[2]
                }
            }
        } else if (type === EnumDate.DAY2){
            start = 1;
            end = this.getDays(this.endDate[0], this.endDate[1]);
            if (this.startDate[1] == this.endDate[1]) {
                if (this.startDate[2] > start) {
                    start = this.startDate[2]
                }
            }
            if(this.endDate[1]==this.getEndDate()[1]){
                end = this.getEndDate()[2]
            }
        }
        
        let count = g.isLandscape ? 5 : 10
        this.selScrollView.node.height = ((end-start)+1)<10 ? ((end-start)+1)*this.dateItem.height : count*this.dateItem.height;
        this.selScrollView.node.active = true;
        let content = this.selScrollView.content;
        content.removeAllChildren();
        for (let i = start; i <= end; i++) {
            let item = cc.instantiate(this.dateItem);
            item.active = true;
            item.parent = content;
            item.getChildByName('lb').getComponent(cc.Label).string = `${i}`

            let handler = new cc.Component.EventHandler();
            handler.target = this.node;
            handler.component = cc.js.getClassName(this);
            handler.handler = "onClickSelectItem";
            handler.customEventData = tos({type: type, date: i});
            item.getComponent(cc.Button).clickEvents[0] = handler;
        }
        //移动到最上面
        this.selScrollView.scrollToTop(0,false);
    }

    private getDays(year:number,month:number) {
        var d = new Date(year, month, 0);
        return d.getDate();
    }

    private onClickCustomDate(event: cc.Event.EventCustom, customdata){
        let type = parseInt(customdata);
        let flag = type>3 ? type-4 : type-1;
        if (this.selScrollView.node.active) {
            this.selScrollView.node.active = false;
            return
        }
        this.selScrollView.node.active = true;
        let pos = this.dateBtns[type-1].position
        this.selScrollView.node.position = cc.v3(pos.x, pos.y-this.dateBtns[type-1].height/2);
        this.showCustomDate(type, flag);
    }

    private onClickSelectDate(event, str) {
        let tag = parseInt(str)
        if (tag===4) {
            this.curLayerTag = LayerTag.SelectDate;
            this.setSelectDate();
        } else {
            // 选择时间查询
            this.curLayerTag = LayerTag.History;
            this.bg2.active = false;
            this.bg1.active = true;
            // let titleStr = ['今天', '最近7天', '最近30天'];
            // this.datelb.string = titleStr[str-1];

            let str1 = i18n.languages[g.language]['history_date_today'] || '';
            let str2 = i18n.languages[g.language]['history_date_lately7'] || '';
            let str3 = i18n.languages[g.language]['history_date_lately30'] || '';
            let titleStr = [str1, str2, str3]
            this.datelb.node.getComponent(LocalizedLabel).dataID = titleStr[str-1];
            this.pageIdx = 1;
            this.historyType = +str;
            this.getHistoryData(true, undefined, undefined, this.pageIdx)
        }
    }

    private onClickSelectItem(event, str) {
        // cc.log('startDate: ',this.startDate);
        // cc.log('endDate: ',this.endDate);
        // cc.log('_endDate: ',this._endDate);
        let obj: {type: EnumDate, date: number} = toj(str);
        this.selScrollView.node.active = false;
        if (obj.type<=3) {
            this.startDate[obj.type-1] = obj.date;
        } else {
            this.endDate[obj.type-4] = obj.date;
        }
        this.dateBtns[obj.type-1].getChildByName('lb').getComponent(cc.Label).string = ''+obj.date;
        //修正当月的最大天数
        if(obj.type==EnumDate.MONTH){
            if(this.startDate[0]==this.endDate[0] && this.startDate[1]==this.endDate[1]){
                let day = this.startDate[2]>this.endDate[2] ? this.endDate[2] : this.startDate[2]
                this.dateBtns[EnumDate.DAY - 1].getChildByName('lb').getComponent(cc.Label).string = '' + day;
                this.startDate[2] = day;
            }

            let dayCount = this.getDays(this.startDate[0], this.startDate[1])
            if(this.startDate[0]==this._endDate[0] && this.startDate[1]==this._endDate[1]){
                dayCount = this._endDate[2];
            }
            if (this.startDate[2] > dayCount){
                this.startDate[2] = dayCount;
                this.dateBtns[EnumDate.DAY - 1].getChildByName('lb').getComponent(cc.Label).string = '' + dayCount;
            }
        } else if (obj.type == EnumDate.MONTH2){
            if(this.startDate[0]==this.endDate[0] && this.startDate[1]==this.endDate[1]){
                let day = this.startDate[2]>this.endDate[2] ? this.endDate[2] : this.startDate[2]
                this.dateBtns[EnumDate.DAY - 1].getChildByName('lb').getComponent(cc.Label).string = '' + day;
                this.startDate[2] = day;
            }

            let dayCount = this.getDays(this.endDate[0], this.endDate[1])
            if(this.endDate[0]==this._endDate[0] && this.endDate[1]==this._endDate[1]){
                dayCount = this._endDate[2];
            }
            if (this.endDate[2] > dayCount) {
                this.endDate[2] = dayCount;
                this.dateBtns[EnumDate.DAY2 - 1].getChildByName('lb').getComponent(cc.Label).string = '' + dayCount;
            }
        }
        // cc.log('11startDate: ',this.startDate);
        // cc.log('11endDate: ',this.endDate);
    }

    private onClickDateSure() {
        cc.log('startDate: ', this.startDate);
        cc.log('endDate: ', this.endDate)
        let start = new Date(this.startDate[0], this.startDate[1]-1, this.startDate[2]).valueOf();
        let end = new Date(this.endDate[0], this.endDate[1]-1, this.endDate[2], 23, 59, 59).valueOf();
        cc.log(start, end);
        if (end-start<0) {
            return
        }
        this.curLayerTag = LayerTag.History;
        this.bg2.active = false;
        this.bg1.active = true;
        this.datelb.string = `${this.startDate[0]}/${this.startDate[1]}/${this.startDate[2]}--${this.endDate[0]}/${this.endDate[1]}/${this.endDate[2]}`;
        this.pageIdx = 1;
        this.historyType = 4;
        this.startTime = start/1000;
        this.endTime = end/1000;
        this.getHistoryData(true, start/1000, end/1000, this.pageIdx);
    }

    private onClickDate() {
        this.curLayerTag = LayerTag.Date;
        this.bg1.active = false;
        this.setSelectDate();
    }

    private onClickBack(){
        cc.log('==== ', this.curLayerTag);
        if (this.curLayerTag===LayerTag.History) {
            this.node.active = false;
        }else if(this.curLayerTag===LayerTag.HistoryDetail) {
            this.curLayerTag = LayerTag.History;
            this.detailScroll.node.active = false;
            this.historyScroll.node.active = true;
        } else if(this.curLayerTag===LayerTag.Date) {
            this.curLayerTag = LayerTag.History;
            this.bg2.active = false;
            this.bg1.active = true;
        }else{
            this.curLayerTag = LayerTag.Date;
            this.setSelectDate();
        }
    }
}
