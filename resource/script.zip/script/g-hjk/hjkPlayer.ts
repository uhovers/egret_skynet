import Player from "../g-share/player";
import HjkGame from "./hjkGame";
import PokerCard from "../g-share/pokerCard";
import Ticker from "../g-share/ticker";
import { loadSprite, nullToZero, transMoney } from "../common/util";
import { numToBigNum } from "../common/Helper";
import g from "../g";
import { LangSprite } from "../g-share/resCfg";

export enum PlayerState {
    /**未准备 */
    UNREADY,
    /**已准备 */
    READY,
    //开始了
    STARTED,
    //开始下注
    BETTING,
    //投降了
    SURRENDER,
    //结算了
    RESULT,
    //end了
    END,
    //断线了
    OFFLINE
}
const cardY = g.isLandscape ? -60 : -55;
const {ccclass, property} = cc._decorator;

@ccclass
export default class HjkPlayer extends Player {

    @property(cc.Node)
    seatIcon: cc.Node = undefined;

    @property(cc.Node)
    seatState: cc.Node = undefined;

    @property(cc.Node)
    cardsBg: cc.Node = undefined;

    @property(cc.Node)
    betBg: cc.Node = undefined;

    @property(cc.Node)
    insureBg: cc.Node = undefined;

    @property(cc.Node)
    timeBg: cc.Node = undefined;

    @property(cc.Node)
    winNode: cc.Node = undefined;

    @property(cc.Sprite)
    betingSp: cc.Sprite = undefined;

    @property({type: cc.SpriteFrame, tooltip: '0: 下注成功， 1： 下注失败'})
    betingSpFrame: cc.SpriteFrame[] = []

    scardsBg: cc.Node = undefined;  // 分牌后第二手牌节点
    private sbetBg: cc.Node = undefined;  // 分牌后第二手下注节点
    private cardsBgPos: cc.Vec3 = undefined;
    private betBgPos: cc.Vec3 = undefined;

    handCards: number[] = [];
    handCards2: number[] = [];  // 分牌后的第二手牌

    cards: PokerCard[] = [];
    cards2: PokerCard[] = [];   // 分牌后的第二手牌

    // 发牌位置
    private dealPos = g.isLandscape ? cc.v2(cc.winSize.width-260, cc.winSize.height-100) : cc.v2(cc.winSize.width-94, cc.winSize.height-112);

    isTurning = false;
    state: PlayerState;//玩家状态
    betnum = 0; // 玩家下注额
    betnum1 = 0;
    game: HjkGame;

    // 准备好了
    get isReady() {
        return this.state === PlayerState.READY
    }

    // 旁观者
    get isLooker() {
        return this.state === PlayerState.UNREADY;
    }

    /** 是否投降 */
    get isSurrender() {
        return this.state === PlayerState.SURRENDER;
    }

    initPly(){
        this.setSeatState(false);
        this.cardsBg.active = false;
        this.cardsBg.getChildByName('pointbg').active = false;
        this.cardsBg.getChildByName('pointbg').getChildByName('point').getComponent(cc.Label).string = '';
        this.cardsBg.getChildByName('winIcon').active = false;
        if (this.cardsBg.getChildByName('blackjack')) {
            this.cardsBg.getChildByName('blackjack').active = false;
        }
        if (this.cardsBg.getChildByName('handtip')) {
            this.cardsBg.getChildByName('handtip').active = false;
        }
        if (this.isDealer) {
            loadSprite(this.sAvatar.getComponent(cc.Sprite), LangSprite.banker);
            return;
        }

        loadSprite(this.seatIcon.getChildByName('sitsp').getComponent(cc.Sprite), LangSprite.blackjack_ziti_btn_zuoxia);
        loadSprite(this.insureBg.getChildByName('bxsp').getComponent(cc.Sprite), LangSprite.blackjack_ziti_baoxian);
        this.lSeat.node.active = false;
        this.sAvatar.node.active = true;
        this.seatIcon.active = true;
        this.betBg.active = false;
        this.insureBg.active = false;
        this.timeBg.active = false;
        this.lName.string = '';
        this.lMoney.node.parent.active = false;
        this.setBtnInteractable(true);
        this.state = PlayerState.UNREADY;
        this.betnum = 0;
        this.betnum1 = 0;
        this.winNode.active = false;
        if (this.betingSp) {
            this.betingSp.node.active = false;
        }

        if (!this.cardsBgPos) {
            this.cardsBgPos = this.cardsBg.position;
            this.betBgPos = this.betBg.position;
        }
    }

    private reset(){
        this.betBg.getChildByName('betlb').getComponent(cc.Label).string = '';
        this.cardsBg.position = this.cardsBgPos;
        this.betBg.position = this.betBgPos;
        this.winNode.active = false;
        if (this.betingSp) {
            this.betingSp.node.active = false;
        }
        this.betnum = 0;
        this.betnum1 = 0;
        this.insureBg.active = false;
        if (this.scardsBg) {
            this.scardsBg.destroy()
            this.scardsBg = undefined;
        }
        if (this.sbetBg) {
            this.sbetBg.destroy();
            this.sbetBg = undefined;
        }
    }

    updatePly(plyInfo?: GameMsg.TablePlayerInfo, seatInfo?: GameMsg.SeatInfo){
        this.setSeatState(false);
        if (this.cardsBg.getChildByName('blackjack')) {
            this.cardsBg.getChildByName('blackjack').active = false;
        }
        this.cardsBg.getChildByName('pointbg').active = false;
        this.cardsBg.getChildByName('pointbg').getChildByName('point').getComponent(cc.Label).string = '';
        this.cardsBg.getChildByName('winIcon').active = false;
        if (this.cardsBg.getChildByName('handtip')) {
            this.cardsBg.getChildByName('handtip').active = false;
        }
        let cardArr = [this.cards, this.cards2];
        for (let i = 0; i < cardArr.length; i++) {
            for (let j = 0; j < cardArr[i].length; j++) {
                this.removeHandCard(j, i)
            }
        }
        this.cardsBg.active = false;
        this.cards = [];
        this.cards2 = [];

        if (this.isDealer) return;

        this.reset();
        this.pos = seatInfo.index;
        this.lSeat.string = ''+seatInfo.index;
        this.sAvatar.spriteFrame = this.game.playerMgr.setindexSp[this.pos-1];
        if (plyInfo && plyInfo.rid) {
            this.setBtnInteractable(false);
            this.lSeat.node.active = false;
            this.sAvatar.node.active = true;
            this.seatIcon.active = false;
            this.betBg.active = false;
            this.insureBg.active = false;
            this.stopCountdown();
            // this.lName.string = g.isDev ? plyInfo.rolename+':'+plyInfo.rid : plyInfo.rolename;
            let str = i18n.languages[g.language]['g_tourist_name'] || '';
            this.lName.string = plyInfo.rolename=='游客' ? str : plyInfo.rolename;
            this.updatePlyCoins(plyInfo.coins);
            this.state = seatInfo.state===19 ? PlayerState.STARTED : PlayerState.READY;
        }else{
            this.initPly();
        }
    }
    
    setStateReady(){
        this.state = PlayerState.READY;
    }

    setStateStart(){
        this.state = PlayerState.STARTED;
    }

    updatePlyCoins(coins: number){
        if (this.isDealer) return;
        this.lMoney.node.parent.active = false;
        // this.lMoney.string = numToBigNum(coins);
    }

    updateSeatIcon(active=false){
        if (this.seatIcon && this.seatIcon.isValid) {
            this.seatIcon.active = active;
        }
    }

    /**
     * 倒计时
     * @param time 
     */
    countDown(time: number){
        this.setSeatState(true);
        if (this.isDealer) return;
        this.timeBg.active = true;
        let ticker = this.timeBg.getComponent(Ticker);
        ticker.show(time, this.game.hjkEvent.isSitdown&&this.seat===3);
        ticker.timeEndHandler = () => {
            this.setSeatState(false);
            // if (this.game.hjkEvent.isSitdown&&this.seat===3 && this.game.hjkOperate.addBetnum>0) {
            //     this.game.gameBet(this.game.hjkOperate.addBetnum);
            //     this.game.hjkOperate.addBetnum = 0;
            // }
            this.game.hjkOperate.hideAll();
            this.hideSplitTip();
        }
    }

    stopCountdown(){
        this.setSeatState(false);
        if (this.isDealer) return;
        let ticker = this.timeBg.getComponent(Ticker);
        ticker.hide();
        ticker.timeEndHandler = undefined;
        this.timeBg.active = false;
    }

    setSeatState(isHight: boolean){
        let idx: number = undefined;
        if (this.seat===3) {
            idx = 0
        } else if (this.seat===7) {
            idx = 2
        } else {   // 其他
            idx = 1
        }
        let sp = isHight ? this.game.playerMgr.seatHightlight[idx] : this.game.playerMgr.seatNormal[idx];
        this.node.getComponent(cc.Sprite).spriteFrame = sp
    }

    addCards(index: number, cardKey: number, doAnim=true, hand=0){
        let c = hand===0 ? this.cards[index] : this.cards2[index]
        if (c) {
            this.removeHandCard(index, hand);
        }
        return this.addCardToHand(index, cardKey, cardKey!==99, doAnim, hand);
    }

    turnCard(index: number, cardKey: number, doAnim=true, hand=0){
        let c = hand===0 ? this.cards[index] : this.cards2[index]
        if (c) {
            let scale =  this.seat===7 ? 0.85 : 0.7;
            this.game.pokerMgr.setPoker(c.node, cardKey);
            return c.turn(true, doAnim, scale);
        }else{
            return this.addCards(index, cardKey, doAnim, hand);
        }
    }

    private removeHandCard(index: number, hand=0) {
        let cards = hand===0 ? this.cards : this.cards2
        let card = cards[index];
        if (!card) {
            cc.warn("试图移除一张不存在的牌");
            return;
        }
        card.node.destroy();
        // cards.splice(index, 1);
        delete cards[index];
    }

    /**
     * 计算牌的 x 位置
     * @param cw 
     * @param hw 
     * @param idx 
     */
    protected getEndX(cw: number, idx: number, count: number) {
        let deltaX = -40;
        let len = count;
        let x = -((len-1)/2 - idx) * (deltaX+cw)
        // cc.log(idx+' ==== x: ', x)
        return 0;
    }

    private getAngle(idx: number, count: number) {
        let deltaAng = 10;
        let len = count;
        let ang = -((len-1)/2 - idx) * deltaAng
        // cc.error(idx+'==== ang: ', ang)
        return ang;
    }

    /**
     * 发牌到玩家
     * @param index 
     * @param cardKey 
     * @param faceUp 
     * @param doAnim 
     */
    private addCardToHand(index: number, cardKey: number, faceUp=true, doAnim=false, handIdx=0){
        return new Promise( (resolve: (card?: PokerCard) => void) => {
            let cardHand = handIdx===0 ? this.cardsBg : this.scardsBg;
            let count = handIdx===0 ? this.handCards.length : this.handCards2.length;
            if (!cardHand) {
                resolve();
                return;
            }
            let card: PokerCard = this.game.pokerMgr.getPoker(cardKey).getComponent(PokerCard);
            let node = card.node;
            if (!node) {
                resolve();
                return;
            }
            card.turn(false, false);
            let cwidth = node.width
            // cc.log('==== ', index, count)
            let handX = this.getEndX(cwidth, index, count);
            let angle = this.getAngle(index, count);
            let zIndex = index;
            // node.anchorY = 0;
            let scale =  this.seat===7 ? 0.85 : 0.7;
            if (doAnim && !this.isTurning) {
                this.game.hjkAudio.playDeal();
                cardHand.addChild(node, zIndex, 'poker')
                let centerPos = cardHand.convertToNodeSpaceAR(this.dealPos);
                node.position = cc.v3(centerPos.x, centerPos.y);
                node.runAction(cc.sequence(
                    cc.moveTo(0.15, handX, cardY),
                    cc.callFunc(() => {
                        node.scale = scale;
                        // resolve(card);
                    }),
                    cc.callFunc(async () => {
                        if (faceUp) {
                            this.game.hjkAudio.playFan();
                            await card.turn(true, true, scale);
                            resolve(card);
                        }
                    }),
                    cc.rotateTo(0.1, angle)
                ));
            } else {
                cardHand.addChild(node, zIndex, 'poker')
                node.position = cc.v3(handX, cardY);
                card.turn(faceUp, false, scale);
                node.angle = -angle;
                // cc.log('没有动画',node)
                resolve(card);
            }
            if (handIdx===0) {
                this.cards[index] = card;
                // cc.log('cards=== ', this.cards);
            } else {
                this.cards2[index] = card;
            }
        });
    }

    updateCardXandAng(handIdx=0){
        return new Promise(resolve => {
            let cards = handIdx===0 ? this.cards : this.cards2;
            if (cards.length===0) resolve();
            
            let count = handIdx===0 ? this.handCards.length : this.handCards2.length;
            for (let i = 0; i < cards.length; i++) {
                let c = cards[i];
                if (!c) continue;
                let x = this.getEndX(c.node.width, i, count);
                let ang = this.getAngle(i, count);
                c.node.position = cc.v3(x, cardY);
                c.node.angle  = -ang;
                if (i===cards.length-1) resolve();
            }
        });
    }

    showPoint(points: number[], handIdx=0, end=false){
        let cardHand = handIdx===0 ? this.cardsBg : this.scardsBg;
        if (!cardHand) return;
        if (this.cardsBg.getChildByName('blackjack')) {
            this.cardsBg.getChildByName('blackjack').active = false;
        }

        let pointbg = cardHand.getChildByName('pointbg');
        cardHand.getChildByName('winIcon').active = false;
        pointbg.active = true;
        pointbg.zIndex = 50;
        let spFrame = this.game.playerMgr.pointBgSp;

        let plb = pointbg.getChildByName('point').getComponent(cc.Label);
        let bfont;
        if (g.language=='ko_kr') {
            bfont = this.game.playerMgr.pointFont[1];
        } else {
            bfont = this.game.playerMgr.pointFont[0];
        }
        plb.font = bfont;

        let sum_upperlimit = 21
        if (points[0]>sum_upperlimit && points[1]>sum_upperlimit) {
            plb.string = "B";
            pointbg.getComponent(cc.Sprite).spriteFrame = spFrame[1];
        }else{
            if (end) {
                let point = this.game.getMax(points);
                cc.log('停牌时刷新点数 point: ', point)
                plb.string = point>sum_upperlimit ? "B" : ''+point;
                pointbg.getComponent(cc.Sprite).spriteFrame = point>sum_upperlimit ? spFrame[1] : spFrame[0];
                return;
            }else{
                pointbg.getComponent(cc.Sprite).spriteFrame = spFrame[0];
                if (points[1] < sum_upperlimit && points[0]!==points[1]) {
                    plb.string = `${points[0]}/${points[1]}`;
                }else if(points[1] === sum_upperlimit) {
                    plb.string = ''+points[1];
                }else{
                    plb.string = ''+points[0];
                }
            }
        }
    }

    showBlackJack(handIdx=0){
        let cardHand = handIdx===0 ? this.cardsBg : this.scardsBg;
        if (!cardHand) return;

        cardHand.getChildByName('pointbg').active = false;
        let bj = cardHand.getChildByName('blackjack');
        if (!bj) {
            bj = cc.instantiate(this.game.playerMgr.blackjack);
            bj.position = cc.v3(0, -25);
            cardHand.addChild(bj, 30, 'blackjack');
        }
        bj.scale = this.seat===7 ? 1.3 : 1;
        bj.active = true;
        bj.getComponent(cc.Animation).play();
    }

    /**
     * 展示输赢结果（投降）
     * @param res 1 投降， 2 赢， 3输
     * @param handIdx 
     */
    showResultSp(res: number, handIdx=0){
        let cardHand = handIdx===0 ? this.cardsBg : this.scardsBg;
        if (!cardHand) return;
        // cardHand.getChildByName('pointbg').active = false;
        this.state = PlayerState.SURRENDER;
        let winIcon = cardHand.getChildByName('winIcon');
        let frame;
        if (res===1) {
            frame = LangSprite.result_surrender;
        } else if(res===2) {
            frame = LangSprite.result_win;
        } else if(res===3) {
            frame = LangSprite.result_lose;
        }
        loadSprite(winIcon.getComponent(cc.Sprite), frame)
        winIcon.active = true;
        winIcon.zIndex = 100;
    }

    /**
     * 停牌回收
     * @param doAnim 
     */
    async discards(doAnim=true){
        this.cardsBg.getChildByName('pointbg').active = false;
        this.cardsBg.getChildByName('pointbg').getChildByName('point').getComponent(cc.Label).string = '';
        this.cardsBg.getChildByName('winIcon').active = false;
        if (this.cardsBg.getChildByName('blackjack')) {
            this.cardsBg.getChildByName('blackjack').active = false;
        }
        if (this.cardsBg.getChildByName('handtip')) {
            this.cardsBg.getChildByName('handtip').active = false;
        }
        if (this.scardsBg && this.scardsBg.getChildByName('handtip')) {
            this.scardsBg.getChildByName('handtip').active = false;
        }
        if (this.scardsBg && this.scardsBg.getChildByName('winIcon')) {
            this.scardsBg.getChildByName('winIcon').active = false;
        }
        if (this.scardsBg && this.scardsBg.getChildByName('pointbg')) {
            this.scardsBg.getChildByName('pointbg').active = false;
        }

        let cardArr = [this.cards, this.cards2];
        // console.log(cardArr);
        let proArr = [];
        for (let i = 0; i < cardArr.length; i++) {
            for (let j = 0; j < cardArr[i].length; j++) {
                const c = cardArr[i][j];
                if (!c) continue;
                // this.discardsAnim(c, j, doAnim, i)
                proArr.push(this.discardsAnim(c, j, doAnim, i))
            }
        }
        await Promise.all(proArr);
        this.cardsBg.active = false;
        this.cards = [];
        this.cards2 = [];
        this.handCards = [];
        this.handCards2 = [];
        if (this.isDealer) return;

        this.betBg.active = false;
        this.reset();
    }

    private discardsAnim(c: PokerCard, index: number, doAnim=true, hand=0) {
        return new Promise<void>(async resolve => {
            let centerPos = this.cardsBg.convertToNodeSpaceAR(this.dealPos);
            centerPos = hand===0 ? centerPos : cc.v2(centerPos.x+70, centerPos.y);
            let scale =  this.seat===7 ? 0.85 : 0.7;
            if (doAnim) {
                await c.discard(doAnim, scale);
                this.game.hjkAudio.playDiscard();
                c.node.runAction(cc.sequence(
                    cc.moveTo(0.2, centerPos),
                    cc.callFunc(() => {
                        this.removeHandCard(index, hand);
                        resolve();
                    })
                ))
            } else {
                this.removeHandCard(index, hand);
                resolve();
            }
        });
    }

    /**
     * 下注
     * @param bet 
     * @param doAnim 
     */
    addChipToTable(doAnim=true, betIdx=0, curBet?: number){
        if (this.isDealer) {
            return;
        }

        let centerPos = this.seat===3 ? cc.v3(0, -100) : cc.v3(0, -100);
        let animT = 0.18;
        let bet = betIdx===0 ? this.betnum : this.betnum1;

        // let spBet = bet;
        let list = this.game.chipMgr.transChips(bet);
        // let list = [200000000, 300000000, 500000000, 20, 50, 100]
        list.sort((a, b)=>{return b-a})
        cc.log(this.lName.string+' ==== list: ', list);
        
        // if (curBet) {
        //     spBet = curBet;
        // }

        let betNode = betIdx===0 ? this.betBg : this.sbetBg;
        betNode.active = true;
        let node = betNode.getChildByName('betchip')
        let betlb = betNode.getChildByName('betlb').getComponent(cc.Label);
        node.removeAllChildren();
        let y = 0
        for (let i = 0; i < list.length; i++) {
            if (i>5) break;
            const element = list[i];
            if (element) {
                let chip = this.game.chipMgr.getSmallChip(element);
                if (element<100000) {
                    if (list[i-1] && list[i-1]>=100000) {
                        y = y + 8;
                    } else {
                        y = y + 6;
                    }
                } else {
                    y = y + 7;
                }
                chip.position = cc.v3(0, y);
                node.addChild(chip, i)
            }
        }

        let pos = node.position;
        node.scale = 0.8
        // let chipNumNode = node.getChildByName('chipNum');

        // let frame = this.game.chipMgr.getChipSpByVal(spBet, true);
        // if (frame) {
        //     node.getComponent(cc.Sprite).spriteFrame = frame;
        //     chipNumNode.getComponent(cc.Label).string = this.transChipNum(spBet);
        // }

        let betStr = transMoney(bet);
        if (doAnim) {
            node.position = cc.v3(centerPos.x, centerPos.y);
            node.runAction(cc.sequence(
                cc.moveTo(animT, pos.x, pos.y),
                cc.callFunc(() => {
                    betlb.string = betStr;
                    // let frame = this.game.chipMgr.getChipSpByVal(bet, true);
                    // if (frame) {
                        // node.getComponent(cc.Sprite).spriteFrame = frame;
                        // chipNumNode.getComponent(cc.Label).string = this.transChipNum(bet);
                    // }
                })
            ));
        } else {
        //     chipNumNode.getComponent(cc.Label).string = this.transChipNum(bet);
            betlb.string = betStr
            node.position = cc.v3(pos.x, pos.y)
        }
    }

    transChipNum(num: number){
        let _num = num.toFixed(2);
        let int_num = _num.split('.')[0];
        let float_num = _num.split('.')[1];
        let result_num = '';
        if (int_num.length <=3 ) {
            result_num = int_num+(float_num=='00'?'':'.'+float_num);
            return result_num;
        }else if (int_num.length === 4) {
            result_num = int_num+(float_num.split('')[0]=='0' ? '' : '.' + float_num.split('')[0]);
            return result_num;
        }else if (int_num.length === 5) {
            result_num = int_num;
            return result_num;
        }else if (int_num.length === 6) {
            let tmp = (Number(int_num)/1000).toFixed(1);
            result_num = (tmp.split('.')[1]=='0' ? tmp.split('.')[0]+'K' : tmp+'K');
            return result_num;
        }else if (int_num.length === 7) {
            let tmp = (Number(int_num)/1000000).toFixed(2);
            result_num = (tmp.split('.')[1]=='00' ? tmp.split('.')[0]+'M' : tmp+'M');
            return result_num;
        }else if (int_num.length === 8) {
            let tmp = (Number(int_num)/1000000).toFixed(1);
            result_num = (tmp.split('.')[1]=='0' ? tmp.split('.')[0]+'M' : tmp+'M');
            return result_num;
        }else {
            result_num = (Number(int_num)/1000000).toFixed(0) + 'M';
            return result_num; 
        }
    }

    clearBet(){
        if (this.isDealer) {
            return;
        }
        let betNode = this.betBg;
        betNode.getChildByName('betchip').removeAllChildren();

        betNode.active = false;
        let betlb = betNode.getChildByName('betlb').getComponent(cc.Label);
        betlb.string = '';
    }

    updateInsure(score: number){
        this.insureBg.active = true;
        let lb = this.insureBg.getChildByName('num').getComponent(cc.Label);
        lb.string = numToBigNum(score);
    }

    async splitCards(isReenter=false, isEnd: boolean){
        this.cards.forEach((c,i) => {
            this.removeHandCard(i);
        })
        this.cardsBg.getChildByName('pointbg').active = false;

        this.scardsBg = cc.instantiate(this.cardsBg);
        this.scardsBg.position = this.cardsBg.position;
        this.scardsBg.parent = this.cardsBg.parent;
        cc.log("开始异步操作")
        if (isReenter) {
            await this.moveSplitCard(false);
            this.splitBet(true);
        } else {
            this.addCards(0, this.handCards[0], false, 0);
            this.addCards(0, this.handCards2[0], false, 1);
            await this.moveSplitCard();
            this.splitBet();

            await this.addCards(1, this.handCards[1], true, 0);

            this.showPoint(this.game.calcPoint(this.handCards), 0, isEnd);

            await this.addCards(1, this.handCards2[1], true, 1);
            this.showPoint(this.game.calcPoint(this.handCards2), 1, isEnd);
        }
        cc.log("异步返回")
    }

    showSplitTip(handIdx=0){
        if (handIdx===0) {
            this.scardsBg.getChildByName('handtip').active = false;
            let tip = this.cardsBg.getChildByName('handtip');
            tip.zIndex = 200;
            tip.active = true;
        }else{
            this.cardsBg.getChildByName('handtip').active = false;
            let tip = this.scardsBg.getChildByName('handtip');
            tip.zIndex = 200;
            tip.active = true;
        }
    }

    hideSplitTip(handIdx=0){
        let cardHand = handIdx===0 ? this.cardsBg : this.scardsBg;
        if (cardHand && cardHand.getChildByName('handtip')) {
            cardHand.getChildByName('handtip').active = false;
        }   
    }

    private moveSplitCard(doAnim=true) {
        let pos = this.cardsBgPos;
        let delta = 50
        return new Promise<void>( resolve => {
            if (doAnim) {
                cc.tween(this.cardsBg).to(0.2, {x: pos.x-delta, y: pos.y}).start();
                this.game.hjkAudio.playChipFly();
                cc.tween(this.scardsBg)
                .to(0.2, {x: pos.x+delta, y: pos.y})
                .call(resolve)
                .start();
                cc.log("0.2秒之后返回")
            } else {
                this.cardsBg.position = cc.v3(pos.x-delta, pos.y);
                this.scardsBg.position = cc.v3(pos.x+delta, pos.y);
                resolve();
            }
        });
    }

    splitBet(isReenter=false){
        let delta = 60
        this.sbetBg = cc.instantiate(this.betBg)
        this.betBg.parent.addChild(this.sbetBg, this.betBg.zIndex-1);
        let pos = this.betBg.position
        this.betBg.position = cc.v3(pos.x-delta, pos.y);
        this.sbetBg.position = cc.v3(pos.x+delta, pos.y);
    
        if (isReenter) {
            this.addChipToTable(true, 0);
            this.addChipToTable(true, 1);
        }else{
            this.betnum1 = this.betnum;
            this.addChipToTable(true, 1);
        }
    }

    /**
     * 展示输赢
     * @param result 
     * @param win 
     */
    showWinLb(result: string, win: number){
        return new Promise( resolve => {
            if (result==='2') {
                resolve();
                return;
            }
            let winNode = this.winNode;
            winNode.active = true;
            winNode.zIndex = 100;
            winNode.opacity = 0;
            let pos = winNode.position;
            let sp = winNode.getChildByName('winsp');
            let lb = winNode.getChildByName('winLb').getComponent(cc.Label);
            win = nullToZero(win);
            lb.string = '';
            if (result==='1') {
                lb.node.active = true;
                loadSprite(sp.getComponent(cc.Sprite), LangSprite.blackjack_ziti_jiesuan_ying)
                lb.font = this.game.playerMgr.winlbFont[1];
                lb.string = '+'+numToBigNum(win);
            } else if (result==='-1') {
                lb.node.active = true;
                loadSprite(sp.getComponent(cc.Sprite), LangSprite.blackjack_ziti_jiesuan_shu)
                lb.font = this.game.playerMgr.winlbFont[0];
                lb.string = ''+numToBigNum(win);
            } else {
                lb.node.active = false;
                loadSprite(sp.getComponent(cc.Sprite), LangSprite.blackjack_ziti_jiesuan_he)
            }
            let y = g.isLandscape ? 60 : 70;
            winNode.runAction(cc.sequence(
                cc.fadeIn(0.1),
                cc.moveBy(0.3, 0, y),
                cc.callFunc(() => {
                    resolve()
                }),
                cc.delayTime(2),
                cc.fadeOut(0.5),
                cc.callFunc(() => {
                    winNode.position = pos;
                })
            ))
        });
    }

    showBetingSp(isSuccess: boolean){
        if (!this.betingSp || !this.game.hjkEvent.isSitdown) {
            return
        }
        let spId = isSuccess ? 0 : 1
        // this.betingSp.spriteFrame = this.betingSpFrame[spId];
        let frame = [LangSprite.beting_success, LangSprite.beting_fail];
        loadSprite(this.betingSp, frame[spId]);
        let betingNode = this.betingSp.node;
        betingNode.active = true;
        betingNode.zIndex = 200;
        betingNode.opacity = 0;
        betingNode.position = cc.v3(0, 0);
        betingNode.runAction(cc.sequence(
            cc.fadeIn(0.1),
            cc.moveBy(0.3, 0, 70),
            cc.delayTime(2),
            cc.fadeOut(0.5),
            cc.callFunc(() => {
                betingNode.position = cc.v3(0, 0);
            })
        ))
    }

    onClickPlayer(){
        cc.log('onClickPlayer seat: ', this.seat, this.pos)
        if (this.seat!==7 && !this.isTurning) {
            this.game.hjkEvent.sitdownTableReq(this.pos);
        }
    }
}
