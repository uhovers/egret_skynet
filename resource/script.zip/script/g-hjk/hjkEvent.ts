import HjkGame, { checkAction } from "./hjkGame";
import { EVENTTYPE, ActionType } from "../common/enum";
import GameEvent from "../g-share/gameEvent";
import GameData from "../common/net/GameData";
import NetProxy from "../common/net/NetProxy";
import { showTip, showConfirm } from '../common/ui';
import g from "../g";
import HeartCtrl from "../lib/Unitys/heartCtrl";

enum GameState {
    /** 准备中 */
    READING = 1,
    /** 游戏开始 */
    START,
    /** 游戏开始 */
    BETING,
    /** 游戏结算 */
    END
}

const {ccclass, property} = cc._decorator;

@ccclass
export default class HjkEvent extends GameEvent<HjkGame> {

    gameInfo: GameMsg.GameInfo = undefined;
    selfRid: number = undefined;
    private gid: number = undefined;
    private roomSvrId: string = undefined;
    private roomSvrTableAddress: number = undefined;

    gameState: GameState;

    playerInfos: {player: GameMsg.TablePlayerInfo, seat: GameMsg.SeatInfo}[] = []

    actionNtcData: GameMsg.DoactionNtc = undefined;

    sitNtcData: GameMsg.SitdownTableNtc = undefined;

    isGameEnd = false

    bets: number[] = [];
    limitRange: number[] = [];

    init(g: HjkGame){
        super.init(g);
        this.selfRid = GameData.tbBaseInfo.rid;
        this.gameInfo = GameData.gameInfo;
        GameData.gameInfo = undefined;

        this.gid = this.gameInfo.id;
        this.roomSvrId = this.gameInfo.roomsvr_id;
        this.roomSvrTableAddress = this.gameInfo.roomsvr_table_address;
        this.bets = this.gameInfo.bet_nums;
        this.limitRange = this.gameInfo.limitRange;

        this.updateTablePlyerInfo();
    }

    releaseAll(){
        this.gameInfo = null;
        this.gid = null;
        this.roomSvrId = null;
        this.roomSvrTableAddress = null;
        this.bets = null;
        this.limitRange = null;
        this.playerInfos = [];
    }

    updateTablePlyerInfo(){
        this.playerInfos = [];
        for (let i = 0; i < this.gameInfo.tableplayerinfos.length; i++) {
            let player = this.gameInfo.tableplayerinfos[i];
            let seat = this.gameInfo.seats[i];
            this.playerInfos.push({player: player, seat: seat});
        }
    }

    onAppEvent(eventType: EVENTTYPE, data: any){
        // cc.log('HjkEvent eventType== ', eventType);
        if (eventType===EVENTTYPE.EVENT_GameStartNtc) {
            this.gameState = GameState.START;
            this.isGameEnd = false;
            cc.log('游戏开始')
            this.gameInfo = data.gameinfo
            this.gameInfo.last_action_type = ActionType.DEAL;
            this.bets = this.gameInfo.bet_nums;
            this.limitRange = this.gameInfo.limitRange;
            this.updateTablePlyerInfo();
            this.game.gameStartNtc();
        }else if (eventType===EVENTTYPE.EVENT_SitdownTableNtc) {
            // if (this.gameState===GameState.START || this.gameState===GameState.BETING) {
            //     this.sitNtcData = data;
            // }else{
                if (data.rid===this.selfRid) {
                    this.gameInfo = data.gameinfo;
                    this.updateTablePlyerInfo();
                } else {
                    this.addPlayer(data);
                }
                this.game.sitdownTableNtc(data);
            // }
        }else if (eventType===EVENTTYPE.EVENT_StandupTableNtc) {
            this.removePlayer(data);
            this.game.standupTableNtc(data);
        }else if (eventType===EVENTTYPE.EVENT_NoticeClientNtc) {
            if (data.info_id[0]===20) {
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => { 
                    let str = i18n.languages[g.language]['g_no_watch'] || '';
                    showConfirm({ content: str, sure: true });
                });
            } else if (data.info_id[0]===21 || data.info_id[0]===22) {
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => { 
                    let str = i18n.languages[g.language]['g_room_close'] || '';
                    showConfirm({ content: str, sure: true });
                });
            } else if (data.info_id[0]===23) {
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => { 
                    let str = i18n.languages[g.language]['g_insufficient_coins'] || '';
                    showConfirm({ content: str, sure: true });
                });
            } else if (data.info_id[0]===24) {  // 下注超时
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => { 
                    let str = i18n.languages[g.language]['g_bet_timeout'] || '';
                    showConfirm({ content: str, sure: true });
                });
            } else if (data.info_id[0]===25) {  // 房间重启
                g.postLeaveRoom();
                cc.director.loadScene(g.LOBBY_SCENE, () => { 
                    let str = i18n.languages[g.language]['g_room_close'] || '';
                    showConfirm({ content: str, sure: true });
                });
            } else if (data.info_id[0]===26) {  // 连续观战提醒
                let str = i18n.languages[g.language]['g_watch_timeout'] || '';
                let desStr = str.replace(/\*/g, data.info_id[1]);
                let desStr1 = desStr.replace(/\#/g, data.info_id[2]);
                showTip(desStr1)
            } else if (data.info_id[0]===27) {  // 连续超时下注提醒
                let rid = data.info_id[3];
                let index = this.getIndexByRid(rid);
                if (index) {
                    this.game.playerMgr.setPlyStateReady(index);
                }

                if (rid && rid===this.selfRid) {
                    this.game.hjkOperate.hideAll();
                    
                    let str = i18n.languages[g.language]['g_continuous_bet_timeout'] || '';
                    let desStr = str.replace(/\*/g, data.info_id[1]);
                    let desStr1 = desStr.replace(/\#/g, data.info_id[2]);
                    showTip(desStr1)
                }
            }
        }else if (eventType===EVENTTYPE.EVENT_DoactionNtc) {
            this.actionNtcData = data;
            if (data.action_type===ActionType.DEAL) {
                this.gameState = GameState.BETING;
                // this.gameInfo.last_action_type = ActionType.DEAL;
            }
            // this.gameInfo.handle_expire = this.actionNtcData.action_to_time
            this.game.doactionNtc(data);
        }else if (eventType===EVENTTYPE.EVENT_DoactionResultNtc) {
            this.modifyPlayer(data);
            this.game.doactionResultNtc(data);
        }else if (eventType===EVENTTYPE.EVENT_DealCardsNtc) {
            this.game.dealCards(data);
        }else if (eventType===EVENTTYPE.EVENT_GameEndResultNtc) {
            this.isGameEnd = true;
            this.gameState = GameState.END;
            let msg: GameMsg.GameEndResultNtc = data;
            for (let i = 0; i < msg.settlement.length; i++) {
                let tab = msg.settlement[i];
                for (let j = 0; j < this.playerInfos.length; j++) {
                    let info = this.playerInfos[j];
                    if (tab.rid===info.player.rid) {
                        info.player.coins = tab.coins;
                    }
                }
            }
            this.game.hjkRoad.showRoad();
            this.game.gameEndResult(msg);

        } else if (eventType === EVENTTYPE.EVENT_BlackJack21_tablesRes){
            this.releaseAll()
        }else if (eventType===EVENTTYPE.EVENT_GoodsNtc) {
            if (this.isGameEnd) {
                let timerId = setTimeout(() => {
                    this.game.setMyMoney();
                    this.isGameEnd = false;
                    clearTimeout(timerId)
                }, 3000);
            } else {
                this.game.setMyMoney();
            }
        }
    }

    /**
     * 判断自己是否已经坐下
     *
     * @readonly
     * @memberof HjkEvent
     */
    get isSitdown(){
        let isSit = false;
        for (let i = 0; i < this.playerInfos.length; i++) {
            let p = this.playerInfos[i].player;
            if (p.rid===this.selfRid) {
                isSit = true;
            }
        }
        return isSit;
    }

    /**
     * 判断rid是否还在桌内
     *
     * @readonly
     * @memberof HjkEvent
     */
    isSitdownByRid(rid: number){
        let isSit = false;
        for (let i = 0; i < this.playerInfos.length; i++) {
            let p = this.playerInfos[i].player;
            if (p.rid===rid) {
                isSit = true;
            }
        }
        return isSit;
    }

    /**
     * 获取自己的位置信息（坐下才有）
     * 
     * @readonly
     * @memberof HjkEvent
     */
    get mySeatInfo(){
        for (let i = 0; i < this.playerInfos.length; i++) {
            let seat = this.playerInfos[i].seat;
            if (seat.rid===this.selfRid) {
                return seat
            }
        }
        return undefined;
    }

    getIndexByRid(rid: number){
        for (let i = 0; i < this.playerInfos.length; i++) {
            let seat = this.playerInfos[i].seat;
            if (seat.rid===rid) {
                return seat.index;
            }
        }
        return undefined;
    }

    getSeatInfoByRid(rid: number){
        for (let i = 0; i < this.playerInfos.length; i++) {
            let seat = this.playerInfos[i].seat;
            if (seat.rid===rid) {
                return seat;
            }
        }
        return undefined;
    }

    /**
     * 获取自己的信息（坐下才有）
     * 
     * @readonly
     * @memberof HjkEvent
     */
    get myPlayerInfo(){
        for (let i = 0; i < this.playerInfos.length; i++) {
            let player = this.playerInfos[i].player;
            if (player.rid===this.selfRid) {
                return player;
            }
        }
        return undefined;
    }

    /**
     *获取自己的服务器位置（坐下才有）
     *
     * @readonly
     * @memberof HjkEvent
     */
    get mySvrPos(){
        return this.mySeatInfo.index;
    }

    /**
     * 获取玩家本地位置 （服务器为lua，所以要 -1）
     * @param svrPos 玩家在服务器的位置
     */
    getLocalPos (svrPos: number){
        if (svrPos===8) return 7;

        let plySum = this.game.playerMgr.playerSum;
        if (!this.isSitdown) {
            return svrPos - 1;
        }
        let myPos = this.mySvrPos;
        if (svrPos < myPos) {
            let pos = plySum - Math.abs(svrPos - myPos) - 4;
            return pos > -1 ? pos : pos + plySum;
        } else {
            let pos = svrPos - myPos + 3;
            return pos < plySum ? pos : pos - plySum;
        }
    }

    sitDownTable(){
        if (this.sitNtcData) {
            let data = this.sitNtcData;
            if (data.rid===this.selfRid) {
                this.gameInfo = data.gameinfo;
                this.updateTablePlyerInfo();
            } else {
                this.addPlayer(data);
            }
            this.game.sitdownTableNtc(data);
            this.sitNtcData = undefined;
        }
    }

    addPlayer(data: GameMsg.SitdownTableNtc){
        let index = data.seatinfo.index;
        this.playerInfos[index-1] = {player: data.tableplayerinfo, seat: data.seatinfo};
        // cc.log(this.playerInfos);
    }

    getPlyInfoByIndex(index: number){
        return this.playerInfos[index-1];
    }

    removePlayer(data: GameMsg.StandupTableNtc){
        let index = data.roomsvr_seat_index;
        let playerInfo = this.playerInfos[index-1];
        for (const key in playerInfo.player) {
            playerInfo.player[key] = null;
        }
        for (const key in playerInfo.seat) {
            if (key==='index') {
            } else if(key==='state') {
                playerInfo.seat.state = 1;
            }else{
                playerInfo.seat[key] = null;
            }
        }
    }

    modifyPlayer(data: GameMsg.DoactionResultNtc){
        let actionType = data.action_type;
        let index = data.obj_seat-1;
        if (data.coins) {
            this.playerInfos[index].player.coins = data.coins;
        }
        if (checkAction(actionType, ActionType.DEAL)) { // 下注
            this.playerInfos[index].seat.betScores_1 = data.call_times;
        }else if (checkAction(actionType, ActionType.INSURE)) { // 保险
            this.playerInfos[index].seat.is_buy_insurance = data.action_subtype===1;
            if (data.action_subtype===1) {
                this.playerInfos[index].seat.insurance_score = data.call_times;
            }
        }else if (checkAction(actionType, ActionType.SURRENDER)) {  // 投降
            this.playerInfos[index].seat.is_give_up = data.action_subtype===1;
        }else if (checkAction(actionType, ActionType.SPLIT)) {  // 分牌
            this.playerInfos[index].seat.cards_1 = data.cards_1;
            this.playerInfos[index].seat.cards_2 = data.cards_2;
            this.playerInfos[index].seat.betScores_1 = data.betScores_1;
            this.playerInfos[index].seat.betScores_2 = data.betScores_2;
        }else if (checkAction(actionType, ActionType.HIT)) {    // 要牌
            if (data.hand===1) {
                this.playerInfos[index].seat.cards_1.concat(data.cards); 
            } else {
                this.playerInfos[index].seat.cards_2.concat(data.cards); 
            }
        }else if (checkAction(actionType, ActionType.STAND)) {  // 停牌
        }else if (checkAction(actionType, ActionType.DOUBLE)) { // 加倍
            if (data.hand===1) {
                this.playerInfos[index].seat.cards_1.concat(data.cards);
                this.playerInfos[index].seat.betScores_1 = data.betScores;
            } else {
                this.playerInfos[index].seat.cards_2.concat(data.cards); 
                this.playerInfos[index].seat.betScores_2 = data.betScores;
            }
        }
    }

    // 请求服务器消息
    sitdownTableReq(seatIdx: number){
        let param = {
            id: this.gid,
            roomsvr_id: this.roomSvrId, 
            roomsvr_table_address: this.roomSvrTableAddress, 
            roomsvr_seat_index: seatIdx
        };
        NetProxy.SitdownTableReq(param, (data: GameMsg.SitdownTableRes) => {
            if (data.errcode===19) {
                let str = i18n.languages[g.language]['g_no_coin'] || '';
                showTip(str);
            }else if (data.errcode!==null) {
                let str = i18n.languages[g.language]['g_net_error'] || '';
                showTip(str)
            }
        });
    }

    doactionReq(type: ActionType, callTimes?: number, actionSubtype?: number){
        return new Promise<GameMsg.DoactionRes>( resolve => {
            let param: GameMsg.DoactionReq = {
                roomsvr_id: this.roomSvrId,
                roomsvr_table_address: this.roomSvrTableAddress,
                action_type: type,
                action_subtype: actionSubtype,
                call_times: callTimes,
                hand: this.actionNtcData.hand,
                obj_seat: this.mySvrPos
            } 
            NetProxy.DoactionReq(param, (data) => {
                resolve(data);
            });
        });
    }

    leaveTableReq(){
        return new Promise<GameMsg.LeaveTableRes>( resolve => {
            let param = {
                id: this.gid,
                roomsvr_id: this.roomSvrId, 
                roomsvr_table_address: this.roomSvrTableAddress, 
            };
            NetProxy.LeaveTableReq(param, (data) => {
                resolve(data);
            });
        });
    }

    blackjackWayReq(){
        return new Promise<GameMsg.BlackjackWayRes> ( resolve => {
            NetProxy.BlackjackWayReq( data => {
                resolve(data);
            });
        });
    }
    
}
