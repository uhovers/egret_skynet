import { soundCfg, random } from "../common/util";
import Audio  from "../g-share/audio";
import HjkGame from "./hjkGame";

const {ccclass, property} = cc._decorator;

@ccclass
export default class HjkAudio extends cc.Component {

    @property({type: cc.AudioClip, tooltip: '点数语音'})
    private pointClip: cc.AudioClip[] = [];

    @property({type: cc.AudioClip, tooltip: '黑杰克语音'})
    private blackJackClip: cc.AudioClip[] = [];

    @property({type: cc.AudioClip})
    private bustClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private dealerNoBjClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private doubleClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private goodjobClip: cc.AudioClip[] = [];

    @property({type: cc.AudioClip})
    private greatClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private impressClip: cc.AudioClip[] = [];

    @property({type: cc.AudioClip})
    private betingClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private rightClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private splitClip: cc.AudioClip = undefined;

    // effect
    @property({type: cc.AudioClip})
    private bxtkClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private btn1Clip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private btn2Clip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private btn3Clip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private clapLoseClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private clapPushClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private chipFlyClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private chipBtnClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private dealClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private fanClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private discardClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private heClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private hitClip: cc.AudioClip = undefined;
    
    @property({type: cc.AudioClip})
    private startGameClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private hjkWinClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private guzhangClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private hjkgzClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private ptwinClip: cc.AudioClip = undefined;

    @property({type: cc.AudioClip})
    private tickerClip: cc.AudioClip = undefined;
    
    private game: HjkGame = undefined;

    onLoad () {
        this.game = cc.find('game').getComponent(HjkGame);
    }

    playAudio(clip: cc.AudioClip, loop = false) {
        if (soundCfg())
            return cc.audioEngine.play(clip, loop, 1);
    }

    stopAudio(id: number) {
        cc.audioEngine.stop(id);
    }

    timeCountDown(){
        this.playAudio(this.tickerClip);
    }

    /**
     * 播放点数声音（1-21点）
     * @param point 
     */
    playPoint(point: number){
        this.playAudio(this.pointClip[point-1]);
    }

    /**
     * 播放黑杰克声音
     */
    playBlackJack(){
        let idx = random(0, this.blackJackClip.length-1);
        this.playAudio(this.blackJackClip[idx]);
    }

    playBust(){
        this.playAudio(this.bustClip);
    }

    playDealerNoBj(){
        this.playAudio(this.dealerNoBjClip);
    }

    playDouble(){
        this.playAudio(this.doubleClip);
    }

    playGoodJob(){
        let idx = random(0, this.goodjobClip.length-1);
        this.playAudio(this.goodjobClip[idx]);
    }

    playGreat(){
        this.playAudio(this.greatClip);
    }

    playImpress(){
        let idx = random(0, this.impressClip.length-1);
        this.playAudio(this.impressClip[idx]);
    }

    playBeting(){
        this.playAudio(this.betingClip);
    }

    playRight(){
        this.playAudio(this.rightClip);
    }

    playSplit(){
        this.playAudio(this.splitClip);
    }

    // 音效
    playBxtk(){
        this.playAudio(this.bxtkClip);
    }

    playBtn1(){
        this.playAudio(this.btn1Clip);
    }

    playBtn2(){
        this.playAudio(this.btn2Clip);
    }

    playBtn3(){
        this.playAudio(this.btn3Clip);
    }

    playClapLose(){
        this.playAudio(this.clapLoseClip);
    }

    playClapHe(){
        this.playAudio(this.clapPushClip);
    }

    playChipFly(){
        this.playAudio(this.chipFlyClip);
    }

    playChipBtn(){
        this.playAudio(this.chipBtnClip);
    }

    playDeal(){
        this.playAudio(this.dealClip);
    }

    playFan(){
        this.playAudio(this.fanClip);
    }

    playDiscard(){
        this.playAudio(this.discardClip);
    }

    playHetk(){
        this.playAudio(this.heClip);
    }

    playHit(){
        this.playAudio(this.hitClip);
    }

    playStartGame(){
        this.playAudio(this.startGameClip);
    }

    playHjkWin(){
        this.playAudio(this.hjkWinClip);
    }

    playHjkgz(){
        this.playAudio(this.hjkgzClip);
    }

    playGuzhang(){
        this.playAudio(this.guzhangClip);
    }

    playPtWin(){
        this.playAudio(this.ptwinClip);
    }
}
