import Game from "../g-share/game";
import HjkPlayerMgr from "./hjkPlayerMgr";
import HjkEvent from "./hjkEvent";
import PokerMgr from "../g-share/pokerMgr";
import ChipMgr from "../g-share/chipMgr";
import g from "../g";
import { BetLimit } from "../common/cfg";
import { CardsPoint, ActionType, AnimName } from "../common/enum";
import { soundCfg, shiftSound, fitCanvas, nullToZero, transMoney, loadSprite } from "../common/util";
import HjkOperate from "./hjkOperate";
import { showTip, showLoading, hideLoading, showConfirm } from "../common/ui";
import HjkHistory from "./hjkHistory";
import HjkRoad from "./hjkRoad";
import HjkHandMgr from "./hjkHandMgr";
import GameData from "../common/net/GameData";
import NetProxy from "../common/net/NetProxy";
import HjkAudio from "./hjkAudio";
import { numToBigNum } from "../common/Helper";
import GameInfo from "../lobby/gameInfo";
import { LangSprite } from "../g-share/resCfg";

const {ccclass, property} = cc._decorator;

/**
 * Decimal
 * @param val 
 */
const decimal = function (val:any) {
    return new window.Decimal(val);
}

/**
 * blackjack 上限
 */
const sum_upperlimit = 21;

/**
 * 自己坐下后的本地下标
 */
const LocalMyIndex = 3;

/**
 * 牌的总张数
 */
const POKER_COUNT = 416;

/**
 * 检测是否存在某一个操作
 * @param type 
 * @param actionType 
 */
export let checkAction = function (type: number, actionType: ActionType){
    return !!(type & actionType);
}

@ccclass
export default class HjkGame extends Game {
    @property(PokerMgr)
    pokerMgr: PokerMgr = undefined;

    @property(ChipMgr)
    chipMgr: ChipMgr = undefined;

    @property({type: HjkPlayerMgr, override: true})
    playerMgr: HjkPlayerMgr = undefined;

    @property(HjkEvent)
    hjkEvent: HjkEvent = undefined;

    @property(HjkOperate)
    hjkOperate: HjkOperate = undefined;

    @property(cc.Label)
    money: cc.Label = undefined;

    @property({type: cc.Node, tooltip: '菜单节点'})
    private menuBg: cc.Node = undefined;

    @property(cc.Node)
    private touchBg: cc.Node = undefined;

    @property(cc.Node)
    wallet: cc.Node = undefined;

    @property(cc.Node)
    private touchWallet: cc.Node = undefined;
    
    @property(cc.Sprite)
    private audioSp: cc.Sprite = undefined;

    @property(cc.Sprite)
    private gameInfoSp: cc.Sprite = undefined;

    @property(cc.Sprite)
    private historySp: cc.Sprite = undefined;

    @property(cc.Sprite)
    logoSp: cc.Sprite = undefined;

    @property(cc.Node)
    private info: cc.Node = undefined;

    @property(cc.Node)
    private dealBg: cc.Node = undefined;

    @property(cc.Node)
    private dealCard: cc.Node = undefined;

    @property(cc.Node)
    private dealYellow: cc.Node = undefined;

    @property(cc.Node)
    private yellowCard: cc.Node = undefined;

    @property(cc.Node)
    private yellowStart: cc.Node = undefined;

    @property(cc.Node)
    private yellowEnd: cc.Node = undefined;

    @property(cc.Sprite)
    limitSp: cc.Sprite = undefined;

    @property(cc.Label)
    private roomBetLb: cc.Label = undefined;

    @property(cc.Node)
    private stateBg: cc.Node = undefined;

    @property(cc.Node)
    private lastRound: cc.Node = undefined;

    @property(cc.SpriteFrame)
    private stateFrame: cc.SpriteFrame[] = [];

    @property(cc.Node)
    private gameStatus: cc.Node = undefined;

    @property(cc.Node)
    private roomTip: cc.Node = undefined;

    @property(HjkAudio)
    hjkAudio: HjkAudio = undefined;

    @property(HjkHandMgr)
    handMgr: HjkHandMgr = undefined;

    @property(HjkHistory)
    private hjkHistory: HjkHistory = undefined;

    @property(GameInfo)
    private gameInfo: GameInfo = undefined;

    @property(HjkRoad)
    hjkRoad: HjkRoad = undefined;

    @property(cc.EditBox)
    testEdit: cc.EditBox = undefined;

    private _menuBgPlayingAnim = false;
    gState: number = 0;
    private timeoutId1 = 0;
    private timeoutId2 = 0;

    /** 记录玩家上一局的下注 */
    lastBet: number = undefined; 

    onLoad(){
        fitCanvas(this.nodeCanvas);
        this.menuBg.scaleY = 0;

        loadSprite(this.gameInfoSp, LangSprite.lb_info);
        let audioSprite = soundCfg()>0 ? LangSprite.lb_close_audio : LangSprite.lb_open_audio;
        loadSprite(this.audioSp, audioSprite)
        loadSprite(this.historySp, LangSprite.lb_history);

        loadSprite(this.limitSp, LangSprite.blackjack_limit);

        loadSprite(this.logoSp, LangSprite.blackjack_ziti_tips);

        loadSprite(this.lastRound.getComponent(cc.Sprite), LangSprite.last_round);

        this.touchBg.on(cc.Node.EventType.TOUCH_START, ()=>{this.menuAnim();});
        this.touchBg["_touchListener"].setSwallowTouches(false);
        this.roomBetLb.string = `-`;

        this.touchWallet.scaleY = 0;
        this.touchWallet.on(cc.Node.EventType.TOUCH_START, ()=>{this.walletAnim();});
        this.touchWallet["_touchListener"].setSwallowTouches(false);
    }

    start () {
        this.playerMgr.setGame(this);
        this.hjkEvent.init(this);
        NetProxy.resumeReceiveMsg();

        this.roomBetLb.string = this.hjkEvent.limitRange.length>1 ? `${transMoney(this.hjkEvent.limitRange[0])}-${transMoney(this.hjkEvent.limitRange[this.hjkEvent.limitRange.length - 1])}` : '-';
        this.setMyMoney();
        this.hjkOperate.init(this.hjkEvent.bets);
        this.gameStatus.active = false;
        this.roomTip.active = false;
        this.stateBg.active = false;
        this.handMgr.node.active = false;
        this.yellowCard.active = false;
        this.lastRound.active = false;
        this.initGame();
    }

    initGame( ) {
        this.initDealer(this.hjkEvent.gameInfo.yellow_card_coordinate);
        this.udpateDeal(this.hjkEvent.gameInfo.remain_cards_count);

        this.showGameInfo();

        this.playerMgr.updateTablePlys();
        this.updateGameState();

        // if (GameData.reEnterFlag) {
            this.scheduleOnce(()=>{
                this.updateReenterTableData();
            }, 0.1);
        //     GameData.reEnterFlag = false;
        // }else{
        //     this.resumePly();
        // }
        if (this.hjkEvent.gameInfo.is_reach_yellow_card) {
            this.showYellowCard(true, false);
        }
    }

    showGameInfo(){
        this.info.active = true;

        let n1 = this.info.getChildByName('n1')
        loadSprite(n1.getChildByName('roundId').getComponent(cc.Sprite), LangSprite.blackjack_xinxi_juhao);

        let n2 = this.info.getChildByName('n2')
        loadSprite(n2.getChildByName('roomId').getComponent(cc.Sprite), LangSprite.blackjack_xinxi_id);

        n1.getChildByName('lb').getComponent(cc.Label).string = this.hjkEvent.gameInfo.table_round_id==null ? '' : ''+this.hjkEvent.gameInfo.table_round_id;
        n1.getComponent(cc.Layout).updateLayout();

        n2.getChildByName('lb').getComponent(cc.Label).string = this.hjkEvent.gameInfo.game_type==null ? '' : ''+this.hjkEvent.gameInfo.game_type;
        n2.getComponent(cc.Layout).updateLayout();
    }

    setMyMoney(){
        this.money.string = numToBigNum(nullToZero(GameData.tbBaseInfo.coins)+nullToZero(GameData.tbBaseInfo.e_wallet));

        this.wallet.getChildByName('item').active = nullToZero(GameData.tbBaseInfo.coins)>0;
        this.wallet.getChildByName('item1').active = nullToZero(GameData.tbBaseInfo.e_wallet)>0;
        this.wallet.getChildByName('item').getChildByName('money').getComponent(cc.Label).string = numToBigNum(nullToZero(GameData.tbBaseInfo.coins));
        this.wallet.getChildByName('item1').getChildByName('money').getComponent(cc.Label).string = numToBigNum(nullToZero(GameData.tbBaseInfo.e_wallet));
    }

    initDealer(yellowIdx: number) {
        this.dealBg.removeAllChildren();
        if (yellowIdx===null) return;
        
        let xs = POKER_COUNT;
        let total = xs, yellow = yellowIdx;
        for (let i = 1; i <= total; i++) {
            let base = i === (xs-yellow) ? cc.instantiate(this.dealYellow) : cc.instantiate(this.dealCard);
            base.active = true;
            base.position = cc.v3(5-i*0.075, 30-i*0.12);
            this.dealBg.addChild(base, i+1);
        }
    }

    udpateDeal(count: number){
        let childs = this.dealBg.children;
        // let idx = Math.floor(100 * (count/POKER_COUNT))
        let idx = count;
        for (let i = 1; i <= childs.length; i++) {
            let c = childs[i-1];
            c.active = i <= idx;
        }
    }

    showYellowCard(active=false, doAnim=true){
        this.yellowCard.active = active;
        this.lastRound.active = false;
        let cardScale = 0.4
        if (doAnim) {
            this.lastRound.active = true;
            this.yellowCard.scale = cardScale;
            this.yellowCard.position = this.yellowStart.position;
            this.lastRound.position = cc.v3(-cc.winSize.width,0);

            this.yellowCard.runAction(cc.sequence(
                cc.spawn(cc.moveTo(0.5, cc.v2(0, 0)), cc.scaleTo(0.5, 1)),
                cc.spawn(cc.delayTime(1), cc.callFunc(() => {
                    this.lastRound.runAction(cc.moveTo(0.5, cc.v2(0, 0)))
                })),
                cc.spawn(cc.moveTo(0.5, cc.v2(this.yellowEnd.position.x, this.yellowEnd.position.y)), cc.scaleTo(0.5, cardScale),cc.callFunc(() => {
                    this.lastRound.runAction(cc.moveTo(0.5, cc.v2(cc.winSize.width, 0)))
                })
            )));
        }else{
            this.yellowCard.scale = cardScale;
            this.yellowCard.position = this.yellowEnd.position;
        }
    }

    updateGameState( ) {
        let lb = this.gameStatus.getChildByName('stateLb').getComponent(LocalizedLabel);
        if (this.hjkEvent.isSitdown) {
            this.handMgr.node.active = true;
            // let p = this.playerMgr.getPlayerByPos(LocalMyIndex);
            // cc.warn('updateGameState: ', p.isReady)
            // this.gameStatus.active = p.isReady && p.handCards.length===0;
            let seat = this.hjkEvent.mySeatInfo;
            this.gameStatus.active = seat.state===2;
            // lb.dataID = '请耐心等待下一局.'
            let str = i18n.languages[g.language]['g_wait_next'] || '';
            lb.dataID = str;
        }else{
            this.handMgr.node.active = false;
            this.gameStatus.active = true;
            // lb.dataID = '观战中...';
            let str = i18n.languages[g.language]['g_watching'] || '';
            lb.dataID = str;
        }
    }

    /**
     * 房间状态
     * @param state 0 下注中；1 投降中；2 购买保险
     * @param active 
     */
    showStateBg(state: number, active=true){
        this.stateBg.active = active;
        if (active) {
            let frame = [LangSprite.state_xz, LangSprite.state_tx, LangSprite.state_bx]
            loadSprite(this.stateBg.getChildByName('state').getComponent(cc.Sprite), frame[state])

            // this.stateBg.getChildByName('state').getComponent(cc.Sprite).spriteFrame = this.stateFrame[state];
        }
    }

    /**
     * 
     * @param action 
     * @param time 
     */
    updateRoomTip(action: ActionType, time?: number){
        this.roomTip.active = true
        let lb = this.roomTip.getChildByName('lb').getComponent(LocalizedLabel);
        lb.node.stopAllActions();
        lb.unscheduleAllCallbacks();
        if (action===ActionType.SHUFFLE) {  // 洗牌中
            // lb.string = '洗牌中,请稍等';
            let str = i18n.languages[g.language]['g_shuffling'] || '';
            lb.dataID = str;
            this.dealBg.children.forEach(n => { n.active = false});
            this.roomTip.runAction(cc.sequence(cc.delayTime(2), cc.callFunc(()=>{
                this.roomTip.active = false;
            })))
        } else if (action===ActionType.DEAL) {  // 游戏开始
            // lb.string = '游戏开始';
            let str = i18n.languages[g.language]['g_game_start'] || '';
            lb.dataID = str;
            this.roomTip.runAction(cc.sequence(cc.delayTime(1), cc.callFunc(()=>{
                this.roomTip.active = false;
            })))
        } else {
            // lb.string = `休息中... (${time}s)`;
            let str = i18n.languages[g.language]['g_resting'] || '';
            lb.dataID = `${str} (${time}s)`;

            let timeFunc = () =>{
                time -=1;
                // lb.string = `休息中... (${time}s)`;
                lb.dataID = `${str} (${time}s)`;
                if (time < 0) {
                    this.roomTip.active = false;
                    lb.unscheduleAllCallbacks()
                }
            }
            lb.schedule(timeFunc, 1)
        }
    }

    updateReenterTableData(){
        let gameInfo = this.hjkEvent.gameInfo;
        let actionNtc: GameMsg.DoactionNtc = {
            obj_seat: gameInfo.player_rounds_index,
            action_type: gameInfo.last_action_type,
            action_to_time: gameInfo.handle_expire-1,
            hand: gameInfo.hand_index,
        }
        if (gameInfo.player_rounds_index!==null && this.hjkEvent.getPlyInfoByIndex(gameInfo.player_rounds_index).player) {
            actionNtc.rid = this.hjkEvent.getPlyInfoByIndex(gameInfo.player_rounds_index).player.rid
        }
        if ((checkAction(actionNtc.action_type, ActionType.DEAL) 
        || checkAction(actionNtc.action_type, ActionType.SURRENDER) 
        || checkAction(actionNtc.action_type, ActionType.INSURE)) && this.hjkEvent.mySeatInfo && this.hjkEvent.mySeatInfo.state===19) {
            actionNtc.rid = this.hjkEvent.mySeatInfo.rid;
        }

        // let actionNtc = {obj_seat: 3, action_type: 14, action_to_time: 3};
        cc.warn(gameInfo.seats);
        cc.warn('重连数据: ', actionNtc);
        this.resumePly();
        this.updateGameState();

        if (actionNtc.action_to_time>0 && actionNtc.action_type!==null) {
            this.hjkEvent.actionNtcData = actionNtc;
            this.scheduleOnce(() => {
                this.doactionNtc(actionNtc);
            }, 0.1)
        }
    }

    resumePly(){
        if (checkAction(this.hjkEvent.gameInfo.last_action_type, ActionType.RESTING)) {
            return;
        }
        for (let i = 0; i < this.hjkEvent.playerInfos.length; i++) {
            let seat = this.hjkEvent.playerInfos[i].seat;
            // cc.log(i+' =====', seat)
            if (seat.index!==8 && seat.rid===null) continue;
            let localPos = this.hjkEvent.getLocalPos(seat.index);
            let p = this.playerMgr.getPlayerByPos(localPos);
            if (seat.state===2) {   // 等待准备
                continue;
            }
            if (seat.state===19) {  // 已经开始
                p.setStateStart();
            }
            if (seat.betScores_1>0) {
                p.betnum = seat.betScores_1;
                if (this.hjkEvent.selfRid===seat.rid) {
                    this.lastBet =  seat.betScores_1;
                }
                p.addChipToTable(false, 0);
            }
            if (seat.betScores_2>0) {
                p.betnum1 = seat.betScores_2;
            }
            if (seat.cards_1.length>0 && seat.cards_2.length>0) {
                p.splitCards(true, false);
            }
            if (seat.cards_1.length > 0) {
                p.handCards = seat.cards_1;
                p.cardsBg.active = true;
                for (let j = 0; j < p.handCards.length; j++) {
                    p.addCards(j, p.handCards[j], false, 0);
                }
                if (seat.cards_2.length===0 && this.isBlackJack(seat.cards_1)) {
                    p.showBlackJack();
                } else {
                    p.showPoint(this.calcPoint(p.handCards), 0, seat.state===17);
                }
            }
            if (seat.cards_2.length > 0) {
                p.handCards2 = seat.cards_2;
                p.scardsBg.active = true;
                for (let j = 0; j < p.handCards2.length; j++) {
                    p.addCards(j, p.handCards2[j], false, 1);
                }
                p.showPoint(this.calcPoint(p.handCards2), 1, seat.state===17);
            }
            if (seat.is_buy_insurance) {    // 是否买保险;
                this.playerMgr.showInsure(seat.index, 1, seat.insurance_score);
            }
            if (seat.is_give_up) {
                this.playerMgr.showSurrender(seat.index);
            }
        }
    }

    gameStartNtc(){
        this.showGameInfo();
        this.hjkOperate.chipVals = this.hjkEvent.bets;
        this.hjkAudio.playStartGame();
        this.playerMgr.updateStart();
        this.updateGameState();
        // this.scheduleOnce(() => {
        //     this.hjkEvent.sitDownTable();
        // }, 0.05);
    }

    // 坐下响应
    async sitdownTableNtc(data: GameMsg.SitdownTableNtc){
        if (data.rid===this.hjkEvent.selfRid) {
            NetProxy.stopReceiveMsg();
            await this.playerMgr.sitDownAnim(data);
            this.playerMgr.updateTablePlys();
            this.scheduleOnce(() => {
                this.updateReenterTableData();
                cc.log('坐下动画完成');
                NetProxy.resumeReceiveMsg();
            }, 0.01);
        } else {
            this.playerMgr.sitdownTable(data);
        }
    }

    // 站起响应
    standupTableNtc(data: GameMsg.StandupTableNtc){
        if (this.isSelf(data.rid) && data.reason==5) {
            this.hjkOperate.hideAll();
            this.playerMgr.leaveTable(data.roomsvr_seat_index);
            this.playerMgr.updateTablePlys();
            this.playerMgr.updatePlayersBet();
            this.updateGameState();
            let str = i18n.languages[g.language]['g_bet_timeout'] || '';
            showConfirm({ content: str, sure: true });
        } else {
            this.playerMgr.leaveTable(data.roomsvr_seat_index);
        }
    }

    async doactionNtc(data: GameMsg.DoactionNtc){
        let actionType = data.action_type;
        // cc.log('doactionNtc: ', actionType);
        // 休息中
        if (checkAction(actionType, ActionType.RESTING)) {
            this.updateRoomTip(actionType, data.action_to_time);
            this.discards(false);
            // this.timeoutId2 = setTimeout(() => {
            //     this.playerMgr.updateTablePlys();
            //     clearTimeout(this.timeoutId2);
            // }, 1000);
            this.updateGameState();
            this.showStateBg(undefined, false);
            return
        }
        // 洗牌中
        if (checkAction(actionType, ActionType.SHUFFLE)) {
            this.updateRoomTip(ActionType.SHUFFLE, data.action_to_time);
            this.showYellowCard(false);
            this.showStateBg(undefined, false);
            return
        }
        if (checkAction(actionType, ActionType.DEAL)) {
            // 游戏开始
            this.hjkAudio.playBeting();
            this.updateRoomTip(ActionType.DEAL);
            this.showStateBg(0);
            this.updateGameState();
            cc.log('游戏开始', data);
        }
        if (checkAction(actionType, ActionType.SURRENDER)) {
            // 投降
            this.showStateBg(1);
        }
        if (checkAction(actionType, ActionType.INSURE)) {
            // 保险
            this.showStateBg(2);
        }
        if (checkAction(actionType, ActionType.STAND)) {
            // 开始操作了
            this.showStateBg(undefined, false);
        }
        this.playerMgr.startCountdown(data.action_to_time, data.obj_seat);
        if (this.hjkEvent.isSitdown) {
            let p = this.playerMgr.getPlayerByPos(LocalMyIndex);
            if (p.isReady) {
                cc.log('自己是准备中')
                return;
            }
            if (checkAction(actionType, ActionType.DEAL) && this.isSelf(data.rid)) { // 通知下注
                this.hjkOperate.showChipMenu();
                return
            }
            if (checkAction(actionType, ActionType.SURRENDER) && this.isSelf(data.rid)) { // 投降
                this.hjkOperate.showSurrender();
                return
            }
            if (checkAction(actionType, ActionType.INSURE) && this.isSelf(data.rid)) { // 保险
                this.hjkOperate.showInsure(p.betnum/2,data.action_to_time);
                return
            }
            if (this.isSelf(data.rid)) {
                this.playerMgr.showSplitTip(data.obj_seat, data.hand-1);
                this.hjkOperate.showOperate(actionType);
            } else {
                this.hjkOperate.hideAll();
            }
        }
    }

    async doactionResultNtc(data: GameMsg.DoactionResultNtc){
        let actionType = data.action_type;
        // 更新玩家金币
        this.playerMgr.updatePlayerCoins(data.obj_seat, data.coins);
        this.playerMgr.stopCountdown(data.obj_seat);
        // if (actionType===null) {
        //     if (data.is_blackjack_banker==='0') {
        //         this.hjkAudio.playDealerNoBj();
        //     }
        // }
        if (checkAction(actionType, ActionType.DEAL)) { // 下注结果
            if (this.isSelf(data.rid)) {
                this.hjkOperate.hideAll();
                this.lastBet = data.call_times;
                this.scheduleOnce(()=>{
                    this.playerMgr.showBetState(true);
                }, 0.4)
                this.playerMgr.betToTable(data.obj_seat, data.call_times, false);
            }else{
                this.playerMgr.betToTable(data.obj_seat, data.call_times);
            }
        }else if (checkAction(actionType, ActionType.INSURE)) {
            if (this.isSelf(data.rid)) {
                this.hjkOperate.hideAll();
            }
            this.playerMgr.showInsure(data.obj_seat, data.action_subtype);
        }else if (checkAction(actionType, ActionType.SURRENDER)) {
            if (this.isSelf(data.rid)) {
                this.hjkOperate.hideAll();
            }
            if (data.action_subtype===1) {  // 投降标识
                this.playerMgr.showSurrender(data.obj_seat);
            }
        }else if (checkAction(actionType, ActionType.SPLIT)) {
            this.playerMgr.splitCard(data.obj_seat, data.cards_1, data.cards_2, data.is_last_refill);
            this.hjkAudio.playSplit();
            this.udpateDeal(data.remain_cards_count);
            if (data.is_reach_yellow_card) {
                this.showYellowCard(true)
            }
        }else if (checkAction(actionType, ActionType.HIT)) {
            // 要牌超时自动补牌了，隐藏操作按钮
            if (this.isSelf(data.rid)) {
                if (data.is_last_refill) {
                    this.hjkOperate.hideAll();
                    this.playerMgr.hideSplitTip(data.obj_seat, 0);
                    this.playerMgr.hideSplitTip(data.obj_seat, 1);
                } else {
                    this.hjkAudio.playHit();
                    this.handMgr.playRightAnim(AnimName.BlackJack_shou5);
                }
            }
            if (data.action_to_time>0) {
                this.playerMgr.startCountdown(data.action_to_time, data.obj_seat);
            }
            await this.getCard(data, data.is_last_refill);
        }else if (checkAction(actionType, ActionType.STAND)) {
            if (this.isSelf(data.rid)) {
                this.hjkOperate.hideAll();
            }
            this.playerMgr.updateEndPoint(data.obj_seat, data.hand-1);
        }else if (checkAction(actionType, ActionType.DOUBLE)) {
            if (this.isSelf(data.rid)) {
                this.hjkOperate.hideAll();
            }
            this.playerMgr.betToTable(data.obj_seat, data.call_times, false, data.hand-1);
            this.hjkAudio.playDouble();
            await this.getCard(data, true, true);
        }else if (checkAction(actionType, ActionType.SHUFFLE)) {    // 洗牌结束
            this.hjkRoad.showRoad();
            this.initDealer(data.yellow_card_coordinate);
        }
    }

    private isSelf(rid: number){
        return rid===this.hjkEvent.selfRid;
    }

    async dealCards(data: GameMsg.DealCardsNtc_21){
        this.showStateBg(undefined, false);
        this.playerMgr.clearBets();
        await this.playerMgr.dealCard(data.seat_cards);
    }

    async onClickBtn1(){
        // let tab = []
        // for (let index = 0; index < 8; index++) {
        //     let obj = {obj_seat: index+1, cards: [1,2]};
        //     tab.push(obj);
        //     // let obj1 = {obj_seat: 8, cards: [1,99]};
        //     // tab.push(obj1);
        // }
        // cc.log(tab)
        // // this.dealCards(tab);
        // cc.log(Date.now())
        // await this.playerMgr.dealCard(tab);
        // cc.log(Date.now())

        this.showYellowCard(true);
        // this.handMgr.playRightAnim(AnimName.BlackJack_shou8);
        let data: GameMsg.DoactionResultNtc = {
            obj_seat: 4,
            hand: 1,
            cards: [1,2],
            action_to_time: 10,
            remain_cards_count: 100,
            is_reach_yellow_card: false
        }
        // this.getCard(data);
    }

    onClickBtn2(){
        // this.showYellowCard(false);
        cc.log(this.testEdit.string);

        let name = AnimName['BlackJack_shou'+this.testEdit.string];
        cc.log(name);
        if (!name) {
            cc.log('name 不存在');
            return
        }
        
        this.handMgr.node.active = true;
        this.handMgr.playRightAnim(name);
    }

    async getCard(data: GameMsg.DoactionResultNtc, end=false, isDouble=false){
        let localPos = this.hjkEvent.getLocalPos(data.obj_seat);
        let p = this.playerMgr.getPlayerByPos(localPos);
        let handIdx = data.hand - 1
        let index = handIdx===0 ? p.handCards.length : p.handCards2.length;
        if (handIdx===0) {
            p.handCards.push.apply(p.handCards, data.cards);
            cc.log('handCards: ',p.handCards)
        } else {
            p.handCards2.push.apply(p.handCards2, data.cards);
            cc.log('handCards2: ',p.handCards2)
        }

        for (let i = 0; i < data.cards.length; i++) {
            let c = data.cards[i];
            await p.updateCardXandAng(handIdx);
            await p.addCards(index+i, c, true, handIdx);
        }
        let handCards = handIdx===0 ? p.handCards : p.handCards2;
        let points = this.calcPoint(handCards)
        p.showPoint(points, handIdx, end);
        if (end || data.action_to_time===null) {
            p.hideSplitTip(handIdx);
        }
        if (!isDouble) {
            if (points[1] <= sum_upperlimit) {
                this.hjkAudio.playPoint(points[1]);
            }else if (points[0]<= sum_upperlimit) {
                this.hjkAudio.playPoint(points[0]);
            } else {
                this.hjkAudio.playBust();
            }
        }

        this.udpateDeal(data.remain_cards_count);
        if (data.is_reach_yellow_card) {
            this.showYellowCard(true)
        }
    }

    async gameEndResult(data: GameMsg.GameEndResultNtc){
        this.showStateBg(undefined, false);
        this.hjkOperate.hideAll();
        await this.openDealerCards(data.banker_cards);

        await this.showWinResult(data.settlement);
        let dealer = this.playerMgr.getPlayerByPos(7);
        dealer.setSeatState(false);

        this.timeoutId1 = setTimeout(() => {
            this.discards();
            clearTimeout(this.timeoutId1);
        }, 3000);
        
        this.timeoutId2 = setTimeout(() => {
            this.playerMgr.updateTablePlys();
            clearTimeout(this.timeoutId2);
        }, 4000);
    }

    /**
     * 庄家开牌
     * @param cards 
     */
    openDealerCards(cards: number[]){
        return new Promise( async resolve => {
            if (cards.length === 1) {
                resolve();
                return;
            }
            let dealer = this.playerMgr.getPlayerByPos(7);
            dealer.setSeatState(true);
            let dealerCard = dealer.handCards;
            dealer.handCards = cards;
            dealer.cardsBg.active = true;
            await dealer.updateCardXandAng();
            // 已经开了一张牌，所以从第二张开始开牌
            for (let i = 1; i < dealer.handCards.length; i++) {
                let c = dealer.handCards[i];
                await dealer.addCards(i, c, true).then(() => {
                    if (dealer.handCards.length===2) {
                        if (i===1) {
                            if (this.isBlackJack(dealer.handCards)) {
                                dealer.showBlackJack();
                                this.hjkAudio.playBlackJack();
                            } else {
                                this.hjkAudio.playDealerNoBj();
                                dealer.showPoint(this.calcPoint(dealer.handCards), 0, true);
                            }
                        }
                    } else {
                        if (i===1) {
                            this.hjkAudio.playDealerNoBj();
                        }
                        dealerCard.push(c)
                        dealer.showPoint(this.calcPoint(dealerCard), 0, true);
                    }
                    if (i===dealer.handCards.length-1) {
                        let time = setTimeout(() => {
                            resolve(); 
                            clearTimeout(time);
                        }, 500);
                    }
                });
            }
        });
    }

    isBlackJack(cards: number[]){
        let isBJ = false;
        if (cards.length===2) {
            let points = this.calcPoint(cards);
            if (points[1]===21) {
                isBJ = true;
            }
        }
        return isBJ;
    }

    showWinResult(settlement: GameMsg.Settlement21[]){
        return new Promise(async resolve => {
            let parr = [];
            let selfWin = '';
            let selfCards = [];
            for (let i = 0; i < settlement.length; i++) {
                let data = settlement[i];
                let seatInfo = this.hjkEvent.getSeatInfoByRid(data.rid);
                // cc.log(seatInfo);
                // cc.log('===========', this.hjkEvent.isSitdownByRid(data.rid))
                if (!this.hjkEvent.isSitdownByRid(data.rid) || !seatInfo || seatInfo.state==2) {
                    cc.log('不需要展示输赢');
                    continue;
                }
                let localPos = this.hjkEvent.getLocalPos(data.obj_seat)
                let p = this.playerMgr.getPlayerByPos(localPos);
                p.setSeatState(false);
                p.updatePlyCoins(data.coins);
                if (this.isSelf(data.rid)) {
                    selfWin = data.victory;
                    selfCards = p.handCards;
                }
                if (data.victory_1==='1') {
                    p.showResultSp(2, 0);
                }else if (data.victory_1==='-1') {
                    p.showResultSp(3, 0);
                }
                if (data.victory_2==='1') {
                    p.showResultSp(2, 1);
                }else if (data.victory_2==='-1') {
                    p.showResultSp(3, 1);
                }
                if (p.handCards2.length===0) {  // 未分牌
                    parr.push(p.showWinLb(data.victory, data.win_score));
                }else if (data.victory!=='0') { // 分牌不为和
                    parr.push(p.showWinLb(data.victory, data.win_score));
                }
            }

            let point = this.getMax(this.calcPoint(selfCards));
            switch (selfWin) {
                case "-1":
                    this.hjkAudio.playClapLose();
                    this.handMgr.playRightAnim(AnimName.BlackJack_shou11)
                    break;
                case "0":
                    this.hjkAudio.playHetk();
                    this.handMgr.playRightAnim(AnimName.BlackJack_shou11)
                    this.hjkAudio.playClapHe();
                    break;
                case "1":
                    if (point<17) {
                        this.hjkAudio.playGoodJob();
                        this.handMgr.playRightAnim(AnimName.BlackJack_shou3);
                        this.hjkAudio.playPtWin();
                    } else if (point>=17 && point<=19) {
                        this.hjkAudio.playGoodJob();
                        this.handMgr.playRightAnim(AnimName.BlackJack_shou9);
                        this.hjkAudio.playPtWin();
                    } else if (!this.isBlackJack(selfCards) && (point===20 || point===sum_upperlimit)) {
                        this.hjkAudio.playImpress();
                        this.handMgr.playRightAnim(AnimName.BlackJack_shou10);
                        this.hjkAudio.playGuzhang();
                    } else if (this.isBlackJack(selfCards)) {
                        this.hjkAudio.playHjkWin();
                        this.handMgr.playRightAnim(AnimName.BlackJack_shou8);
                        this.hjkAudio.playHjkgz();
                    }
                    break;
                default:
                    break;
            }
            await Promise.all(parr).then(resolve);
        });
    }

    discards(doAnim=true){
        return new Promise(async resolve => {
            let count = 8;
            for (let i = 0; i < count; i++) {
                if (this.playerMgr.getPlayerByPos) {
                    let p = this.playerMgr.getPlayerByPos(i);
                    p.discards(doAnim);
                    if (i===count-1) resolve();
                }
            }
        });
    }

    // 下注
    async gameBet(bet: number){
        if (bet<=0) {
            cc.log('选择下注错误', bet);
            return;
        }
        let data = await this.hjkEvent.doactionReq(ActionType.DEAL, bet);
        this.playerMgr.stopCountdown(this.hjkEvent.mySeatInfo.index);
        if (data.errcode===19) {
            this.playerMgr.myBeting(false);
            let str = i18n.languages[g.language]['g_no_coin'] || '';
            showTip(str);
        }else if (data.errcode===609) { //超过下注限制
            this.playerMgr.myBeting(false);
            let str = i18n.languages[g.language]['g_bet_outlimit'] || '';
            showTip(str)
        }else if (data.errcode!==null) {
            this.playerMgr.myBeting(false);
            this.playerMgr.showBetState(false);
        }
    }

    // 保险
    async gameInsure(call: number){
        let data = await this.hjkEvent.doactionReq(ActionType.INSURE, undefined, call);
        if (data.errcode===19) {
            let str = i18n.languages[g.language]['g_no_coin'] || '';
            showTip(str);
        }else if (data.errcode!==null) {
            let str = i18n.languages[g.language]['g_net_wait'] || '';
            showTip(str);
        }
        this.playerMgr.stopCountdown(this.hjkEvent.mySeatInfo.index);
    }

    async gameSurrender(call: number){
        let data = await this.hjkEvent.doactionReq(ActionType.SURRENDER, undefined, call);
        if (data.errcode!==null) {
            let str = i18n.languages[g.language]['g_net_wait'] || '';
            showTip(str);
        }
        this.playerMgr.stopCountdown(this.hjkEvent.mySeatInfo.index);
    }

    // 停牌
    async standPoker(){
        let data = await this.hjkEvent.doactionReq(ActionType.STAND);
        if (data.errcode!==null) {
            let str = i18n.languages[g.language]['g_net_wait'] || '';
            showTip(str);
            return;
        }
        this.playerMgr.stopCountdown(this.hjkEvent.mySeatInfo.index);
        this.handMgr.playRightAnim(AnimName.BlackJack_shou12);
    }

    // 要牌
    async hitPoker(){
        let data = await this.hjkEvent.doactionReq(ActionType.HIT);
        if (data.errcode!==null) {
            let str = i18n.languages[g.language]['g_net_wait'] || '';
            showTip(str);
            return;
        }
        this.hjkOperate.showOperate(data.action_type);
    }

    // 分牌
    async splitPoker(){
        let data = await this.hjkEvent.doactionReq(ActionType.SPLIT);
        if (data.errcode===19) {
            let actType = this.hjkEvent.actionNtcData.action_type;
            // actType = actType^ActionType.SPLIT;
            this.hjkOperate.showOperate(actType);
            let str = i18n.languages[g.language]['g_no_coin'] || '';
            showTip(str);
            return
        } else if (data.errcode!==null) {
            let str = i18n.languages[g.language]['g_net_wait'] || '';
            showTip(str);
            return
        }
        this.hjkOperate.hideAll();
    }

    // 加倍
    async doublePoker(){
        let data = await this.hjkEvent.doactionReq(ActionType.DOUBLE);
        if (data.errcode===19) {
            let actType = this.hjkEvent.actionNtcData.action_type;
            // actType = actType^ActionType.DOUBLE;
            this.hjkOperate.showOperate(actType);
            let str = i18n.languages[g.language]['g_no_coin'] || '';
            showTip(str);
            return
        } else if (data.errcode!==null) {
            return
        }
        this.playerMgr.stopCountdown(this.hjkEvent.mySeatInfo.index);
        this.hjkOperate.hideAll();
    }

    getMax(arr: number[]){
        let num = arr[0];
        for (let i = 0; i < arr.length; i++) {
            if (arr[i]>num && arr[i]<= sum_upperlimit) {
                num = arr[i]
            }
        }
        return num;
    }
    
    /**
     * 计算点数并返回 return [min, max]
     * @param cards 
     */
    calcPoint(cards: number[]){
        let points: number[][] = [];
        let min = 0, max = 0, score = 0;
        if (cards==null || cards.length===0) {
            return [min, max];
        }
        for (let i = 0; i < cards.length; i++) {
            let p = CardsPoint[cards[i]];
            if (!p) continue;
            if (p instanceof Array) {
                points.push(p);
            }else{
                score += p;
            }
        }
        min = score, max = score;
        for (let i = 0; i < points.length; i++) {
            let A_points = points[i];
            if (sum_upperlimit - max >= A_points[1]) {
                max += A_points[1];
            }else{
                max += A_points[0];
            }
            min += A_points[0];
        }
        // cc.log([min, max])
        return [min, max];
    }

    transChips(num: number){
        let totalNum = num;
        let chipVals = [0.1, 0.2, 0.5, 1, 2, 5];
        let chips = [];
        if (totalNum <= 0)  {
            return chips;
        }
        let multiple = decimal(BetLimit[g.curBetLimit].min).div(decimal(chipVals[0]))
        for (let i = chipVals.length-1; i >= 0; i--) {
            let val = decimal(chipVals[i]).mul(multiple).toNumber();
            if (totalNum >= val) {
                let count = Math.floor(decimal(totalNum).div(decimal(val)).toNumber());
                for (let j = 0; j < count; j++) {
                    chips.push(val);
                }
                totalNum = parseFloat(decimal(totalNum).mod(decimal(val)).val());
                // cc.log('==== ', totalNum);
                if (totalNum<=0) break
            }else{
                continue;
            }
        }
        return chips;
    }

    private walletAnim() {
        if (this._menuBgPlayingAnim) {
            return;
        }
        this._menuBgPlayingAnim = true;
        let scaleY = this.touchWallet.scaleY===0 ? 1 : 0;
        cc.tween(this.touchWallet).to(0.1, {scaleY: scaleY}).call(()=>{this._menuBgPlayingAnim=false}).start();
    }

    private onClickWallet() {
        if (nullToZero(GameData.tbBaseInfo.coins)<=0 && nullToZero(GameData.tbBaseInfo.e_wallet)<=0) {
            return;
        }
        this.hjkAudio.playBtn1();
        this.menuBg.scaleY = 0;
        this.walletAnim();
    }

    private menuAnim(){
        this.touchWallet.scaleY = 0;
        if (this._menuBgPlayingAnim) {
            return;
        }
        this._menuBgPlayingAnim = true;
        let scaleY = this.menuBg.scaleY===0 ? 1 : 0;
        cc.tween(this.menuBg).to(0.1, {scaleY: scaleY}).call(()=>{this._menuBgPlayingAnim=false}).start();
    }
    
    private onClickMenu() {
        this.hjkAudio.playBtn1();
        this.menuAnim();
    }

    private onClickGameInfo() {
        this.hjkAudio.playBtn1();
        this.menuAnim();
        this.gameInfo.node.active = true;
        this.gameInfo.init();
    }

    private onClickAudio() {
        shiftSound();
        let audioSprite = soundCfg()>0 ? LangSprite.lb_close_audio : LangSprite.lb_open_audio;
        loadSprite(this.audioSp, audioSprite)
        this.hjkAudio.playBtn1();
    }

    private onClickHistory() {
        this.hjkAudio.playBtn1();
        this.menuAnim();
        if (GameData.tbBaseInfo.user_type===-1) {   // 游客
            let str = i18n.languages[g.language]['g_visitors_cannot'] || '';
            showConfirm({ content: str, sure: true });
            return
        }
        this.hjkHistory.node.active = true;
        this.hjkHistory.init();
    }

    private onClickRoad(){
        this.hjkAudio.playBtn1();
        this.menuBg.scaleY = 0
        this.touchWallet.scaleY = 0;
        this.hjkRoad.node.active = true;
        this.hjkRoad.initUI();
    }

    private async onClickBack() {
        this.hjkAudio.playBtn1();
        showLoading();
        let data = await this.hjkEvent.leaveTableReq();
        hideLoading();
        if (data.errcode===null) {
            g.postLeaveRoom();
            cc.director.loadScene(g.LOBBY_SCENE);
        } else if(data.errcode===27) {
            let str = i18n.languages[g.language]['g_not_quit'] || '';
            showTip(str);
        }
    }

    onDestroy(){
        clearTimeout(this.timeoutId1);
        clearTimeout(this.timeoutId2);
    }
}
