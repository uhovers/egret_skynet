const {ccclass, property} = cc._decorator;

interface mapObj {
    startPos?: number, 
    endPos?: number
};

@ccclass
export default class TableView extends cc.Component {

    public itemData = undefined;
    private scrollView: cc.ScrollView = undefined;
    private item: cc.Prefab = undefined;
    private itemInterval: number = 0;
    private scrollViewCanFix: boolean = true;

    private content: cc.Node = undefined;
    private layerHeight: number = undefined;
    private firstItemIndex = 0;
    private lastItemIndex = 0;
    private firstItemData: mapObj = undefined;
    private lastItemData: mapObj = undefined;
    private itemArr: cc.Node[] = [];
    private itemNode: cc.Node[] = [];
    private itemPosMap: Map<number, mapObj> = undefined;
    private initItemData = true;
    private itemCanMoveUp = false;
    private itemCanMoveDown = false;
    private lastTestTime = 0;
    private lastResetItemIndex = 0
    private lastResetItemInfoHeight = 0
    private count = 0;

    buildItem: (data, item) => void;

    /**
     * 
     * @param itemData tableview数据
     * @param scrollView cc.ScrollView
     * @param item cell
     * @param itemInterval 间距
     * @param scrollViewCanFix 是否自动修正
     * @param isSkipInit 
     */
    init(itemData: any, scrollView: cc.ScrollView, item: cc.Prefab, itemInterval: number, scrollViewCanFix: boolean, isSkipInit?: boolean){
        console.log('TableView init: ', itemData.length);
        if (!arguments[0] || itemData.length==0) {
            return false;
        }
        this.itemData = itemData;
        this.scrollView = scrollView;
        this.item = item;
        this.itemInterval = itemInterval || this.itemInterval;
        this.scrollViewCanFix = scrollViewCanFix || this.scrollViewCanFix;

        this.content = this.scrollView.content;
        this.layerHeight = this.scrollView.node.height;
        this.itemPosMap = new Map();
        if (isSkipInit) {
            return;
        }
        this.itemNode.push(cc.instantiate(this.item));

        cc.log(this.testTime(0));
        this.initItem();
        this.getItemPos(0);
        this.scrollView.node.on('scrolling', this.callback, this);
        cc.log('tableView结束:' + this.testTime());
    }

    getItemPos(index: number){
        for (let i = index; i < this.itemData.length; i++) {
            let obj: mapObj = {startPos: 0, endPos: 0};
            if (i===0) {
                obj.startPos = 0;
            } else {
                obj.startPos = this.itemPosMap.get(i - 1).endPos;
            }
            let j = this.itemData[i].pfbType||0;
            obj.endPos = obj.startPos + this.itemNode[j].height + this.itemInterval;
            this.itemPosMap.set(i, obj);
        }
        this.updateContentHeight(this.itemPosMap.get(this.itemData.length - 1).endPos);
    }

    initItem(){
        // 实例化所有用到的item，j控制实例化item的数目,暂定超出两个
        let j = 0;
        for (let i = 0; i < this.itemData.length; i++) {
            if (this.content.height > this.layerHeight) {
                j++;
                if (j > 2) break;
            }
            let y;
            if (i === 0) {
                y = 0
            } else {
                y = this.itemArr[i-1].y - this.itemArr[i-1].height - this.itemInterval;
            }
            this.addItemNode(i, y);
            this.updateContentHeight(this.itemArr[i].height - y);
        }
    }

    addItemNode(i: number, y: number){
        let pfbType = this.itemData[i].pfbType||0;
        let item = cc.instantiate(this.itemNode[pfbType]);
        item.parent = this.content;
        item['index'] = i;
        item['pfbType'] = pfbType;
        if (i===0) {
            item.y = 0;
        } else {
            item.y = y;
        }
        item.x = 0;
        // item.getComponent(Item).init(this.itemData[i], this);
        this.buildItem(this.itemData[i], item);
        this.itemArr.push(item);
        // console.log(item);
        // cc.log('生成itemNode: ' + i);
    }

    updateContentHeight(num){
        this.content.height = num > this.layerHeight ? num : this.layerHeight;
        // cc.log('滚动条高度:', this.content.height);
    }

    //触摸滚动条的函数回调
    //第一,滚动条
    callback(event, eventType) {
        // cc.log(event && event.type || eventType)
        if (this.content.height > this.layerHeight) {
            let firstItemPos = this.scrollView.getScrollOffset().y;
            let lastItemPos = firstItemPos + this.layerHeight;
            if (firstItemPos < 0) return;
            if (this.initItemData) {
                this.initItemData = false;
                this.updateFirstItemIndex(firstItemPos);
                this.itemCanMoveDown = true;
                this.updateLastItemIndex(lastItemPos);
                this.itemCanMoveDown = false;
            }

            //超出边界直接返回.
            //滚动条向上滑动可能会触发的函数
            if (firstItemPos > this.firstItemData.endPos) {
                if (this.lastItemIndex + 1 < this.itemData.length) {
                    this.updateFirstItemIndex(firstItemPos);
                }
                this.count++;
            }
            if (lastItemPos > this.lastItemData.endPos) {
                if (this.lastItemIndex + 1 < this.itemData.length) {
                    this.itemCanMoveDown = true;
                    this.updateLastItemIndex(lastItemPos);
                    this.itemCanMoveDown = false;
                }
            }
            //滚动条向下滑动可能会触发的函数
            if (lastItemPos < this.lastItemData.startPos) {
                this.updateLastItemIndex(lastItemPos);
                this.count--;
            }
            if (firstItemPos < this.firstItemData.startPos) {
                this.itemCanMoveUp = true;
                this.updateFirstItemIndex(firstItemPos);
                this.itemCanMoveUp = false;
            }

        }

    }

    updateFirstItemIndex(pos?: number) {
        let num = this.firstItemIndex;
        if (this.itemCanMoveUp && num > this.getItemIndex()[0] && num > 0) {
            this.itemMoveUp(this.firstItemIndex - 1);
        }
        this.updateItemIndex();
    }

    updateLastItemIndex(pos?: number) {
        let num = this.lastItemIndex;
        if (this.itemCanMoveDown && num < this.getItemIndex()[1] && num + 1 < this.itemData.length) {
            this.itemMoveDown(this.lastItemIndex + 1);
        }
        this.updateItemIndex();
    }

    testTime(time?: number) {
        let t=new Date().getTime()
        this.lastTestTime = this.lastTestTime || t;
        let timestamp = new Date().getTime() - this.lastTestTime;
        return timestamp
    }

    updateItemIndex() {
        //cc.log(this.firstItemIndex, this.lastItemIndex, this.itemArr, this.itemData)
    }

    //得到滚动条此时状态下应有的itemNode元素,包括滚动条上方一个,滚动条下方一个.
    getItemIndex() {
        let firstItemPos = this.scrollView.getScrollOffset().y;
        let lastItemPos = firstItemPos + this.layerHeight;
        let arr = [];
        for (let [key, value] of this.itemPosMap.entries()) {
            //判断状态的位置关系是[);
            let status1 = value.startPos <= firstItemPos && value.endPos > firstItemPos;
            let status2 = value.startPos >= firstItemPos && value.endPos < lastItemPos;
            let status3 = value.startPos <= lastItemPos && value.endPos > lastItemPos;
        
            if (status1) {
                this.firstItemData = value;
                this.firstItemIndex = key;
                arr.push(key);
            }
            if (status3) {
                this.lastItemData = value;
                this.lastItemIndex = key;
                arr.push(key);
            }
        }
        return arr;
    }

    //firstIndex 滚动条顺序是从上到下开始遍历
    itemMoveUp(num) {
        if (num < 0 || this.lastItemIndex + 1 < num || num + 1 > this.itemData.length) {
            return;
        }
        if (!this.hasItem(num)) {
            this.itemMove(num, -this.itemPosMap.get(num).startPos);
        }
        num++;
        return this.itemMoveUp(num);

    }

    itemMoveDown(num) {
        if (num < 0 || this.firstItemIndex - 1 > num || num + 1 > this.itemData.length) {
            return;
        }
        if (!this.hasItem(num)) {
            this.itemMove(num, -this.itemPosMap.get(num).startPos);
        }
        num--;
        return this.itemMoveDown(num);

    }

    //判断指定index位置是否存在itemNode.
    hasItem(index) {
        for (let i = 0; i < this.itemArr.length; i++) {
            if (this.itemArr[i]['index'] === index) {
                return true;
            }
        }
        return false;
    }

    //得到要移动的item的索引index,
    //逻辑判断,第一种情况,修改itemArr数组的某个对象,第二种情况实例化一个新itemNode
    itemMove(index, y) {
        for (let i = 0; i < this.itemArr.length; i++) {
            //index存在-1的情况,类似于在缓存池里的item.
            let status1 = this.itemArr[i]['index'] < this.firstItemIndex - 1 ? true : false;
            let status2 = this.itemArr[i]['index'] > this.lastItemIndex + 1 ? true : false;
            let status3 = this.itemArr[i]['pfbType'] === this.itemData[index].pfbType;
            //cc.log('item的索引', this.firstItemIndex, this.lastItemIndex)
            if (status1 && status3 || status2 && status3) {
                //cc.log(i, index, this.itemArr, this.content.height);
                //给item赋值还有设置位置
                this.itemArr[i]['index'] = index;
                this.itemArr[i].y = y;
                // this.itemArr[i].getComponent(Item).init(this.itemData[index], this);
                this.buildItem(this.itemData[index], this.itemArr[i]);
                return;
            }
        }
        this.addItemNode(index, y);
    }

    //得到相关位置的排序index
    getPosIndex(pos) {
        for (let [key, value] of this.itemPosMap.entries()) {
            if (value.endPos > pos && value.startPos <= pos) {
                return key;
            }
        }
    }

    addItem(obj) {
        this.itemData.push(obj);
        this.getItemPos(this.itemData.length - 1);
        let endPos = this.itemPosMap.get(this.itemData.length - 1).endPos;
        if (endPos - this.layerHeight > 0) {
            let startPos = endPos - this.layerHeight;
            //得到当前的firstItemIndex;
            for (let i = this.itemData.length - 1; i >= 0; i--) {
                if (this.itemPosMap.get(i).endPos > startPos && this.itemPosMap.get(i).startPos <= startPos) {
                    this.firstItemIndex = i;
                }
            }
            this.scrollView.scrollToBottom();
            this.lastItemIndex = this.itemData.length - 1;
            let num = this.firstItemIndex - 1 > 0 ? (this.firstItemIndex - 1) : 0;
            this.itemMoveUp(num);
            return true;
        } else {
            this.firstItemIndex = 0;
            this.lastItemIndex = this.itemData.length - 1;
            this.itemMoveUp(this.firstItemIndex);
            return false;
        }

    }

    clearItem() {
        this.itemData = [];
        this.itemPosMap.clear();
        this.scrollView.scrollToTop();
        this.content.height = 0;
        for (let i in this.itemArr) {
            this.itemArr[i]['index'] = -1;
            this.itemArr[i].y = 3000;
        }
    }

    deleteItem(i) {
        this.itemData.splice(i, 1);
        this.getItemPos(this.itemData.length - 1);

        //改变this.itemArr的内容
        for (let j = 0; j < this.itemArr.length; j++) {
            if (this.itemArr[j]['index'] === i) {
                this.itemArr[j]['index'] = -1;
                this.itemArr[j].y = 3000;
            }
            if (this.itemArr[j]['index'] > i) {
                let num = this.itemArr[j]['index'];
                // //cc.log(j,this.itemArr[j]['index'])
                this.itemArr[j].y = -this.itemPosMap.get(num - 1).startPos;
                this.itemArr[j]['index'] = num - 1;
                //cc.log(this.itemArr[j]['index'], this.itemArr[j].y)
            }
        }
        this.updateContentHeight(this.itemPosMap.get(this.itemData.length - 1).endPos);
        this.itemMoveUp(this.firstItemIndex);
    }

    resetItemData(index) {
        for (let i = 0; i < this.itemArr.length; i++) {
            if (this.itemArr[i]['index'] === index) {
                // let js = this.itemArr[i].getComponent(Item);
                // js.init(this.itemData[index], this);
                this.buildItem(this.itemData[index], this.itemArr[i]);
                break;
            }
        }
    }

    resetItemSize(index, infoHeight) {
        let func = (function (index, infoHeight) {

            for (let i = 0; i < this.itemArr.length; i++) {
                if (this.itemArr[i]['index'] > index) {
                    this.itemArr[i].y -= infoHeight;
                }
            }

            for (let [key, value] of this.itemPosMap.entries()) {
                if (key === index) {
                    value.endPos += infoHeight;
                }
                if (key > index) {
                    value.endPos += infoHeight;
                    value.startPos += infoHeight;
                }
            }
            this.lastResetItemInfoHeight = infoHeight;
            this.lastResetItemIndex = index;
        }).bind(this);
        if (this.lastResetItemIndex !== null && this.lastResetItemInfoHeight) {
            if (this.lastResetItemIndex === index) {
                func(this.lastResetItemIndex, -this.lastResetItemInfoHeight);
                this.lastResetItemIndex = null;
                this.lastResetItemInfoHeight = 0;
            } else {
                func(this.lastResetItemIndex, -this.lastResetItemInfoHeight);

                func(index, infoHeight);
            }
        } else {
            func(index, infoHeight);
        }
        this.itemMoveUp(this.firstItemIndex);
        this.updateContentHeight(this.itemPosMap.get(this.itemData.length - 1).endPos);
    }

}
