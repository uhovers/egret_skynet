import { EVENTTYPE } from "./enum";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Base extends cc.Component {
    onAppEvent(eventype: EVENTTYPE, data){
        
    }
}
