import { DevStatus } from "./enum"

interface url{
    ip: string,
    port: string,
}

/**
 * 生产环境 服务器列表
 */
// 47.244.219.252:19501
export const DEFAULT_IP = [
    {ip:"blackjack.sxyirun.cn", port:''},
]


/**
 * 本地服务器列表
 */
export const LOC_SERVER = {
    HJL: {ip:"192.168.0.38", port: '29501'},
    HJL2: {ip:"192.168.0.38", port: '28501'},
    ZCK: { ip:"192.168.0.39", port: '28501'},
    L243: {ip:"121.40.230.243", port: '11301'},
    wln: {ip:"192.168.2.166", port: '28501'},
}

//  121.40.230.243 11301
/**
 * 转发节点
 */
export const SERVER_NODE: { [n: string]: url[] } = {
    [DevStatus.LOCAL_DEV]: [LOC_SERVER.L243],
    [DevStatus.OUT_DEV]: [{ip:"cstest-api.21bjk.com", port: '19501'},],    // 预发布
    [DevStatus.OFFICIAL]: DEFAULT_IP,
}

export const BetLimit: {min: number, max: number}[] = [
    {min: 0.1, max: 5},
    {min: 1, max: 50},
    {min: 10, max: 500},
]

export const ChipColor: {[value: number]: string} = {
    0.1: '#1d97d0',
    0.2: '#029b75',
    0.5: '#79b617',
    1: '#c9990a',
    2: '#d93e3d',
    5: '#c428a1',
    10: '#7302b6',
    20: '#4360b8',
    50: '#27ae93',
    100: '#a8b430',
    200: '#d1a622',
    500: '#e05d09'
}

/**
 * 支持的语言
 */
export let SupportLang = {
    'en_us': true, //美式英语 US EN Reference
    'zh_cn': true, //简体中文
    'zh_tw': false, //繁體中文 (台灣)
    'ko_kr': true, // 韓語 Korean
    'ja_jp': false, //日語 Japanese
    'vi_vn': true, //越南語 Vietnamese
    'ms_my': false, //馬來語 Malay
    'in_id': false, //印度尼西亚 Indonesian
    'th_th': true, //泰語 Thai
    'zh_hk': false, //繁體中文 (香港)
    'km_kh': false, //柬埔寨文 Cambodia
    'pt_pt': false, //葡萄牙文 Portugal
    'es_es': false, //西班牙文 Spanish
    'my_mm': false, //缅甸文 Burmese
    'hi_in': false, //Hindī  (印地语：天城文)
    'ta_in': false, //Tamiḻ（坦米爾語）
    'de_de': false, //德語 German
    'fr_fr': false, //法語 French
    'tr_tr': false, //土耳其文 Turkish
}