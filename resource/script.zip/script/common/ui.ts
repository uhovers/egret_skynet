import Main from "../start/main";
import Loading from "../start/loading";
import Tips from "../start/tips";
import Confirm from "../start/confirm";

export const enum UI_ZORDER {
    BOTTOM = 1000,
    MIDDLE,
    TOP,
}

let main: Main;
function getMain() {
    if (!main) {
        main = cc.find("main").getComponent(Main);
    }
    return main;
}

/**
 * 显示加载转圈，可以附加文本信息
 * @param info 
 */
export function showLoading(info?: string): void {
    let canvas = cc.find("Canvas")
    if (!canvas) return
    let node = canvas.getChildByName('loading')
    if (!node) {
        let main = getMain()
        node = cc.instantiate(main.loading)
        canvas.addChild(node, UI_ZORDER.MIDDLE)
    }
    node.getComponent(Loading).showLoading();
}

/**
 * 隐藏加载转圈
 */
export function hideLoading() {
    let canvas = cc.find("Canvas")
    if (!canvas) return
    let node = canvas.getChildByName('loading')
    if (node) {
        node.getComponent(Loading).hideLoading();
    }
}

/**
 * 显示文本信息
 * @param info 
 */
export function showTip(info?: string): void {
    let canvas = cc.find("Canvas")
    if (!canvas) return
    let node = canvas.getChildByName('tips')
    if (!node) {
        let main = getMain()
        node = cc.instantiate(main.tips)
        canvas.addChild(node, UI_ZORDER.TOP)
    }
    node.getComponent(Tips).showTip(info)
}

/**
 * 显示提示框
 */
export function showConfirm(data: {title?: string, content: string, icon?: number, cancel?: boolean, sure?: boolean}): Confirm{
    let canvas = cc.find("Canvas")
    if (!canvas) return
    let node = canvas.getChildByName('confirm')
    if (!node) {
        let main = getMain()
        node = cc.instantiate(main.confirm)
        canvas.addChild(node, UI_ZORDER.TOP)
    }
    let confirm = node.getComponent(Confirm);
    confirm.showConfirm(data)
    return confirm;
}