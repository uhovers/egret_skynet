import { SAVEKEY } from "./enum";
import g from "../g";
import { numToBigNum } from "./Helper";
// import { copyStr } from "./app";

export function nullToZero(num): number{
    return (num===null || num===undefined) ? 0 : num;
}

/**
 * 处理转换json对象
 * @param str
 * @returns 返回一个对象，至少都是一个{}， 出错时，返回undefined
 */
export function toj<T>(str: string) {
    let data: T
    try { data = JSON.parse(str) }
    catch (err) {
        cc.log("转json出错")
        cc.error(err)
    }
    return data
}

/**
 * 处理转换json对象到string
 * @param obj
 * @returns {string}
 */
export function tos(obj: Object) {
    return JSON.stringify(obj)
}

/**
 * 随机 min-max 之间所有整数；max不存在时为0-min之间
 * @param min 
 * @param max
 */
export function randomArray(min: number): number[]
export function randomArray(min: number, max: number): number[]
export function randomArray(min: number, max?: number){
    let start = max ? min : 0;
    let end = max ? max : min
    let ary = [];                    //创建一个空数组用来保存随机数组
    for(let i=start; i<end; i++){            //按照正常排序填充数组
        ary.push(i);
    }
    ary.sort(function(){
        return 0.5-Math.random();        //返回随机正负值
    });
    return ary;   //返回数组                  
}

/**
 * 闭区间[min,max]随机整数
 */
export function random(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

export function randomMinus1To1() {
    return (Math.random() - 0.5) * 2
}

/**
 * 随机(min到max)小数
 */
export function randf(max: number): number
export function randf(min: number, max: number): number
export function randf(min: number, max?: number): number {
    if (max === undefined) {
        max = min
        min = 0
    }
    if (min > max) {
        min = max + min
        max = min - max
        min = min - max
    }
    let r = Math.random()
    let a = r * (Math.round(Math.random()) ? -1 : 1)
    return (a / 2 + 0.5) * (max - min) + min
}

export function addSingleEvent(btn: cc.Button, h: cc.Component.EventHandler) {
    if (btn.clickEvents.filter(e => e.component === h.component && e.target === h.target && e.handler === h.handler).length === 0) {
        btn.clickEvents.push(h);
    }
}

/**
 * 是否是iphoneX
 */
export function isIphoneX() {
    if (cc.sys.isNative && cc.sys.os === cc.sys.OS_IOS) {
        let size = cc.view.getFrameSize();
        let isIphoneX = (size.width == 2436 && size.height == 1125) || (size.width == 1125 && size.height == 2436);
        return isIphoneX;
    }
    return false;
}

export function fitCanvas(nodeCanvas: cc.Node) {
    if (!nodeCanvas) {
        return;
    }
    let size = cc.view.getFrameSize();
    let r = size.height / size.width;
    let canvas: cc.Canvas = nodeCanvas.getComponent(cc.Canvas);
    cc.log('fitCanvas r: ', r, size);
    let desSize = g.isLandscape ? cc.size(960, 540) : cc.size(540, 960);
    
    if (g.isLandscape) {
        if (r > 0.5625) {
            canvas.designResolution = desSize;
            canvas.fitHeight = false;
            canvas.fitWidth = true;
        } else {
            canvas.designResolution = desSize;
            canvas.fitHeight = true;
            canvas.fitWidth = false;
        }
    } else {
        if (r > 1.777) {
            canvas.designResolution = desSize;
            canvas.fitHeight = false;
            canvas.fitWidth = true;
        } else {
            canvas.designResolution = desSize;
            canvas.fitHeight = true;
            canvas.fitWidth = false;
        }
    }
}

/**
 * 更换对应语言的资源
 * @param sprite cc.Sprite
 * @param path 资源路径
 */
export function loadSprite(sprite: cc.Sprite, path: string) {
    return new Promise(resolve => {
        cc.resources.load(`font/${g.language}/${path}`, cc.SpriteFrame, (err, spriteFrame: cc.SpriteFrame)=>{
            // cc.log(`font/${g.language}/${path}`, spriteFrame);
            // cc.log('****',sprite)
            // cc.log('====== ', err, spriteFrame);
            if (sprite && spriteFrame) {
                sprite.spriteFrame = spriteFrame;
            }
            resolve();
        });
    });
}

let add0 = function (m) { return m < 10 ? '0' + m : m };

//秒数转成显示的时钟格式mm:ss
export function formatSeconds(time: number) {
    time = Math.floor(time);
    if (time <= 0) return "00:00"
    let m = Math.floor(time / 60);
    let s = time % 60;
    return ((m < 10) ? ("0" + m) : m) + ":" + ((s < 10) ? ("0" + s) : s);
}

/**
 * 格式化输出当前本地时间
 * @param 时间精度
 * d:日  m:分  s:秒  ms:毫秒
 *
 * @param 指定时间
 */
export function formatTimeStr(prec: 'd' | 'm' | 's' | 'ms', date?: string | number) {
    let d: Date = date ? new Date(date) : new Date()
    let str = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`
    // let str = '';
    if (prec === 'd') return str
    str += `\n${add0(d.getHours())}:${add0(d.getMinutes())}`
    if (prec === 'm') return str
    str += `:${add0(d.getSeconds())}`
    if (prec === 's') return str
    str += `:${d.getMilliseconds()}`
    if (prec === 'ms') return str
}

/**
 * 拷贝文本
 * @export
 * @param {string} str
 * @returns
 */
export function setClipboard(str: string) {
    let rst: boolean
    if (cc.sys.isNative) {
        // rst = copyStr(str);
        // rst = jsb.copyTextToClipboardAPI(str)
    } else {
        let el = document.createElement("textarea")
        el.style.position = 'fixed'
        el.style.width = '2em'//不要改成0，否则不成功
        el.style.height = '2em'//不要改成0，否则不成功
        el.style.background = 'transparent'
        el.value = str
        document.body.appendChild(el)
        el.select()
        rst = document.execCommand('copy')
        document.body.removeChild(el)
    }
    return rst
}

// 存储设置（music：2位，sound：1位），扩展震动：3位
let EffectCfg = 3
export function musicCfg() {
    return (EffectCfg >> 1) & 0b01
}
export function soundCfg() {
    return EffectCfg & 0b01
}
export function loadEffectCfg() {
    let r = cc.sys.localStorage.getItem(SAVEKEY.EFFECT)
    if (r == null)
        EffectCfg = 3
    else
        EffectCfg = r
}
/**
 * 开关音乐
 */
export function shiftMusic() {
    let n = 2
    EffectCfg = EffectCfg ^ (1 << (n - 1))// n位取非
    cc.sys.localStorage.setItem(SAVEKEY.EFFECT, EffectCfg)
}
/**
 * 开关音效
 */
export function shiftSound() {
    EffectCfg = EffectCfg ^ 1
    cc.sys.localStorage.setItem(SAVEKEY.EFFECT, EffectCfg)
}

export function getDistance(startPos: cc.Vec3, endPos: cc.Vec3) {
    return startPos.sub(endPos).mag();
}

export function transMoney(money: number){
    if (money<100000) {
        return numToBigNum(money);
    } else if(money < 1000000) {
        return numToBigNum(money/1000)+'k';
    }else{
        return numToBigNum(money/1000000)+'m';
    }
}

/**
 * 获取url的数据
 * @param url 获取数据的url
 * @param timeout 设置超时，默认5秒。
 * @returns 非空是数据，空是错误。
 */
export function getUrlData(url: string, timeout: number = 5000) {
    return new Promise((resolve: (ret?: any) => void) => {
        cc.log(("url: " + url))
        let xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function (event: Event) {
            if (xhr.readyState === 4) {
                if (xhr.status >= 200 && xhr.status < 400) {
                    let ret;
                    try {
                        ret = JSON.parse(xhr.responseText);
                    } catch (error) {
                        cc.log("-----------JSON.parse err ----------" + url)
                        resolve();
                    }
                    cc.log("获取:" + url + "数据:", ret);
                    if (ret)
                        resolve(ret);
                } else {
                    resolve();
                }
            }
        };
        xhr.timeout = timeout;
        xhr.ontimeout = function () {
            cc.log("获取超时:" + url);
            resolve();
        };
        xhr.onerror = function () {
            cc.log("获取失败:" + url);
            resolve();
        };
        xhr.open("GET", url);
        xhr.send();
    });
}

/**
* [获取URL中的参数名及参数值的集合]
* 示例URL:http://htmlJsTest/getrequest.html?uid=admin&rid=1&fid=2&name=小明
* @param {[string]} urlStr [当该参数不为空的时候，则解析该url中的参数集合]
* @return {[string]}       [参数集合]
*/
export function GetRequest(urlStr: string) {
    let url: string;
    if (typeof urlStr == "undefined") {
        url = decodeURI(location.search); //获取url中"?"符后的字符串
    } else {
        url = "?" + urlStr.split("?")[1];
    }
    if (urlStr.split("?")[1]==undefined) {
        return undefined;
    }
    
    let theRequest = new Object();
    if (url.indexOf("?") != -1) {
        let str = url.substr(1);
        let strs = str.split("&");
        for (let i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURIComponent(decodeURI(strs[i].split("=")[1]));
        }
    }
    return theRequest;
}