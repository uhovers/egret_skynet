/**
 * 當地環境 (語系) 設置表
 *
 * 如果只是想取得 語系代碼 清單
 * 可以使用 Object.keys( CONST.localeSettingList );
 */
export const localeSettingList = {
    en_us: {   // 00 美式英語
        code: 'en_us',              // 系統使用的語言代碼 (由 語言代碼 與 國家或地區代碼 組成) (全小寫)
        localeName: 'English',      // 當地的語言名稱 (用該語系來呈現的 語言名稱) (常用於介面選單的呈現)
        language: 'en',             // 語言代碼 (ISO 639-1) (由兩個字母組成) (全小寫) (作為翻譯時的選項代碼)
        territory: [ 'US' ],        // 國家或地區代碼 (ISO 3166-1) (由兩個字母組成) (全大寫) (同一個語言，可能會在很多地區使用，所以要使用陣列來表示)
        sbDP: '.',                  // 小數點 符號 (Symbol : Decimal Point) (常用於金額等數值的呈現)
        sbTS: ','                   // 千分位 符號 (Symbol : Thousandth) (常用於金額等數值的呈現)
    },
    zh_cn: {   // 01 簡體中文
        code: 'zh_cn',
        localeName: '简体中文',
        language: 'zh',
        territory: [ 'CN' ],
        sbDP: '.',
        sbTS: ','
    },
    zh_hk: {   // 02 粵語 (香港)
        code: 'zh_hk',
        localeName: '粵語',
        language: 'zh',
        territory: [ 'HK' ],
        sbDP: '.',
        sbTS: ','
    },
    zh_tw: {   // 03 繁體中文
        code: 'zh_tw',
        localeName: '繁體中文',
        language: 'zh',
        territory: [ 'TW' ],
        sbDP: '.',
        sbTS: ','
    },
    ms_my: {   // 04 馬來語 (馬來西亞)
        code: 'ms_my',
        localeName: 'Bahasa Malayu',
        language: 'ms',
        territory: [ 'MY' ],
        sbDP: '.',
        sbTS: ','
    },
    vi_vn: {   // 05 越南語
        code: 'vi_vn',
        localeName: 'Tiếng Việt',
        language: 'vi',
        territory: [ 'VN' ],
        sbDP: '.',
        sbTS: ','
    },
    ko_kr: {   // 06 韓國語
        code: 'ko_kr',
        localeName: '한국어',
        language: 'ko',
        territory: [ 'KR' ],
        sbDP: '.',
        sbTS: ','
    },
    ja_jp: {   // 07 日本語
        code: 'ja_jp',
        localeName: 'にほんご',
        language: 'ja',
        territory: [ 'JP' ],
        sbDP: '.',
        sbTS: ','
    },
    in_id: {   // 08 印尼語
        code: 'in_id',
        localeName: 'Indonesia', // 'Bahasa Indonesia', // 'भारत',
        language: 'in',
        territory: [ 'ID' ],
        sbDP: ',',  // 注意：印尼   用 '.' 表示千分位符號   用 ',' 表示小數點符號
        sbTS: '.'
    },
    th_th: {   // 09 泰語
        code: 'th_th',
        localeName: 'ภาษาไทย', // 'ไทย',
        language: 'th',
        territory: [ 'TH' ],
        sbDP: '.',
        sbTS: ','
    },
    pt_pt: {   // 10 葡萄牙語
        code: 'pt_pt',
        localeName: 'Português',
        language: 'pt',
        territory: [ 'PT' ],
        sbDP: '.',
        sbTS: ','
    },
    km_kh: {   // 11 高棉語 (柬埔寨)
        code: 'km_kh',
        localeName: 'ភាសាខ្មែរ',
        language: 'km',
        territory: [ 'KH' ],
        sbDP: '.',
        sbTS: ','
    },
    my_mm: {   // 12 缅甸语 (缅甸)
        code: 'my_mm',
        localeName: 'မြန်မာဘာသာ',
        language: 'my',
        territory: [ 'MM' ],
        sbDP: '.',
        sbTS: ','
    },
    es_es: {   // 13 西班牙语 (西班牙)
        code: 'es_es',
        localeName: 'Español',
        language: 'es',
        territory: [ 'ES' ],
        sbDP: '.',
        sbTS: ','
    },
    hi_in: {   // 天城文 (印度)
        code: 'hi_in',
        localeName: 'हिन्दी',
        language: 'hi',
        territory: [ 'IN' ],
        sbDP: '.',
        sbTS: ','
    },
    ta_in: {   // 坦米爾語 (印度)
        code: 'ta_in',
        localeName: 'தமிழ்',
        language: 'ta',
        territory: [ 'IN' ],
        sbDP: '.',
        sbTS: ','
    },
    fr_fr: {  // https://en.wikipedia.org/wiki/French_language
        code: 'fr_fr',
        localeName: 'français',
        language: 'fr',
        territory: [ 'FR' ],
        sbDP: '.',
        sbTS: ','
    },
    de_de: {  // https://en.wikipedia.org/wiki/German_language
        code: 'de_de',
        localeName: 'Deutsch',
        language: 'de',
        territory: [ 'DE' ],
        sbDP: '.',
        sbTS: ','
    },
    tr_tr: {  // 土耳其 Turkish tr_TR https://en.wikipedia.org/wiki/Turkish_language
        code: 'tr_tr',
        localeName: 'Türkçe',
        language: 'tr',
        territory: [ 'TR' ],
        sbDP: '.',
        sbTS: ','
    }
};