
/**
 * 开发状态列表
 */
export const enum DevStatus {
    LOCAL_DEV,  // 内网
    OUT_DEV,    // 外网
    OFFICIAL,   // 正式
}

export enum NetEnum{
    WS_CONNECTING=0,                // 连接中
	WS_OPEN=1,                      // 已连接
	WS_CLOSEING=2,                  // 关闭中
	WS_CLOSED=3,               	    // 已关闭
	WS_NONE_INIT=4,            	    // 未初始化
	WS_TIME_OUT=5,                  // 连接超时
	WS_CONNECTION_FAILURE=6,        // 连接失败
	WS_UNKNOWN_ERROR=7,             // 未知错误
	WS_ENTER_FOREGROUND=8,          // 客户端转前台
	WS_ENTER_BACKGROUND=9,          // 客户端转后台
	WS_CLIENT_NEED_RECONNECT = 10,  // 客户端需要强制断线重连
}

export enum SAVEKEY{
    DEVICEONLY = "DEVICEONLY",
    LOGINACCOUNT = "LOGINACCOUNT",
    EFFECT = "EFFECT",
    hotUpdateTime = "hotUpdateTime",
}

//弹窗类型
export enum MsgBoxType{
    OKC = 0,
    OK = 1,
    CACEL = 2
}

export enum EVENTTYPE{
    EVENT_LoginRes = "loginres",
    EVENT_EnterGameRes = "EVENT_EnterGameRes",
    EVENT_LOADING_LAYER = "EVENT_LOADING_LAYER",
    EVENT_GoodsNtc = "GoodsNtc",
    EVENT_BlackJack21_tablesNtc = "BlackJack21_tablesNtc",
    EVENT_ReenterTableNtc = "ReenterTableNtc",
    EVENT_GameStartNtc = "GameStartNtc",
    EVENT_SitdownTableNtc = "SitdownTableNtc",
    EVENT_StandupTableNtc = "StandupTableNtc",
    EVENT_DoactionNtc = "DoactionNtc",
    EVENT_DoactionResultNtc = "DoactionResultNtc",
    EVENT_DealCardsNtc = "DealCardsNtc",
    EVENT_GameEndResultNtc = "GameEndResultNtc",
    EVENT_NoticeClientNtc = "NoticeClientNtc",
    EVENT_BlackJack21_tablesRes = "BlackJack21_tablesRes",
    EVENT_PLAYER_TEMPLEAVE_BACK = "EVENT_PLAYER_TEMPLEAVE_BACK",
}

// 每张牌的key
export const CardsKey = [
    0,1,2,3,
    4,5,6,7,
    8,9,10,11,
    12,13,14,15,
    16,17,18,19,
    20,21,22,23,
    24,25,26,27,
    28,29,30,31,
    32,33,34,35,
    36,37,38,39,
    40,41,42,43,
    44,45,46,47,
    48,49,50,51,
]

// 每张牌对应的牌风
export const CardsValue = [
    2,2,2,2,
    3,3,3,3,
    4,4,4,4,
    5,5,5,5,
    6,6,6,6,
    7,7,7,7,
    8,8,8,8,
    9,9,9,9,
    10,10,10,10,
    11,11,11,11,    // J
    12,12,12,12,    // Q
    13,13,13,13,    // K
    14,14,14,14,    // A
]

// 每张牌的点数
export const CardsPoint = [
    2,2,2,2,
    3,3,3,3,
    4,4,4,4,
    5,5,5,5,
    6,6,6,6,
    7,7,7,7,
    8,8,8,8,
    9,9,9,9,
    10,10,10,10,
    10,10,10,10,    // J
    10,10,10,10,    // Q
    10,10,10,10,    // K
    [1,11],[1,11],[1,11],[1,11],    // A
]

/**
 * 玩家操作类型 1:下注  2:要牌  4:停牌 8:双倍下注 16:分牌 32:买保险 64:投降 128:休息 256:洗牌
 */
export enum ActionType {
    DEAL = 1, 
    HIT = 2,
    STAND = 4,
    DOUBLE = 8,
    SPLIT = 16,
    INSURE = 32,
    SURRENDER = 64,
    RESTING = 128,
    SHUFFLE = 256
}

/**
 * 动画名称
 */
export enum AnimName {
    /** 右手-收回桌面筹码 */
    BlackJack_shou1 ='21dian_shou1.plist',
    /** 右手-下注筹码到桌面 */
    BlackJack_shou2 ='21dian_shou2.plist',
    /** 右手-握拳 */
    BlackJack_shou3 ='21dian_shou3.plist',
    /** 右手-拨弄筹码 */
    BlackJack_shou4 ='21dian_shou4.plist',
    /** 右手-拍桌子 */
    BlackJack_shou5 ='21dian_shou5.plist',
    /** 右手-翻转筹码 */
    BlackJack_shou6 ='21dian_shou6.plist',
    /** 左手-拍桌子 */
    BlackJack_shou7 ='21dian_shou7.plist',
    /** 双手-鼓掌 */
    BlackJack_shou8 ='21dian_shou8.plist',
    /** 右手-打响指 */
    BlackJack_shou9 ='21dian_shou9.plist',
    /** 右手-竖拇指 */
    BlackJack_shou10 ='21dian_shou10.plist',
    /** 右手-砸桌子 */
    BlackJack_shou11 ='21dian_shou11.plist',
    /** 右手-不要（摇手指） */
    BlackJack_shou12 ='21dian_shou12.plist',
}
