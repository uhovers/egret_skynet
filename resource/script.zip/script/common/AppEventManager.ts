import Base from "./Base";
import { EVENTTYPE } from "./enum";

interface eventMap {
    callback: Function,
    target: cc.Component
}

class AppEventManager {

    _eventMap: {[type: string]: eventMap[]} = {}
    
    _eventHandler: Base[] = []

    on(type: string, _callback: Function, _target: cc.Component) {
        if (this._eventMap[type] === undefined) {
            this._eventMap[type] = [];
        }
        this._eventMap[type].push({ callback: _callback, target: _target });
    }

    emit(type: string, parameter) {
        let array = this._eventMap[type];
        if (array === undefined) return;

        for (let i = 0; i < array.length; i++) {
            let element = array[i];
            if (element) element.callback.call(element.target, parameter);
        }
    }

    off(type: string, callback: Function) {
        let array = this._eventMap[type];
        if (array === undefined) return;

        for (let i = 0; i < array.length; i++) {
            let element = array[i];
            if (element && element.callback === callback) {
                array[i] = undefined;
                break;
            }
        }
    }

    offType(type: string) {
        this._eventMap[type] = undefined;
    }

    addEventHandler(target: Base) {
        this._eventHandler.push(target);
    }

    removeEventHandler(target: Base) {
        for (let i = 0; i < this._eventHandler.length; i++) {
            let element = this._eventHandler[i];
            if (element == target) {
                this._eventHandler.splice(i, 1);
                break;
            }
        }
    }

    notifyEvent(eventtype: EVENTTYPE, data?) {
        for (let i = 0; i < this._eventHandler.length; i++) {
            let element = this._eventHandler[i];
            if (element.onAppEvent != null) {
                element.onAppEvent.call(element, eventtype, data);
            }
        }
    }
}

export default new AppEventManager()