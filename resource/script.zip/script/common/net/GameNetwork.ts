import * as GameWebSocket from './GameWebSocket';
import * as XXTea from './XXTea.js';
import * as Helper from '../Helper';

let response_state = {
    ERROR_OK: '0'
}

let Uint8ArrayToString = function (fileData) {
    let dataString = "";
    for (let i = 0; i < fileData.length; i++) {
        dataString += String.fromCharCode(fileData[i]);
    }
    return dataString
}

let stringToUint8Array = function (str) {
    let arr = [];
    for (let i = 0, j = str.length; i < j; ++i) {
        arr.push(str.charCodeAt(i));
    }

    let tmpUint8Array = new Uint8Array(arr);
    return tmpUint8Array
}

class NetworkCallback {
    
    request: string = undefined;

    /**
     *请求回调对方法
     *
     * @type {Function}
     * @memberof NetworkCallback
     */
    callback: Function = undefined;

    init(request: string, callback: Function){
        this.request = request;
        this.callback = callback;
    }
}

export default class GameNetwork extends GameWebSocket.GameWebSocketDelegate {
    
    _socket: GameWebSocket.GameWebSocket = undefined;
    
    _delegate = undefined;

    _requestSequenceId: number = undefined;

    /**
     * 接受服务器主动下发的response回调
     * key 表示BaseResponse.act
     * @type {Object.<string, function(object.<string, *>)>}
     */
    pushResponseCallback = {};

    /**
     * 根据seq保存Request和其callback，以便在收到服务器的响应后回调
     * @type {Object.<int, NetworkCallback>}
     * @private
     */
    _networkCallbacks = {};

    _mSendmsgCache = {};

    _eventhandlerList = {};

    is_socket_close: boolean = undefined;

    cur_url: string = undefined;

    _pb: any  = undefined;

    constructor(){
        super()
        
        this._socket = undefined;

        this._delegate = undefined;

        this.pushResponseCallback = {};

        this._networkCallbacks = {};

        this._mSendmsgCache = {};

        this._eventhandlerList = {};

        this.is_socket_close = false

        this.cur_url = ""
    }

    setDelegate(delegate, pb: any){
        this._delegate = delegate;
        this._pb = pb;
    }

    addGlobalMsgHandler(target: any, handler: Function){
        this._eventhandlerList[target] = handler;
    }

    removeGlobalMsghandler(target: any) {
        this._eventhandlerList[target] = undefined;
    }

    /**
     * 注册服务器主动推送的response 回调
     */
    registerPushResponseCallback(act: any, callback: Function) {
        this.pushResponseCallback[act] = callback;
    }

    /**
     * 判断socket已连接成功，可以通信
     * @returns {boolean}
     */
    isSocketOpened(): boolean{
        return (this._socket && this._socket.getState() === GameWebSocket.GameWebSocketState.OPEN);
    }

    isSocketClosed(): boolean{
        return this._socket == null;
    }

    /**
     * 启动连接
     */
    connect(url: string) {
        cc.log("webSocketUrls=" + url);
        if (this.cur_url == url && (this.isSocketOpened() || (this._socket && this._socket.getState() == GameWebSocket.GameWebSocketState.CONNECTING))){
            cc.log("不需要重新连接")
            return;
        }
        this.cur_url = url;
        this._requestSequenceId = 0;
        this._socket = new GameWebSocket.GameWebSocket();
        this._socket.init(url, this);
        this._socket.connect();
    }

    closeConnect(){
        this.is_socket_close = true
        if (this._socket) {
            this._socket.close();
        }
    }

    onSocketOpen(){
        super.onSocketOpen()
        this.is_socket_close = false
        cc.log('Socket:onOpen');
        if (this._delegate && this._delegate.onNetworkOpen) {
            this._delegate.onNetworkOpen();
        }
    }

    msgUpdate(){
        if (this.isSocketOpened() && (!this.is_socket_close)) {
            if (Helper.getLength(this._mSendmsgCache) > 0) {
                for (let i in this._mSendmsgCache) {
                    if (this._mSendmsgCache.hasOwnProperty(i) && this._mSendmsgCache[i] != undefined) {
                        this._socket.send(this._mSendmsgCache[i]);
                        this._mSendmsgCache[i] = undefined;
                    }
                }
            }
        }
    }

    onSocketError(){
        this.is_socket_close = true
        cc.log('Socket:onError');
    }

    onSocketClosed(reason) {
        this.is_socket_close = true
        cc.log('Socket:onClose: ', reason);
        if (this._socket) {
            this._socket.close();
        }
        this._socket = null;
        if (this._delegate && this._delegate.onNetworkClose) {
            this._delegate.onNetworkClose();
        }
    }

    onSocketMessage(msg) {
        this._onResponse(msg);
    }

    _onResponse(responseData) {
        let self = this;

        if (!cc.sys.isNative) {
            let read = new FileReader();                                 //创建读取器对象FileReader
            read.readAsArrayBuffer(responseData);                                 //开始读取文件
            read.onload = function () {                             //数据读完会触发onload事件
                let resultData = new Uint8Array(read.result);
                self.onDecodeResMsg(resultData)
            }
        }else{
            self.onDecodeResMsg(new Uint8Array(responseData))
        }
        
    }

    onDecodeResMsg(resultData) {
        let self = this;
        //解密
        let ss = Uint8ArrayToString(resultData);
        ss = XXTea.decrypt(ss);
        resultData = stringToUint8Array(ss);

        // 提取前两个字节，包头长度
        let headLength = 0;
        let bNum = (resultData[0] & 0xff) << 8;
        let sNum = (resultData[1] & 0xff);
        headLength = bNum + sNum;
        let headData = resultData.slice(2, 2 + headLength)
        let bodyData = resultData.slice(2 + headLength, resultData.byteLength)

        let headPb = self._pb.ClientMsgHead.decode(Array.from(headData));
        let msgname = headPb.msgname;
        // cc.log("onmessage:"+msgname)
        if (self._pb[msgname] == null) {
            cc.log("msg out!");
            return
        }
        let bodyPb = self._pb[msgname].decode(Array.from(bodyData));
        // cc.log(JSON.stringify(bodyPb))

        //首先处理全局回调，因为有些全局变量需要首先赋值,后面再具体做处理
        for (let key in self._eventhandlerList) {
            self._eventhandlerList[key](msgname, bodyPb);
        }

        // 处理服务器推送消息
        let pushCallback = self.pushResponseCallback[msgname];
        if (pushCallback) {
            pushCallback(msgname, bodyPb);
        }

        // request回调
        let callbackObj = self._networkCallbacks[msgname];
        if (callbackObj) {
            callbackObj.callback(bodyPb);
        }
    }

    /**
     * 向服务器发送请求。
     *
     * 如果提供了callback，在收到response后会被回调。如果response是一个错误(status!=ERR_OK)，则需要决定由谁来负责处理错误。
     * 如果callback中已经对错误进行了处理，应该返回true，这样会忽略该错误。否则应该返回false，则负责处理该错误。
     *
     * 特别注意：如果这是一个异步(is_async)请求，且出错，一般来讲应该重新登录/同步。但是如果callback返回了true，不会进行
     * 任何处理，也就是不会重新登录/同步。请小心确定返回值。
     *
     * @param {object.<BaseRequest>}
     * @param {function(BaseResponse): boolean=} opt_callback 回调函数。出错的情况下，如果返回true，则不会再次处理错误。
     */
    sendRequest(request: {name: string, body: any}, opt_callback?: Function) {
        // cc.log("send "+JSON.stringify(request));
        //生成NetworkCallback对象，绑定请求seq和回调方法
        if (opt_callback) {
            let reqname = request.name
            let resname = reqname.substring(0,reqname.length-1)+"s"
            this._networkCallbacks[resname] = new NetworkCallback();
            this._networkCallbacks[resname].init(request, opt_callback);
        }
        this._sendSocketRequest(request);
    }

    /**
     * @param {object.<BaseRequest>} req
     */
    _sendSocketRequest( req) {
        // cc.assert(this._socket);
        let name = req.name;
        let body = req.body;

        let tbMsgHead = new this._pb.ClientMsgHead({
            msgtype:2,
            msgname: name,
            svr_id:"",
            service_address:0,
        })
        //编码消息头
        let headData = tbMsgHead.toArrayBuffer();
        headData = new Uint8Array(headData);
        let headLength = headData.byteLength;
        //编码消息体
        let bodyData = body.toArrayBuffer();
        bodyData = new Uint8Array(bodyData);
        let bodyLength = bodyData.byteLength;
    
        let sendData = new Uint8Array(2+headLength+bodyLength);
        //前两位存储表头的长度
        sendData[0] = (headLength>>8)&0xff;
        sendData[1] = (headLength)&0xff;
        let beginIndex = 2
        for (let i = 0; i < headLength; i++) {
            sendData[i + beginIndex] = headData[i];
        }
        beginIndex+=headLength
        for (let i = 0; i < bodyLength; i++) {
            sendData[i + beginIndex] = bodyData[i];
        }
        //加密
        let ss = Uint8ArrayToString(sendData);
        ss = XXTea.encrypt(ss);
        let data = stringToUint8Array(ss);

        if (this.isSocketOpened() && (!this.is_socket_close)) {

            this._socket.send(data);
        } else {
            this._mSendmsgCache[name] = data
        }
    }

}
