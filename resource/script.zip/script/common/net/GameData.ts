import * as Enum from "../enum";
import * as Helper from "../Helper";
import NetProxy from "./NetProxy";
import Md5 from '../Md5';

export interface gameSer{
    strIP: string, 
    iPort: number
}

export interface weChatInfo{
    uid: string,
    nickname: string,
    imgpath: string,
    sex: string,
    token: string,
    openid: string,
}

interface tbThirdPartInfo {
    nickname: string,
    strHeadUrl: string,
    iSex: number,
    strUID: string,
    strToken: string,
    uidtype: number, 	////登录账号类型  1游客 2微信
    openID: string,
}

enum ClientOsType{
	ANDROID = 'android',
	IOS = 'ios',
	WIN32 = 'win32',
	WEB = 'web',
}

class GameData {
    tbBaseInfo: GameMsg.PlayerBaseinfo = undefined;
    msgcontrol_time: number = undefined;
    tbGameSer: gameSer[] = [];
    strPlatform: string = undefined;
    tbThirdPartInfo: tbThirdPartInfo = undefined;
    strUID: string = undefined;
    strRID: number = undefined;
    strLoginToken: string = undefined;
    iTokenExpTime: number = undefined;
    gameInfo: GameMsg.GameInfo = undefined;

    public static exceptionStr: { [key: string]: string } = {}

    reEnterFlag = false;

    constructor() {
        this.init()
    }

    init() {
        this.msgcontrol_time = 0

        this.tbGameSer = [];
        this.strPlatform = "h5";
        this.tbThirdPartInfo = {
            nickname: "",
            strHeadUrl: "",
            iSex: 0,
            strUID: "",
            strToken: "",
            uidtype: 1, 	////登录账号类型  1游客 2微信
            openID: "",
        };
    }

    UpdateBaseInfo(tbPlayerBaseInfo: GameMsg.PlayerBaseinfo){
        let logininfo = {rid: tbPlayerBaseInfo.rid}
        Helper.setItem(Enum.SAVEKEY.LOGINACCOUNT, JSON.stringify(logininfo))

        //填充玩家基本数据
        this.tbBaseInfo = tbPlayerBaseInfo;
    }

    updateUserCoins(resMsg: GameMsg.GoodsNtc) {
        cc.log('GoodsNtc====', resMsg)
        this.tbBaseInfo.coins = resMsg.coins;
        this.tbBaseInfo.e_wallet = resMsg.e_wallet;
    }

    msgUpdate(dt) {
        this.msgcontrol_time = this.msgcontrol_time + dt 

        return this.msgcontrol_time
    }

    msgRes() {
        this.msgcontrol_time = 0
    }


    errorCatch() {
        if (cc.sys.isNative) {
            window.__errorHandler = function (errorMessage, file, line, message, error) {
                let exception = {
                    errorMessage: errorMessage,
                    file: file,
                    line: line,
                    message: message,
                    error: error
                };
                var excStr = JSON.stringify(exception)
                // var md5str = Md5.Instance.get_md5(excStr)
                var md5str = excStr

                if (GameData.exceptionStr[md5str] == null) {
                    GameData.exceptionStr[md5str] = excStr;
                    // cc.error("异常捕捉")
                    cc.log(exception);
                    //TODO: 发送请求上报异常
                    NetProxy.ClientErrorUploadReq({
                        errorDesc:excStr,
                        deviceinfo:"web",
                    })
                }
            };
        } else if (cc.sys.isBrowser) {
            window.onerror = function (errorMessage, file, line, message, error) {
                let exception = {
                    errorMessage: errorMessage,
                    file: file,
                    line: line,
                    message: message,
                    error: error
                };

                var excStr = JSON.stringify(exception)
                // var md5str = Md5.Instance.get_md5(excStr)
                var md5str = excStr

                if (GameData.exceptionStr[md5str] == null) {
                    GameData.exceptionStr[md5str] = excStr;
                    // cc.error("异常捕捉")
                    cc.log(exception);
                    //TODO: 发送请求上报异常
                    NetProxy.ClientErrorUploadReq({
                        errorDesc: excStr,
                        deviceinfo: "web",
                    })
                }
            };
        }
    }
}

export default new GameData();