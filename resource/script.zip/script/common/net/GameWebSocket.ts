
export const enum GameWebSocketState {
    CONNECTING = 1,
    OPEN,
    CLOSING,
    CLOSED
}

export class GameWebSocketDelegate {
    onSocketOpen(){};
    
    /**
     * 收到了消息
     *@param {string | Uint8Array} data
     */
    onSocketMessage(data: string | Uint8Array){};

    onSocketError(){};

    /**
     * 连接关闭
     * @param {string} reason
     */
    onSocketClosed(reason: string){};
}

export class GameWebSocketInterface {
    connect(){}

    send(data: any){}

    close(){}

    getState():GameWebSocketState{
        return GameWebSocketState.CLOSED;
    };
}

export class GameWebSocket extends GameWebSocketInterface {
    /**
     *服务器地址
     *
     * @type {string}
     * @memberof GameWebSocket
     */
    _address: string;

    /**
     * @type {GameWebSocketDelegate}
     * @memberof GameWebSocket
     */
    _delegate: GameWebSocketDelegate;

    /**
     * @type {WebSocket}
     * @memberof GameWebSocket
     */
    _webSocket: WebSocket;

    /**
     *初始化
     *
     * @param {string} address 服务器地址
     * @param {GameWebSocketDelegate} delegate 回调接口
     * @memberof GameWebSocket
     */
    init(address: string, delegate: GameWebSocketDelegate){
        this._address = address;
        this._delegate = delegate;
        this._webSocket = undefined;
    }

    connect(){
        cc.log('开始连接网络 connect to: ', this._address);
        let ws = new WebSocket(this._address);
        ws.onopen = this._delegate.onSocketOpen.bind(this._delegate);
        ws.onmessage = (param) => {
            this._delegate.onSocketMessage(param.data);
        }
        ws.onerror = this._delegate.onSocketError.bind(this._delegate);
        ws.onclose = (param) => {
            this._delegate.onSocketClosed(param.reason);
        }
        this._webSocket = ws;
    }

    /**
     *发送数据
     *
     * @param {*} stringOrBinary
     * @memberof GameWebSocket
     */
    send(stringOrBinary: any){
        this._webSocket.send(stringOrBinary);
    }

    close(){
        if (!this._webSocket) {
            return;
        }

        try {
            this._webSocket.close();
        } catch (error) {
            cc.log('error while closing webSocket', error.toString());
        }
        this._webSocket = undefined;
    }

    getState(){
        if (this._webSocket) {
            switch (this._webSocket.readyState) {
                case WebSocket.OPEN:
                    return GameWebSocketState.OPEN;
                case WebSocket.CONNECTING:
                    return GameWebSocketState.CONNECTING;
                case WebSocket.CLOSING:
                    return GameWebSocketState.CLOSING;
                case WebSocket.CLOSED:
                    return GameWebSocketState.CLOSED;
            }
        }
        return GameWebSocketState.CLOSED;
    }
}
