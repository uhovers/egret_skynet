import GameNetwork from './GameNetwork';
import * as pbkiller from '../../lib/pbkiller/src/pbkiller.js';
import * as Helper from '../Helper';
import AppEventManager from '../AppEventManager';
import * as Enum from '../enum';
import GameData from './GameData';
import { showTip, showLoading, hideLoading, showConfirm } from '../ui';
import g from '../../g';

// let version = {
//     platform: 1,
//     channel: 203,
//     version: "2.1.24",
//     authtype: 1,
//     regfrom: 1,
// }

let controlMsgMap = {
    "EnterGameReq": true,
    "TransferReq": true,
}

class NetProxy {

    network: GameNetwork = undefined;

    _cachePushCallback: Function[] = [];

    _loadingCtlMap = {};

    socketip: string = undefined;
    socketport: string = undefined;
    isNeedInitSocket: boolean = undefined;
    isNeedReConnect: boolean = undefined;
    mIsNeedClose: boolean = undefined;
    isRepeatNtc: boolean = undefined;

    mCanReceive = true;
    mResMsgCache = [];

    pb: any = undefined;
    closeCB:Function = undefined;

    iSLoginConnecting:boolean = false;
    mCurLoginConnectIndex:number = 0;
    socketws = 'ws://';

    constructor() {
        this.network = undefined;
        this._cachePushCallback = [];
        this._loadingCtlMap = {};
    }

    init(cb?: Function) {
        if(this.network!=null){
            return;
        }
        this.network = new GameNetwork();
        
        pbkiller.preload(() => {
            this.pb = pbkiller.loadFromFile('clientmsg.proto', 'GameMsg');
            this.network.setDelegate(this, this.pb);
            if (cb) {
                cb();
            }
        });

        this.socketip = ""
        this.socketport = ""
        this.isNeedInitSocket = false
        this.isNeedReConnect = false
        this.isRepeatNtc = false;

        setInterval(() => {
            if (this.isNeedInitSocket) {
                this.isNeedInitSocket = false
                this.mIsNeedClose = false
                this.isNeedReConnect = false

                let url = (this.socketport==null || this.socketport=='null' || this.socketport=="") ? this.socketip : `${this.socketip}:${this.socketport}`;
                this.network.connect(url)
            }else if (this.isNeedReConnect) {
                cc.log("isNetworkClosed: ", this.isNetworkClosed())
                if (this.isNetworkClosed()) {
                    cc.log("需要重连的时候, 此时网络已断开连接", this.socketip, this.socketport)
                    showLoading();
                    if (this.socketip!=='') {
                        let url = (this.socketport==null || this.socketport=='null' || this.socketport=="") ? this.socketip : `${this.socketip}:${this.socketport}`;
                        this.network.connect(url)
                    }
                } else {
                    // showLoading();
                    cc.log("需要重连的时候，此时网络没有断开")
                }
                this.isNeedReConnect = false
            }

            this.network.msgUpdate()
        }, 100)

        this.addGlobalMsgHandler(this, this.onMsgRes.bind(this))
    }

    addGlobalMsgHandler(target: any, handler: Function) {
        this.network.addGlobalMsgHandler(target, handler);
    }

    removeGlobalMsghandler(target: any) {
        this.network.removeGlobalMsghandler(target);
    }

    connectLogin() {
        let LOGIN_IP: string = g.gameServers[0].ip;
        if (LOGIN_IP.search('ws://')!=-1) { // 包含ws:
            this.socketws = 'ws://'
        } else if (LOGIN_IP.search('wss://')!=-1) { // 包含wss:
            this.socketws = 'wss://'
        }
        // this.socketws = window.location.protocol==='https:' ? 'wss://' : 'ws://';

        let LOGIN_PORT = g.gameServers[0].port;
        this.changeSocket(LOGIN_IP, LOGIN_PORT);
    }

    initSocket(ip: string, port: string) {
        if (ip.search('ws://')!=-1 || ip.search('wss://')!=-1) { // 有包含前缀
            cc.warn('有前缀')
            this.socketip = ip
        } else {
            cc.warn('没有前缀')
            this.socketip = this.socketws+ip;
        }

        // this.socketip = this.socketws+ip;
        this.socketport = port
        this.isNeedInitSocket = true
        this.isNeedReConnect = false
    }

    changeSocket(ip: string, port: string) {

        if (this.socketip == ip && this.socketport == port && this.isNetworkOpened()) {
            return
        }

        if (this.isNetworkOpened()) {
            this.closeSocket()
        }
        this.initSocket(ip, port)
    }

    // 强制重连网络
    forceReconnect() {
        this.closeSocket()
        this.isNeedInitSocket = true
        this.isNeedReConnect = false
    }

    closeSocket(cb:Function=null) {
        // cc.error("主动关闭socket")
        this.mIsNeedClose = true;
        this.isNeedInitSocket = false;
        this.closeCB = cb
        if (this.isNetworkOpened()) {
            this.network.closeConnect();
        }
    }

    reconnectSocket() {
        cc.log("mIsNeedClose: ", this.mIsNeedClose)
        if (this.mIsNeedClose) {
            return;
        }
        this.isNeedReConnect = true;
    }

    isNetworkOpened() {
        return this.network.isSocketOpened();
    }

    isNetworkClosed() {
        return this.network.isSocketClosed();
    }

    onNetworkOpen() {
        cc.log("网络连接成功");
    }

    onNetworkClose() {
        cc.log("网络连接关闭", this.isNetworkClosed());
        this.reconnectSocket();
        if(this.closeCB!=null){
            this.closeCB();
        }
    }

    //这个消息需要加loading界面控制
    loadingCtl(msgname: string) {
        msgname = msgname.substring(0, msgname.length - 1) + "s"
        this._loadingCtlMap[msgname] = true
        AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_LOADING_LAYER, true);
    }

    loadingCtlRes(msgname: string) {
        if (this._loadingCtlMap.hasOwnProperty(msgname) && this._loadingCtlMap[msgname]) {
            delete this._loadingCtlMap[msgname];

            if (msgname == "EnterGameRes") {
                //登录的时候清空
                this._loadingCtlMap = {}
            }

            if (Helper.getLength(this._loadingCtlMap) > 0) {

            } else {
                AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_LOADING_LAYER, false);
            }
        }
    }

    // 停止接受消息
    stopReceiveMsg(){
        // cc.error('停止接受消息');
        this.mCanReceive = false
    }

    // 插入消息，消息恢复得时候发送出去
    insertresumeReceiveMsg(name: string, body){
        let msg = {
            name: name,
            body: body
        }
        this.mResMsgCache.push(msg);
    }

    // 恢复接受消息
    resumeReceiveMsg(){
        // cc.error('恢复接受消息');
        this.mCanReceive = true
        for (let i = 0; i < this.mResMsgCache.length; i++) {
            const e = this.mResMsgCache[i];
            for (let key in this.network._eventhandlerList) {
                this.network._eventhandlerList[key](e.name, e.body);
            }
        }
        this.mResMsgCache = []
    }

    beginSendRequest(req:{name: string, body: any}, callback?: Function) {
        if (req.name!="HeartReq") {
            // cc.log("send "+JSON.stringify(req));
            cc.log(req);
        }
        this.network.sendRequest(req, callback);
        if (controlMsgMap[req.name] == true) {
            this.loadingCtl(req.name)
        }
    }

    //所有消息的回调
    onMsgRes(msgname: string, resMsg: any) {
        GameData.msgRes()
        if (!this.mCanReceive) {
            this.insertresumeReceiveMsg(msgname, resMsg);
            return;
        }

        if (msgname!=="HeartRes" && msgname!=='BroadCastMsgNtc') {
            cc.log("msgname===" + msgname);
            cc.log(resMsg);
        }
        this.loadingCtlRes(msgname);
        
        if (msgname==="LoginRes") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_LoginRes, resMsg);
        }else if (msgname==="RepeatNtc") {
            cc.log("其他设备登录");
            this.isRepeatNtc = true;
            this.closeSocket();
            let str: string = i18n.languages[g.language]['g_repeated_login'] || '';
            let conf = showConfirm({content: str, sure: true});
            conf.sureHandler = () => {
                showLoading();
                g.postBackToLobby();
            }
        }else if (msgname==="KickPlayerNtc") {
            this.isRepeatNtc = true;
            this.closeSocket();
            let str: string = i18n.languages[g.language]['g_net_error'] || '';
            let conf = showConfirm({content: str, sure: true});
            conf.sureHandler = () => {
                showLoading();
                g.postBackToLobby();
            }
        }else if (msgname==="EnterGameRes") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_EnterGameRes, resMsg);
        }else if (msgname==="GoodsNtc") {
            GameData.updateUserCoins(resMsg)
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_GoodsNtc, resMsg);
        }else if (msgname==="BlackJack21_tablesNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_BlackJack21_tablesNtc, resMsg);
        }else if (msgname==="ReenterTableNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_ReenterTableNtc, resMsg);
        }else if (msgname==="GameStartNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_GameStartNtc, resMsg);
        }else if (msgname==="SitdownTableNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_SitdownTableNtc, resMsg);
        }else if (msgname==="StandupTableNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_StandupTableNtc, resMsg);
        }else if (msgname==="DealCardsNtc_21") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_DealCardsNtc, resMsg);
        }else if (msgname==="DoactionNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_DoactionNtc, resMsg);
        }else if (msgname==="DoactionResultNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_DoactionResultNtc, resMsg);
        }else if (msgname==="GameEndResultNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_GameEndResultNtc, resMsg);
        }else if (msgname==="NoticeClientNtc") {
            AppEventManager.notifyEvent(Enum.EVENTTYPE.EVENT_NoticeClientNtc, resMsg);
        }
    }

    logout(){
        
    }

    //心跳
    HeartReq(callback?: Function) {
        let req = {
            name: "HeartReq",
            body: new this.pb.HeartReq({
                version: g.version,
            })
        }
        this.beginSendRequest(req, callback);
    }

    LoginReq(ip: string, callback?: Function) {
        cc.log(g.thirdConfig.userId);
        
        let req = {
            name: "LoginReq",
            body: new this.pb.LoginReq({
                version: g.version,
                deviceinfo: GameData.strPlatform,
                uid: g.thirdConfig.userId,
                uidtype: GameData.tbThirdPartInfo.uidtype,
                thirdtoken: GameData.tbThirdPartInfo.strToken,
                only_id: g.thirdConfig.userId,
                login_ip: ip,
            })
        }
        this.connectLogin();
        this.beginSendRequest(req, callback);
    }

    EnterGameReq(callback?: Function) {
        let req = {
            name: "EnterGameReq",
            body: new this.pb.EnterGameReq({
                version: g.version,
                device_info:GameData.strPlatform,			//设备系统标志
                uid : GameData.strUID, //玩家第三方登陆UID
                rid : GameData.strRID, //玩家游戏内部ID
                expiretime : GameData.iTokenExpTime, //登陆令牌过期时间
                logintoken : GameData.strLoginToken, //游戏登陆令牌
                uidtype : GameData.tbThirdPartInfo.uidtype,
                subchannelId: g.thirdConfig.subchannelId,
                third_token: g.thirdConfig.token,
            })
        }
        this.beginSendRequest(req, callback);
    }

    BlackJack21_tablesReq(callback?: Function){
        let req = {
            name: 'BlackJack21_tablesReq',
            body: new this.pb.BlackJack21_tablesReq({

            })
        }
        this.beginSendRequest(req, callback);
    }

    EnterTableReq(id: number, roomsvr_id: string, roomsvr_table_address: number, callback?: Function){
        let req = {
            name: 'EnterTableReq',
            body: new this.pb.EnterTableReq({
                version: g.version,
                id: id,
                roomsvr_id: roomsvr_id,
                roomsvr_table_address: roomsvr_table_address,
            })
        }
        this.beginSendRequest(req, callback);
    }

    ReenterTableReq(data: GameMsg.ReenterTableReq, callback?: Function){
        let req = {
            name: 'ReenterTableReq',
            body: new this.pb.ReenterTableReq({
                version: g.version, 
                roomsvr_id: data.roomsvr_id, 
                roomsvr_table_address: data.roomsvr_table_address, 
            })
        }
        this.beginSendRequest(req, callback);
    }

    SitdownTableReq(data: GameMsg.SitdownTableReq, callback?: Function){
        let req = {
            name: 'SitdownTableReq',
            body: new this.pb.SitdownTableReq({
                version: g.version,
                id: data.id,
                roomsvr_id: data.roomsvr_id,
                roomsvr_table_address: data.roomsvr_table_address,
                roomsvr_seat_index: data.roomsvr_seat_index,
            })
        }
        this.beginSendRequest(req, callback);
    }

    StandupTableReq(data: GameMsg.StandupTableReq, callback?: Function){
        let req = {
            name: 'StandupTableReq',
            body: new this.pb.StandupTableReq({
                version: g.version,
                id: data.id,
                roomsvr_id: data.roomsvr_id,
                roomsvr_table_address: data.roomsvr_table_address
            })
        }
        this.beginSendRequest(req, callback);
    }

    LeaveTableReq(data: GameMsg.LeaveTableReq, callback?: Function){
        let req = {
            name: 'LeaveTableReq',
            body: new this.pb.LeaveTableReq({
                version: g.version,
                id: data.id,
                roomsvr_id: data.roomsvr_id,
                roomsvr_table_address: data.roomsvr_table_address,
                is_switch: false
            })
        }
        this.beginSendRequest(req, callback);
    }

    /**
     * 发牌、要牌、停牌等操作
     * @param data.actionType  玩家操作类型 1:发牌  2:要牌  4:停牌 8:双倍下注 16:分牌 32:买保险
     * @param data.call_times
     * @param callback 
     */
    DoactionReq(data: GameMsg.DoactionReq, callback?: Function){
        let req = {
            name: 'DoactionReq',
            body: new this.pb.DoactionReq({
                roomsvr_id: data.roomsvr_id,
                roomsvr_table_address: data.roomsvr_table_address,
                action_type: data.action_type,
                action_subtype: data.action_subtype,
                call_times: data.call_times,
                hand: data.hand,
                obj_seat: data.obj_seat
            })
        }
        this.beginSendRequest(req, callback);
    }

    BlackjackWayReq(callback?: Function){
        let req = {
            name: 'BlackjackWayReq',
            body: new this.pb.BlackjackWayReq({
            })
        }
        this.beginSendRequest(req, callback);
    }

    BlackjackHistoryReq(data: GameMsg.BlackjackHistoryReq, callback?: Function){
        let req = {
            name: 'BlackjackHistoryReq',
            body: new this.pb.BlackjackHistoryReq({
                type_id: data.type_id,
                begin_time: data.begin_time,
                end_time: data.end_time,
                page_index: data.page_index,
                page_size: data.page_size,
                id: data.id
            })
        }
        this.beginSendRequest(req, callback);
    }

    BlackJackQuickStartReq(callback?: Function){
        let req = {
            name: 'BlackJackQuickStartReq',
            body: new this.pb.BlackJackQuickStartReq({
            })
        }
        this.beginSendRequest(req, callback);
    }

    ClientErrorUploadReq(data:GameMsg.ClientErrorUploadReq, callback?: Function) {
        let req = {
            name: "ClientErrorUploadReq",
            body: new this.pb.ClientErrorUploadReq({
                errorDesc:data.errorDesc,
                deviceinfo:data.deviceinfo
            })
        }
        this.beginSendRequest(req, callback);
    }

}

export default new NetProxy()