namespace GameMsg{

  export interface ClientMsgHead{
       msgtype?:number,
       msgname?:string,
       svr_id?:string,
       service_address?:number,
  }
  export interface Version{
       platform?:number,
       channel?:number,
       version?:string,
       authtype?:number,
       regfrom?:number,
       channel_name?:string,
  }
  export interface GateSvrItem{
       ip?:string,
       port?:number,
       updatetime?:number,
       onlinenum?:number,
  }
  export interface PlayerBaseinfo{
       rid?:number,
       rolename?:string,
       logo?:string,
       phone?:string,
       totalgamenum?:number,
       winnum?:number,
       sex?:number,
       coins?:number,
       diamonds?:number,
       highwininseries?:number,
       maxcoinnum?:number,
       base_room_card?:number,
       bind_room_card?:number,
       club_id?:number,
       level_name?:string,
       vip_level?:number,
       sign?:string,
       phone_bind?:string,
       is_system_create?:number,
       player_level?:number,
       exp?:number,
       next_level_need_exp?:number,
       account?:string,
       e_wallet?:number,
       user_type?:number,
       currency?:string,
  }
  export interface TableStateItem{
       id?:number,
       state?:number,
       name?:string,
       room_type?:number,
       game_type?:number,
       max_player_num?:number,
       cur_player_num?:number,
       retain_to_time?:number,
       create_user_rid?:number,
       create_user_rolename?:string,
       create_time?:number,
       create_table_id?:string,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       action_timeout?:number,
       action_timeout_count?:number,
       create_user_logo?:string,
       min_carry_coin?:number,
       max_carry_coin?:number,
       base_coin?:number,
       common_times?:number,
       totalplayernum?:number,
       distribute_playernum?:number,
       round_num?:number,
       rule_name?:string,
       rule_ext_names?:string[],
       max_fan_names?:string[],
       check_type_indexs?:number,
       play_rule_type?:number,
       check_room_index?:number,
       is_review_mode?:number,
       table_uid?:number,
       is_no_shuffle?:number,
       level?:number,
       contest_type?:string,
       tickets?:number,
       need_consume_coin?:number,
       king_wins_card?:number,
  }
  export interface SeatInfo{
       rid?:number,
       index?:number,
       state?:number,
       is_tuoguan?:number,
       coin?:number,
       jdztag?:number,
       isdz?:number,
       ready_to_time?:number,
       cardsnum?:number,
       cards?:number[],
       out_cards?:number[],
       curscore?:number,
       actionmesg?:DoactionNtc,
       is_ming_pai?:number,
       contest_score?:number,
       rank?:number,
       total_player?:number,
       jdz_score?:number,
       need_play_num_add_king_card?:number,
       call_time?:number,
       is_see_card?:boolean,
       total_score?:number,
       gepaonum?:number,
       fan_bei_num?:number,
       is_gendaodi?:boolean,
       is_quanya?:boolean,
       is_tanpai?:boolean,
       is_taotai?:boolean,
       cards_1?:number[],
       cards_2?:number[],
       betScores_1?:number,
       betScores_2?:number,
       is_buy_insurance?:boolean,
       insurance_score?:number,
       is_give_up?:boolean,
       limit_range?:number[],
  }
  export interface TablePlayerInfo{
       rid?:number,
       rolename?:string,
       logo?:string,
       sex?:number,
       totalgamenum?:number,
       winnum?:number,
       coins?:number,
       diamonds?:number,
       highwininseries?:number,
       maxcoinnum?:number,
       clientip?:string,
       latitude?:string,
       longitude?:string,
       level_name?:string,
       vip_level?:number,
  }
  export interface ChipInfo{
       rid?:number,
       score?:number,
  }
  export interface RecordCell{
       id?:number,
       num?:number,
  }
  export interface NNRecordCell{
       id?:number,
       record?:RecordCell[],
  }
  export interface ZFBRecordCell{
       id?:number,
       record?:RecordCell[],
  }
  export interface QDZPlayerInfo{
       rid?:number,
       rolename?:string,
  }
  export interface RankPlayerInfo{
       rid?:number,
       rolename?:string,
       coins?:number,
       totalbets?:number,
       winnum?:number,
       logo?:string,
       winmoney?:number,
       vip_level?:number,
  }
  export interface GameInfo{
       id?:number,
       state?:number,
       name?:string,
       room_type?:number,
       game_type?:number,
       max_player_num?:number,
       cur_player_num?:number,
       retain_to_time?:number,
       create_user_rid?:number,
       create_user_rolename?:string,
       create_time?:number,
       create_table_id?:string,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       action_timeout?:number,
       action_timeout_count?:number,
       create_user_logo?:string,
       min_carry_coin?:number,
       max_carry_coin?:number,
       base_coin?:number,
       common_times?:number,
       all_times?:number,
       action_seat_index?:number,
       action_to_time?:number,
       action_type?:number,
       dz_seat_index?:number,
       seats?:SeatInfo[],
       tableplayerinfos?:TablePlayerInfo[],
       actionlist?:number[],
       room_round?:number,
       curr_round?:number,
       play_rule_type?:number,
       rule_name?:string,
       is_club_daikai?:boolean,
       check_room_index?:number,
       rang_pai_num?:number,
       fan_bei_num?:number,
       last_cards?:number[],
       dizhu_dipai?:number[],
       call_times?:number,
       can_use_bomb?:number,
       last_cardtype?:number,
       laizicards?:number[],
       lastcond?:number,
       master_score?:number,
       tickets?:number,
       loser_score?:number,
       contest_type?:string,
       contest_cfg_uuid?:string,
       contest_game_uuid?:string,
       contest_svr_id?:string,
       contest_agent_address?:number,
       contest_di_score?:number,
       contest_template_id?:number,
       kick_score?:number,
       contest_prefer_left_count?:number,
       chiplist?:ChipInfo[],
       all_score?:number,
       rounds?:number,
       count_time?:number,
       wait_call_times?:number[],
       qdz_players?:QDZPlayerInfo[],
       rank_list?:RankPlayerInfo[],
       players?:HHPlayerInfo[],
       winrecord?:HHRoadNode[],
       remain_score?:number,
       nntrend?:NNRecordCell[],
       baccarat_road?:RoadNode[],
       lucky?:RankPlayerInfo,
       hh_road?:HHRoadNode[],
       player_info?:HHPlayerInfo,
       zfb_trend?:ZFBRecordCell[],
       lh_players?:LHPlayerInfo[],
       lh_winrecord?:LHRoadNode[],
       lh_road?:LHRoadNode[],
       bet_nums?:number[],
       player_rounds_index?:number,
       handle_expire?:number,
       last_action_type?:number,
       yellow_card_coordinate?:number,
       remain_cards_count?:number,
       is_reach_yellow_card?:boolean,
       hand_index?:number,
       limitRange?:number[],
       table_round_id?:string,
       shoe_round_id?:number,
  }
  export interface AwardItem{
       id?:number,
       num?:number,
  }
  export interface ThirdInfo{
       type_id?:number,
       status?:number,
  }
  export interface GetThirdStatusReq{
       rid?:number,
  }
  export interface GetThirdStatusRes{
       errcode?:number,
       errcodedes?:string,
       info_list?:ThirdInfo[],
  }
  export interface UpdateThirdStatusReq{
       type_id?:number,
       status?:number,
  }
  export interface UpdateThirdStatusRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface AccRegReq{
       version?:Version,
       deviceinfo?:string,
       uid?:string,
       uidtype?:number,
       thirdtoken?:string,
       username?:string,
       vercode?:string,
  }
  export interface AccRegRes{
       errcode?:number,
       errcodedes?:string,
       uid?:string,
       rid?:number,
       logintoken?:string,
       expiretime?:number,
       gatesvrs?:GateSvrItem[],
       clientip?:string,
  }
  export interface AccBindReq{
       uid?:string,
       uidtype?:number,
       phone?:string,
       vercode?:string,
  }
  export interface AccBindRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface AccBindPhoneScretReq{
       uid?:string,
       uidtype?:number,
       phone?:string,
       only_id?:string,
       account?:string,
  }
  export interface AccBindPhoneScretRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface LHChangePwdReq{
       old_pwd?:string,
       new_pwd?:string,
  }
  export interface LHChangePwdRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface LHPhoneCodeReq{
       version?:Version,
       phone?:string,
       vercode_type?:number,
  }
  export interface LHPhoneCodeRes{
       errcode?:number,
       errcodedes?:string,
       vercode?:string,
  }
  export interface LHPhoneBindReq{
       vercode?:string,
       phone?:string,
  }
  export interface LHPhoneBindRes{
       errcode?:number,
       errcodedes?:string,
       phone?:string,
  }
  export interface LHAccDisBindPhoneReq{
       phone?:string,
       vercode?:string,
  }
  export interface LHAccDisBindPhoneRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface PhoneScretResetReq{
       scret?:string,
  }
  export interface PhoneScretResetRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface PhoneVerCodeReq{
       version?:Version,
       uid?:string,
       uidtype?:number,
  }
  export interface PhoneVerCodeRes{
       errcode?:number,
       errcodedes?:string,
       vercode?:string,
  }
  export interface LoginReq{
       version?:Version,
       deviceinfo?:string,
       uid?:string,
       uidtype?:number,
       device_uuid?:string,
       only_id?:string,
       thirdtoken?:string,
       account?:string,
       login_ip?:string,
  }
  export interface LoginRes{
       errcode?:number,
       errcodedes?:string,
       uid?:string,
       rid?:number,
       logintoken?:string,
       expiretime?:number,
       gatesvrs?:GateSvrItem[],
       clientip?:string,
       uidtype?:number,
       check_code?:number,
       vercode_pwd?:string,
       device_uuid?:string,
  }
  export interface LoginResetPwdReq{
       phone?:string,
       vercode?:string,
       new_pwd?:string,
  }
  export interface LoginResetPwdRes{
       errcode?:number,
       errcodedes?:string,
       new_pwd?:string,
  }
  export interface ChangeLoginPwdReq{
       old_pwd?:string,
       new_pwd?:string,
  }
  export interface ChangeLoginPwdRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface HeartReq{
       version?:Version,
  }
  export interface HeartRes{
       errcode?:number,
       errcodedes?:string,
       servertime?:number,
  }
  export interface QiniuUploadReq{
       version?:Version,
       uploadlogo?:string,
  }
  export interface QiniuUploadRes{
       errcode?:number,
       errcodedes?:string,
       uploadtoken?:string,
  }
  export interface EnterGameReq{
       version?:Version,
       device_info?:string,
       uid?:string,
       rid?:number,
       expiretime?:number,
       logintoken?:string,
       uidtype?:number,
       subchannelId?:number,
       third_token?:string,
  }
  export interface EnterGameRes{
       errcode?:number,
       errcodedes?:string,
       isreauth?:number,
       servertime?:number,
       baseinfo?:PlayerBaseinfo,
       ip?:string,
       port?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       identity_type?:number,
       bind_prompter?:number,
       create_club_flag?:number,
       club_owner_rid?:number,
       server_current_mode?:number,
       unread_mail_num?:number,
       previous_room_num?:number,
       create_table_id?:string,
       new_join_daikai_apply_flag?:number,
       contest_uuid?:string,
       limit_room_info?:PropRoomInfo[],
       limit_money_page_info?:PropMoneyPageInfo[],
  }
  export interface CreateClubFlagNtc{
       create_club_flag?:number,
       can_open_club_level?:number,
  }
  export interface RealNameValidateReq{
       name?:string,
       id_card?:string,
  }
  export interface RealNameValidateRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface PrompterValidateReq{
       name?:string,
       id_card?:string,
       phone?:string,
  }
  export interface PrompterValidateRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface PrompterValidateCodeReq{
       name?:string,
       id_card?:string,
       phone?:string,
       validate_code?:string,
  }
  export interface PrompterValidateCodeRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface BindInviteCodeReq{
       invite_code?:string,
  }
  export interface BindInviteCodeRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface CardInfo{
       cardtype?:number,
       cards?:number[],
       mingpai_provider?:number,
  }
  export interface PlayerBaseinfoReq{
       version?:Version,
       rid?:number,
  }
  export interface PlayerBaseinfoRes{
       errcode?:number,
       errcodedes?:string,
       baseinfo?:PlayerBaseinfo,
  }
  export interface UpdateinfoReq{
       version?:Version,
       rolename?:string,
       logo?:string,
       phone?:string,
       sex?:number,
       sign?:string,
       flag?:number,
       third_topUpSum?:number,
  }
  export interface UpdateinfoRes{
       errcode?:number,
       errcodedes?:string,
       rolename?:string,
       logo?:string,
       phone?:string,
       sex?:number,
       sign?:string,
       vip_level?:number,
  }
  export interface UpdatePlayerInfoNtc{
       level_name?:string,
  }
  export interface CreateFriendTableReq{
       version?:Version,
       action_timeout?:number,
       retain_time?:number,
       base_coin?:number,
       iscontrol?:number,
       check_room_index?:number,
       is_club_daikai?:boolean,
       play_rule_type?:number,
       coin_room_level?:number,
  }
  export interface CreateMockTableReq{
       table_uid?:string,
       select_round?:number,
  }
  export interface CreateMockTableRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface CreateFriendTableRes{
       errcode?:number,
       errcodedes?:string,
       create_table_id?:string,
       is_club_daikai?:boolean,
  }
  export interface GetTableStateByCreateIdReq{
       version?:Version,
       create_table_id?:string,
  }
  export interface GetTableStateByCreateIdRes{
       errcode?:number,
       errcodedes?:string,
       tablestate?:TableStateItem,
  }
  export interface GetFriendTableListReq{
       version?:Version,
  }
  export interface GetFriendTableListRes{
       errcode?:number,
       errcodedes?:string,
       tablelist?:TableStateItem[],
  }
  export interface FriendTableListChangeNtc{
       type?:number,
       room_id?:number,
  }
  export interface GetGameRoomsReq{
       version?:Version,
       room_type?:number,
  }
  export interface GameRoomsInfo{
       room_type?:number,
       tablestates?:TableStateItem[],
       player_num?:number,
  }
  export interface GetGameRoomsRes{
       errcode?:number,
       errcodedes?:string,
       rooms_info?:GameRoomsInfo[],
  }
  export interface QuickStartReq{
       version?:Version,
       room_type?:number,
       id?:number,
       game_type?:number,
       is_create?:boolean,
  }
  export interface QuickStartRes{
       errcode?:number,
       errcodedes?:string,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       room_type?:number,
       game_type?:number,
  }
  export interface CancelQuickStartReq{
       version?:Version,
       room_type?:number,
       game_type?:number,
  }
  export interface CancelQuickStartRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface GoldRoomMatchNTC{
       errcode?:number,
       errcodedes?:string,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       room_type?:number,
       game_type?:number,
  }
  export interface ContestRoomMatchNTC{
       errcode?:number,
       errcodedes?:string,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       room_type?:number,
       game_type?:number,
       rid?:number,
  }
  export interface CreateRobotTableReq{
       version?:Version,
  }
  export interface CreateRobotTableRes{
       errcode?:number,
       errcodedes?:string,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface StartGameReq{
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface StartGameRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface DoactionReq{
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       version?:Version,
       id?:number,
       cards?:number[],
       laizi_cards_key?:number[],
       action_type?:number,
       action_subtype?:number,
       obj_seat?:number,
       hand?:number,
       call_times?:number,
  }
  export interface Doaction2RobotNtc{
       action_type?:number,
       value?:number,
  }
  export interface DoactionRes{
       errcode?:number,
       errcodedes?:string,
       action_type?:number,
       action_subtype?:number,
       hand?:number,
  }
  export interface DoactionNtc{
       can_use_bomb?:number,
       must_chu_heart3?:number,
       rounds?:number,
       roomsvr_seat_index?:number,
       rid?:number,
       action_to_time?:number,
       action_type?:number,
       action_subtype?:number,
       obj_seat?:number,
       hand?:number,
  }
  export interface DoactionResultNtc{
       card_type?:number,
       rang_pai_num?:number,
       fan_bei_num?:number,
       is_server_op?:number,
       laizi_cards_key?:number[],
       roomsvr_seat_index?:number,
       all_score?:number,
       player_win_score?:number,
       rid?:number,
       action_type?:number,
       action_subtype?:number,
       obj_seat?:number,
       hand?:number,
       cards?:number[],
       cards_1?:number[],
       cards_2?:number[],
       betScores?:number,
       betScores_1?:number,
       betScores_2?:number,
       call_times?:number,
       is_blackjack_banker?:string,
       is_blackjack_player?:string,
       settlement?:Settlement21[],
       times?:string,
       is_over_load?:string,
       coins?:number,
       is_last_refill?:boolean,
       is_reach_yellow_card?:boolean,
       remain_cards_count?:number,
       yellow_card_coordinate?:number,
       action_to_time?:number,
  }
  export interface Settlement21{
       rid?:number,
       obj_seat?:number,
       victory?:string,
       victory_1?:string,
       victory_2?:string,
       win_score?:number,
       coins?:number,
  }
  export interface GameReadyReq{
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface GameReadyRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface PlayerGameRecordinfoReq{
       version?:Version,
       rid?:number,
       id?:number,
       limit?:number,
  }
  export interface playerRecordinfo{
       rid?:number,
       currencyid?:number,
       balancenum?:number,
       rolename?:string,
  }
  export interface PlayerGameRecordinfo{
       id?:number,
       table_id?:number,
       table_create_time?:number,
       tablecreater_rid?:number,
       entercosts?:number,
       recordinfos?:playerRecordinfo[],
  }
  export interface PlayerGameRecordinfoRes{
       errcode?:number,
       errcodedes?:string,
       records?:PlayerGameRecordinfo[],
  }
  export interface GetMailsReq{
       create_time?:number,
  }
  export interface PlayerMailNtc{
       type?:number,
       mailitems?:MailItem[],
  }
  export interface MailItem{
       mail_key?:string,
       reason?:number,
       rid?:number,
       create_time?:number,
       content?:string,
       isattach?:number,
       is_read?:number,
  }
  export interface PlayerMailListReq{
       index?:number,
       page_size?:number,
       req_type?:number,
  }
  export interface PlayerMailListRes{
       errcode?:number,
       errcodedes?:string,
       index?:number,
       size?:number,
       total?:number,
       mailitems?:MailItem[],
  }
  export interface PlayerMailAlreadyReadReq{
       mail_key?:string,
  }
  export interface PlayerMailAlreadyReadRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface GetMailsRes{
       errcode?:number,
       errcodedes?:string,
       mailitems?:MailItem[],
  }
  export interface GetmailItemsReq{
       version?:Version,
       mail_key?:string,
  }
  export interface GetmailItemsRes{
       errcode?:number,
       errcodedes?:string,
       mail_key?:string,
       resultdes?:string,
  }
  export interface DeleteMailReq{
       version?:Version,
       mail_key?:string,
  }
  export interface DeleteMailRes{
       errcode?:number,
       errcodedes?:string,
       mail_key?:string,
  }
  export interface TaskReward{
       id?:number,
       num?:number,
  }
  export interface TaskItem{
       task_id?:number,
       desc?:string,
       condition?:number,
       progress?:number,
       status?:number,
       rewards?:TaskReward[],
       jump_type?:number,
       icon?:string,
  }
  export interface QueryTaskReq{
       version?:Version,
  }
  export interface QueryTaskRes{
       errcode?:number,
       errcodedes?:string,
       dailytasks?:TaskItem[],
       systemtasks?:TaskItem[],
  }
  export interface DoTaskNtc{
       daily_task_info?:TaskItem,
  }
  export interface GetTaskRewardReq{
       task_id?:number,
       task_type?:number,
  }
  export interface GetTaskRewardRes{
       errcode?:number,
       errcodedes?:string,
       task_id?:number,
       task_type?:number,
       status?:number,
       award_list?:AwardItem[],
  }
  export interface SendMessageReq{
       version?:Version,
       messages?:string,
       chat_type?:number,
       chat_to_seat_index?:number,
  }
  export interface SendMessageRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface ConfBase{
       changetime?:number,
       confname?:string,
       confcontent?:string,
  }
  export interface DownloadCfgReq{
       version?:Version,
       resconfinfos?:ConfBase[],
  }
  export interface DownloadCfgRes{
       errcode?:number,
       errcodedes?:string,
       reqconfinfos?:ConfBase[],
  }
  export interface DisbandRoomReq{
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       roomsvr_seat_index?:number,
  }
  export interface DisbandRoomRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface ResponseDisbandRoomReq{
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       roomsvr_seat_index?:number,
       bdisband?:number,
  }
  export interface ResponseDisbandRoomRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface IosGoodItems{
       goods_id?:string,
       count?:number,
       price?:number,
       title?:string,
       simple_description?:string,
       description?:string,
       iconPath?:string,
  }
  export interface BuyCardModelReq{
       version?:Version,
       type?:number,
  }
  export interface BuyCardModelRes{
       errcode?:number,
       errcodedes?:string,
       goods_item?:IosGoodItems[],
  }
  export interface CreateClubReq{
       rid?:number,
       club_name?:string,
       club_city?:string,
  }
  export interface CreateClubRes{
       errcode?:number,
       errcodedes?:string,
       club_id?:number,
  }
  export interface JoinClubReq{
       club_id?:number,
  }
  export interface NewJoinClubApplyNtc{
       type?:number,
       num?:number,
  }
  export interface JoinClubRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface ClubEditReq{
       rid?:number,
       edit_club_notice?:string,
       edit_club_city?:string,
       edit_club_name?:string,
  }
  export interface ClubEditRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface ClubEditNotice{
       notice_type?:number,
  }
  export interface ClubInfoReq{
       rid?:number,
  }
  export interface ClubInfo{
       club_notice?:string,
       club_create_time?:number,
       club_owner_name?:string,
       club_id?:number,
       club_room_card?:number,
       club_level?:number,
       online_member?:number,
       club_name?:string,
       club_city?:string,
       club_member_counts?:number,
       club_max_member_limit?:number,
       club_room_card_endtime?:number,
       is_check_long_time?:boolean,
       club_owner_rid?:number,
       day_average_room_times_of_7day?:number,
       my_club_room_card_quota?:number,
       exit_end_time?:number,
  }
  export interface ClubInfoRes{
       errcode?:number,
       errcodedes?:string,
       club_info?:ClubInfo,
  }
  export interface ConfigReq{
       theme?:number,
       type?:number,
  }
  export interface ConfigRes{
       errcode?:number,
       errcodedes?:string,
       data?:string,
       type?:number,
  }
  export interface ClubLevelInfoReq{
       rid?:number,
  }
  export interface ClubLevelInfo{
       club_level?:number,
       average_war_record_7?:number,
  }
  export interface ClubLevelInfoRes{
       errcode?:number,
       errcodedes?:string,
       club_level_info?:ClubLevelInfo,
  }
  export interface ClubMembersListReq{
       rid?:number,
       key?:string,
       index?:number,
       page_size?:number,
  }
  export interface MemberInfo{
       rid?:number,
       photo?:string,
       name?:string,
       status?:number,
       off_time?:number,
       level?:number,
       star_level?:number,
       remain_room_card?:number,
       current_table_player_num?:number,
       create_table_id?:number,
       exit_club_remain_time?:number,
       max_player_num?:number,
  }
  export interface ClubMembersListRes{
       errcode?:number,
       errcodedes?:string,
       member_info?:MemberInfo[],
       application_num?:number,
       index?:number,
       size?:number,
       total?:number,
  }
  export interface MemberJoinRoomReq{
       rid?:number,
       to_rid?:number,
  }
  export interface MemberJoinRoomRes{
       errcode?:number,
       errcodedes?:string,
       room_id?:number,
       room_address?:string,
  }
  export interface ApplicationMembersReq{
       rid?:number,
       key?:string,
  }
  export interface ApplicationMembers{
       rid?:number,
       photo?:string,
       name?:string,
       credit?:number,
  }
  export interface ApplicationMembersRes{
       errcode?:number,
       errcodedes?:string,
       application_members?:ApplicationMembers[],
  }
  export interface HandleClubMemberApplicationReq{
       is_allow_join_club?:number,
       choose_rid?:number,
  }
  export interface HandleClubMemberApplicationRes{
       errcode?:number,
       errcodedes?:string,
       is_allow_join_club?:number,
       choose_rid?:number,
  }
  export interface ClubApplicationResultNotice{
       club_id?:number,
       is_allow_join_club?:number,
  }
  export interface ManageClubMemberReq{
       add_white_list_id?:number,
       remove_white_list_id?:number,
       delete_rid?:number,
  }
  export interface ManageClubMemberRes{
       errcode?:number,
       errcodedes?:string,
       delete_rid?:number,
  }
  export interface PaiHistoryInfoReq{
       rid?:number,
  }
  export interface PaiHistoryInfo{
       time?:number,
       mj_type?:string,
       room_owner?:number,
       current_ju_num?:number,
       total_ju_num?:number,
  }
  export interface PaiHistoryInfoRes{
       errcode?:number,
       errcodedes?:string,
       pai_info?:PaiHistoryInfo[],
  }
  export interface WarRewardHistoryInfoReq{
       rid?:number,
  }
  export interface WarRewardHistoryInfo{
       photo?:string,
       name?:string,
       score?:number,
  }
  export interface WarRewardHistoryInfoRes{
       errcode?:number,
       errcodedes?:string,
       war_reward_info?:WarRewardHistoryInfo[],
  }
  export interface ClubTableRecordReq{
       type?:number,
       index?:number,
       page_size?:number,
  }
  export interface TableRecordPlayerInfo{
       photo?:string,
       name?:string,
       id?:number,
  }
  export interface TableRecordSigleRoundScoreInfo{
       score?:number[],
  }
  export interface SingleTableRecord{
       create_table_id?:number,
       play_round_num?:number,
       total_round_num?:number,
       table_type_name?:string,
       creator_name?:string,
       consume_room_card?:string,
       table_start_time?:number,
       table_player_info?:TableRecordPlayerInfo[],
       table_score_info?:TableRecordSigleRoundScoreInfo[],
       is_game_end?:boolean,
       consume_of_increase_round?:number,
       can_increase_round_num?:number,
       create_user_rid?:number,
       table_uid?:string,
       is_have_application?:boolean,
  }
  export interface ClubTableRecordRes{
       errcode?:number,
       errcodedes?:string,
       req_type?:number,
       start?:number,
       size?:number,
       total?:number,
       records?:SingleTableRecord[],
  }
  export interface UseRoomCardSetReq{
       operation_rid?:number,
       star_level?:number,
  }
  export interface UseRoomCardSetRes{
       errcode?:number,
       errcodedes?:string,
       operation_rid?:number,
       star_level?:number,
  }
  export interface GetRoomCardByStarReq{
       rid?:number,
       room_card?:number,
  }
  export interface GetRoomCardByStarRes{
       errcode?:number,
       errcodedes?:string,
       club_room_card?:number,
       remain_room_card?:number,
  }
  export interface QuotaRoomCardLogReq{
       rid?:number,
  }
  export interface RoomCardLog{
       time?:number,
       name?:string,
       conf_room_card?:number,
       consumer_room_card?:number,
  }
  export interface QuotaRoomCardLogRes{
       errcode?:number,
       errcodedes?:string,
       set_room_card_log?:RoomCardLog[],
  }
  export interface ClubOpenRoomReq{
       rid?:number,
       invited_id?:number[],
       check_room_index?:number,
  }
  export interface ClubOpenRoomRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface ClueOpenRoomReplyReq{
       rid?:number,
       is_agree?:boolean,
  }
  export interface ClueOpenRoomReplyRes{
       errcode?:number,
       errcodedes?:string,
       is_agree?:boolean,
  }
  export interface CanInviteJoinRoomListReq{
       rid?:number,
  }
  export interface CanInviteJoinRoom{
       id?:number,
       photo?:string,
       name?:string,
       credit?:number,
  }
  export interface CanInviteJoinRoomListRes{
       errcode?:number,
       errcodedes?:string,
       member_info?:CanInviteJoinRoom[],
  }
  export interface InvitedJoinRoomReq{
       rid?:number,
       invited_ids?:number[],
       room_id?:string,
  }
  export interface InvitedJoinRoomRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface DaikaiRoomIdsReq{
       rid?:number,
  }
  export interface DaikaiRoomIdsRes{
       errcode?:number,
       errcodedes?:string,
       room_ids?:string[],
       is_have_application?:boolean[],
  }
  export interface DaikaiMainInfoReq{
       create_table_id?:string,
  }
  export interface DaikaiMainInfoRes{
       errcode?:number,
       errcodedes?:string,
       invite_infos?:CanInviteJoinRoom[],
       application_members?:CanInviteJoinRoom[],
       disband_room_time?:number,
       majiang_name?:string,
       is_review_mode?:number,
       rule_ext_names?:string[],
       max_fan_names?:string[],
       round_num?:number,
  }
  export interface DaikaiRoomUpdatePlayerNtc{
       create_table_id?:string,
       updated_player?:CanInviteJoinRoom,
       state?:number,
  }
  export interface DaikaiKickReq{
       rid?:number,
       room_id?:string,
       kick_rid?:number,
  }
  export interface DaikaiKickRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface RepeatNtc{
       rid?:number,
  }
  export interface SitdownTableNtc{
       rid?:number,
       seatinfo?:SeatInfo,
       tableplayerinfo?:TablePlayerInfo,
       gameinfo?:GameInfo,
  }
  export interface StandupTableNtc{
       rid?:number,
       roomsvr_seat_index?:number,
       state?:number,
       reason?:number,
  }
  export interface TingStruct{
       card?:number,
       canhutilelist?:TingTileInfo[],
  }
  export interface TingTileInfo{
       card?:number,
       multiple?:number,
  }
  export interface MingPaiInfo{
       cards?:number[],
  }
  export interface PDKBombInfo{
       seat_index?:number,
       bomb_score?:number,
  }
  export interface PDKBombNtc{
       player_bomb_list?:PDKBombInfo[],
  }
  export interface GameStartNtc{
       gameinfo?:GameInfo,
  }
  export interface CompareCardsNtc{
       winner?:number,
       loser?:number,
       is_draw?:boolean,
  }
  export interface DealCardsNtc{
       rid?:number,
       roomsvr_seat_index?:number,
       cards?:number[],
  }
  export interface card_21{
       obj_seat?:number,
       rid?:number,
       cards?:number[],
       is_reach_yellow_card?:boolean,
       remain_cards_count?:number,
  }
  export interface DealCardsNtc_21{
       seat_cards?:card_21[],
  }
  export interface AllCardsNtc{
       red?:number[],
       black?:number[],
  }
  export interface DoReadyNtc{
       rid?:number,
       roomsvr_seat_index?:number,
       ready_to_time?:number,
  }
  export interface GameNtc{
       itype?:number,
       time?:number,
  }
  export interface DoDoubleScoreReq{
       rid?:number,
  }
  export interface DoDoubleScoreRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface DoubleScoreNtc{
       rid?:number,
       status?:number,
  }
  export interface HHPlayerInfo{
       rid?:number,
       rolename?:string,
       logo?:string,
       lucky?:number,
       win_num_20?:number,
       total_score_20?:number,
       coins?:number,
       bigwinner?:number,
       win_point?:number,
       vip_level?:number,
  }
  export interface DoGePaoNtc{
       gepao_config?:number[],
       action_timeout?:number,
  }
  export interface SelGePaoReq{
       gepaonum?:number,
  }
  export interface SelGePaoRes{
       errcode?:number,
       errcodedes?:string,
       gepaonum?:number,
  }
  export interface SelGePaoNtc{
       gepaonum?:number[],
  }
  export interface HHTablePlayerNtc{
       isend?:number,
       list?:HHPlayerInfo[],
       hh_road?:HHRoadNode,
       player_info?:HHPlayerInfo,
  }
  export interface GameReadyResultNtc{
       rid?:number,
       roomsvr_seat_index?:number,
       isready?:number,
  }
  export interface PlayerInfoInGameEnd{
       rid?:number,
       finalscore?:number,
       iswin?:number,
       winnum?:number,
       seatindex?:number,
       rolename?:string,
       logo?:string,
       rivals?:number[],
  }
  export interface HuInfo{
       rid?:number,
       seatindex?:number,
       hu_type?:number,
       cards?:number[],
  }
  export interface DealCardsEnd{
       seatindex?:number,
       cards?:number[],
       winmoney?:number,
       hu_info?:HuInfo[],
       total_money?:number,
       win_contest_score?:number,
       total_contest_score?:number,
       rank?:number,
       total_player?:number,
       be_kick?:number,
       master_score?:number,
       times?:number,
       base_coin?:number,
       flg?:number,
       is_show_cards?:boolean,
  }
  export interface TimesInfo{
       id?:number,
       times?:number,
  }
  export interface GameEndResultNtc{
       dealcard?:DealCardsEnd[],
       basecoins?:number,
       times?:number,
       countdata?:PlayerInfoInGameEnd[],
       ischuntian?:number,
       mjrounds?:number,
       table_rounds_uid?:string,
       total_time?:number,
       times_info_list?:TimesInfo[],
       total_rounds?:number,
       is_friend_force_disbandom?:boolean,
       remain_score?:number,
       is_game_end?:boolean,
       settlement?:Settlement21[],
       banker_cards?:number[],
  }
  export interface CardsPuts{
       rid?:number,
       putcards?:number[],
       laizi_cards_key?:number[],
  }
  export interface ReenterRoomNtc{
       index?:number,
  }
  export interface CardTask{
       beinum?:number,
       desc?:string,
  }
  export interface ReenterTableNtc{
       handcards?:number[],
       dealcards?:number[],
       cardsput?:CardsPuts[],
       action_type?:number,
       action_to_time?:number,
       action_seat_index?:number,
       must_chu_heart3?:number,
       random_task?:CardTask,
       dipai_tasks?:CardTask[],
       is_use_kandipai?:boolean,
       is_use_jipaiqi?:boolean,
       dipai_cards?:number[],
       handle_out_card?:number[],
  }
  export interface PlayerTableMessageNtc{
       rid?:number,
       seat_index?:number,
       messages?:string,
       chat_type?:number,
       chat_to_seat_index?:number,
  }
  export interface DeliverGoodsNtc{
       order_id?:string,
       option_data?:string,
       awards?:AwardItem[],
  }
  export interface PlayerBaseInfoNtc{
       baseinfo?:PlayerBaseinfo,
  }
  export interface PlayerLevelTableNtc{
       rid?:number,
  }
  export interface PlayerDisconnectNtc{
       index?:number,
  }
  export interface DisbandRoomNtc{
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       roomsvr_seat_index?:number,
       rolename?:string,
  }
  export interface DisbandRoomResultNtc{
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       roomsvr_seat_index?:number,
       bdisband?:number,
       rolename?:string,
  }
  export interface GoodsNtc{
       rid?:number,
       coins?:number,
       diamonds?:number,
       base_room_card?:number,
       bind_room_card?:number,
       master_score?:number,
       king_wins_card?:number,
       bag_info?:BagInfo[],
       totalgamenum?:number,
       winnum?:number,
       bank_coin?:number,
       e_wallet?:number,
  }
  export interface SeverNtc{
       msg_type?:number,
       disband_reason?:string,
  }
  export interface PlayerBindPrompterNtc{
       bind_prompter?:number,
  }
  export interface BroadCastMsgInfo{
       msg?:string,
       count?:number,
       distance_time?:number,
  }
  export interface BroadCastMsgNtc{
       broadcast_list?:BroadCastMsgInfo[],
  }
  export interface JonClubInfoNtc{
       status?:number,
  }
  export interface ClubChangeNtc{
       command_id?:number,
       extra_msg?:string,
       extra_data?:number,
  }
  export interface ClubOpenRoomNtc{
       invite_id?:number,
       invite_name?:string,
       check_room_index?:number,
  }
  export interface InviteJoinRoomNtc{
       room_number?:string,
       room_owner_name?:string,
       invite_id?:number,
  }
  export interface TableReviewModeSetReq{
       is_open?:number,
       create_table_id?:string,
  }
  export interface TableReviewModeSetRes{
       errcode?:number,
       errcodedes?:string,
       create_table_id?:string,
       is_open?:number,
  }
  export interface TableReviewClosedNtc{
       table_create_id?:string,
  }
  export interface TableReviewApplyNtc{
       rid?:number,
       name?:string,
       logo?:string,
       table_create_id?:string,
  }
  export interface TableReviewApplyMutiNtc{
       is_review_mode?:number,
       applys?:TableReviewApplyNtc[],
  }
  export interface HandleTableReviewApplyReq{
       choose_rid?:number,
       is_allow?:boolean,
       room_id?:string,
  }
  export interface HandleTableReviewApplyRes{
       errcode?:number,
       errcodedes?:string,
       choose_rid?:number,
  }
  export interface TableReviewApplyResultNtc{
       is_allow?:boolean,
       create_table_id?:number,
       create_user_rolename?:string,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       errcodedes?:string,
  }
  export interface MemberStarLevelNtc{
       star_level?:number,
       can_use_room_card?:number,
       club_room_card?:number,
  }
  export interface ClubLevelChangeNtc{
       club_level?:number,
       club_member_counts?:number,
  }
  export interface ClubDaikaiTableIncreaseRoundReq{
       table_uid?:string,
  }
  export interface ClubDaikaiTableIncreaseRoundRes{
       errcode?:number,
       errcodedes?:string,
       table_uid?:string,
       new_total_round_num?:number,
  }
  export interface TableConfChangeNtc{
       type?:number,
       club_owner_name?:string,
       new_rounds?:number,
  }
  export interface DaikaiKickNtc{
       name?:string,
  }
  export interface ClubRoomCardNtc{
       club_room_card?:number,
  }
  export interface MockChargeReq{
       item_id?:string,
  }
  export interface MockChargeRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface UploadPlayerPostionReq{
       latitude?:string,
       longitude?:string,
  }
  export interface UploadPlayerPostionRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface UploadPlayerPostionNtc{
       rid?:number,
       latitude?:string,
       longitude?:string,
  }
  export interface BindIntroducerReq{
       bind_rid?:number,
  }
  export interface BindIntroducerRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface InviteNewPlayerInfo{
       rid?:number,
       name?:string,
       status?:number,
       invite_time?:number,
       award_cards?:number,
  }
  export interface InviteNewPlayerListReq{
  }
  export interface InviteNewPlayerListRes{
       errcode?:number,
       errcodedes?:string,
       invite_player_list?:InviteNewPlayerInfo[],
  }
  export interface InviteActivityStateReq{
       type?:number,
  }
  export interface InviteActivityStateRes{
       errcode?:number,
       errcodedes?:string,
       total_invite_num?:number,
       already_get_card?:number,
  }
  export interface MockTableInfoNtc{
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       gameinfo?:GameInfo,
       gepaonum?:number[],
  }
  export interface MockTableNextActionReq{
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface MockTableNextActionRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface GetInviteNewPlayerAwardReq{
       choose_rid?:number,
  }
  export interface GetInviteNewPlayerAwardRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface ShareAppAwardReq{
       type?:number,
  }
  export interface ShareAppAwardRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       remain_time?:number,
  }
  export interface ClientErrorUploadReq{
       errorDesc?:string,
       deviceinfo?:string,
  }
  export interface ClientErrorUploadRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface PlayBackTableInitInfo{
       table_state_info?:TableStateItem,
       seat_card?:MingPaiInfo[],
       seat_player_info?:TablePlayerInfo[],
       dz_seat_index?:number,
       gepao_config?:number[],
  }
  export interface PlayBackScoreResultInfo{
       dealcard?:DealCardsEnd[],
       winseatindex?:number[],
       endtype?:number,
       mjrounds?:number,
       mjquannum?:number,
       countdata?:PlayerInfoInGameEnd[],
       baocardvalue?:number,
       dianpao_index?:number,
       hupai_index?:number,
       hupai_type?:number,
       table_rounds_uid?:string,
       ischuntian?:number,
       basecoins?:number,
       times?:number,
       total_time?:number,
  }
  export interface PlayBackActionResultInfo{
       rid?:number,
       roomsvr_seat_index?:number,
       action_type?:number,
       cards?:number[],
       call_times?:number,
       card_type?:number,
       rang_pai_num?:number,
       fan_bei_num?:number,
       laizi_cards_key?:number[],
  }
  export interface PlayBackRecordReq{
       table_rounds_uid?:string,
  }
  export interface PlayBackRecordRes{
       errcode?:number,
       errcodedes?:string,
       table_info?:PlayBackTableInitInfo,
       score_info?:PlayBackScoreResultInfo,
       action_result_list?:PlayBackActionResultInfo[],
  }
  export interface ExitClubReq{
       rid?:number,
       type?:number,
  }
  export interface ExitClubRes{
       errcode?:number,
       errcodedes?:string,
       exit_club_last_time?:number,
  }
  export interface KickPlayerNtc{
       desc?:string,
  }
  export interface DizhuNtc{
       rid?:number,
       seatindex?:number,
       cards?:number[],
       call_times?:number,
       qiangzhuang_seatindex_list?:number[],
  }
  export interface TempLeaveReq{
       rid?:number,
       type?:number,
  }
  export interface TempLeaveRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface TempLeaveNtc{
       rid?:number,
       type?:number,
  }
  export interface PushhandsNumNtc{
       basecoins?:number,
       times?:number,
       seats?:SeatInfo[],
  }
  export interface DealCardsEndNtc{
       rid?:number,
       cards?:number[],
       times?:number,
  }
  export interface MingPaiCardNtc{
       card?:number,
  }
  export interface MingPaiNtc{
       seat_index?:number,
       cards?:number[],
  }
  export interface NoDizhuNtc{
       info?:string,
  }
  export interface HangUpReq{
       rid?:number,
  }
  export interface HangUpRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface WakeUpReq{
       version?:Version,
  }
  export interface WakeUpRes{
       errcode?:number,
       errcodedes?:string,
       gameinfo?:GameInfo,
  }
  export interface NoticeClientNtc{
       info_id?:number[],
  }
  export interface GetRewardListReq{
       rid?:number,
  }
  export interface SubsidyInfo{
       config_min_coin?:number,
       subsidy_coin?:number,
       can_attach_num?:number,
  }
  export interface GetRewardListRes{
       errcode?:number,
       errcodedes?:string,
       remain_award_status?:number,
       subsidy_info?:SubsidyInfo,
       goods_info?:GoodsInfo,
  }
  export interface SubsidyNtc{
       coins_num?:number,
       subsidy_num?:number,
  }
  export interface SpecialCoinInfoReq{
       rid?:number,
       buy_type?:number,
  }
  export interface GoodsInfo{
       discount?:string,
       special_price?:string,
       is_can_buy?:number,
       award_list?:AwardItem[],
       goods_id?:number,
  }
  export interface SpecialCoinInfoRes{
       errcode?:number,
       errcodedes?:string,
       last_limit_buy_time?:number,
       goods_info_list?:GoodsInfo[],
  }
  export interface BuySpecialCoinReq{
       buy_type?:number,
       pos_index?:number,
  }
  export interface BuySpecialCoinRes{
       errcode?:number,
       errcodedes?:string,
       award_list?:AwardItem[],
  }
  export interface RemainLoginAwardInfoReq{
       rid?:number,
  }
  export interface RemainLoginAwardInfo{
       award_list?:AwardItem[],
  }
  export interface RemainLoginAwardInfoRes{
       errcode?:number,
       errcodedes?:string,
       remain_day_num?:number,
       is_attach_coin?:number,
       award_info?:RemainLoginAwardInfo[],
  }
  export interface GetRemainLoginAwardReq{
       rid?:number,
  }
  export interface GetRemainLoginAwardRes{
       errcode?:number,
       errcodedes?:string,
       award_list?:AwardItem[],
  }
  export interface SubsidyReq{
       rid?:number,
  }
  export interface SubsidyRes{
       errcode?:number,
       errcodedes?:string,
       subsidy_num?:number,
       award_list?:AwardItem[],
  }
  export interface GetShopInfoReq{
       type?:number,
  }
  export interface ShopItemInfo{
       goods_id?:number,
       goods_icon?:string,
       goods_name?:string,
       price?:string,
       award_list?:AwardItem[],
       extra_award_list?:AwardItem[],
       ios_order_name?:string,
       extra_pre?:string,
       baidu_point?:string,
  }
  export interface GetShopInfoRes{
       errcode?:number,
       errcodedes?:string,
       shop_item_list?:ShopItemInfo[],
  }
  export interface BuyShopInfoReq{
       type?:number,
       goods_id?:number,
  }
  export interface BuyShopInfoRes{
       errcode?:number,
       errcodedes?:string,
       award_list?:AwardItem[],
  }
  export interface HaifantianInfoReq{
       rid?:number,
  }
  export interface HaifantianInfoRes{
       errcode?:number,
       errcodedes?:string,
       award_list?:AwardItem[],
       money_rmb?:number,
  }
  export interface GetHaifantianGoodsReq{
       rid?:number,
  }
  export interface GetHaifantianGoodsRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface GetBagInfoReq{
       rid?:number,
       get_bag_type?:number,
  }
  export interface BagInfo{
       id?:number,
       num?:number,
       goods_type?:number,
  }
  export interface GetBagInfoRes{
       errcode?:number,
       errcodedes?:string,
       info_list?:BagInfo[],
  }
  export interface UsePropReq{
       bag_info?:BagInfo,
  }
  export interface UsePropRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface UsePropCardsNtc{
       prop_type?:number,
       cards?:number[],
  }
  export interface HuoDongInfoReq{
       rid?:number,
  }
  export interface HuoDongInfoRes{
       errcode?:number,
       errcodedes?:string,
       activity_ids?:number[],
  }
  export interface TurntableStatusReq{
       rid?:number,
  }
  export interface TurntableInfo{
       goods_pos?:number,
       award_list?:AwardItem[],
  }
  export interface TurntableStatusRes{
       errcode?:number,
       errcodedes?:string,
       goods_list?:TurntableInfo[],
       need_master_score?:number,
  }
  export interface TurntableLuckDrawReq{
       rid?:number,
  }
  export interface TurntableLuckDrawRes{
       errcode?:number,
       errcodedes?:string,
       goods_pos?:number,
       next_need_master_score?:number,
  }
  export interface WeinxinShareStatusReq{
       rid?:number,
  }
  export interface WeinxinShareStatusRes{
       errcode?:number,
       errcodedes?:string,
       status?:number,
       items?:AwardItem[],
  }
  export interface WeinxinShareReq{
       rid?:number,
  }
  export interface WeinxinShareRes{
       errcode?:number,
       errcodedes?:string,
       items?:AwardItem[],
  }
  export interface CreateLaiziNtc{
       cards?:number[],
  }
  export interface RedSecondItem{
       id?:number,
       status?:number,
  }
  export interface RedPrimaryItem{
       id?:number,
       status?:number,
       item_list?:RedSecondItem[],
  }
  export interface RedNtc{
       red_list?:RedPrimaryItem[],
  }
  export interface KnockoutMiscInfoReq{
  }
  export interface KnockoutPlayerInfo{
       cfg_uuid?:string,
       game_uuid?:string,
       rid?:number,
       rank?:number,
       score?:number,
       reason?:number,
       state?:number,
       round?:number,
       total_player?:number,
       regist_min_count?:number,
       prefer_left_count?:number[],
  }
  export interface KnockoutMiscInfoRes{
       errcode?:number,
       errcodedes?:string,
       cfg_uuid?:string,
       template_id?:number,
       group_type?:number,
       svr_id?:string,
       contest_address?:number,
       game_uuid?:string,
       create_table_id?:number,
       playinfo?:KnockoutPlayerInfo,
       open_interval_time?:number,
       cfg_uuids?:string[],
  }
  export interface KnockoutContestInfoReq{
       cfg_uuid?:string,
  }
  export interface KnockoutContestInfo{
       cfg_uuid?:string,
       group_type?:number,
       template_id?:number,
       svr_id?:string,
       contest_address?:number,
       open_interval_time?:number,
       deduct_item_list?:AwardItem[],
       show_num?:number,
       regist_count?:number,
       countdown?:number,
       next_contest_time?:number,
       is_regist?:boolean,
       game_uuid?:string,
       is_confirm_entry?:boolean,
  }
  export interface KnockoutContestInfoRes{
       errcode?:number,
       errcodedes?:string,
       info?:KnockoutContestInfo,
  }
  export interface KnockoutListReq{
       group_type?:number,
  }
  export interface KnockoutListRes{
       errcode?:number,
       errcodedes?:string,
       group_type?:number,
       list?:KnockoutContestInfo[],
  }
  export interface KnockoutRegistReq{
       svr_id?:string,
       contest_address?:number,
       cfg_uuid?:string,
       deduct_item?:number,
  }
  export interface KnockoutRegistRes{
       errcode?:number,
       errcodedes?:string,
       cfg_uuid?:string,
       regist_count?:number,
  }
  export interface KnockoutUnRegistReq{
       svr_id?:string,
       contest_address?:number,
       cfg_uuid?:string,
  }
  export interface KnockoutUnRegistRes{
       errcode?:number,
       errcodedes?:string,
       cfg_uuid?:string,
       regist_count?:number,
  }
  export interface KnockoutConfirmEntryNtc{
       svr_id?:string,
       contest_address?:number,
       cfg_uuid?:string,
       template_id?:number,
       diff_time?:number,
  }
  export interface KnockoutConfirmEntryReq{
       svr_id?:string,
       contest_address?:number,
       cfg_uuid?:string,
       entry_flag?:number,
  }
  export interface KnockoutConfirmEntryRes{
       errcode?:number,
       errcodedes?:string,
       svr_id?:string,
       contest_address?:number,
       cfg_uuid?:string,
       entry_flag?:number,
  }
  export interface KnockoutAbortiveNtc{
       cfg_uuid?:string,
       rid?:number,
  }
  export interface KnockoutUnMatchNtc{
       cfg_uuid?:string,
       game_uuid?:string,
       state?:number,
       round?:number,
  }
  export interface KnockoutPlayerInfoNtc{
       cfg_uuid?:string,
       game_uuid?:string,
       rid?:number,
       rank?:number,
       score?:number,
       reason?:number,
       state?:number,
       round?:number,
       total_player?:number,
       reward?:AwardItem[],
       svr_id?:string,
       contest_address?:number,
       regist_min_count?:number,
       prefer_left_count?:number[],
  }
  export interface KnockoutGameInfoReq{
       cfg_uuid?:string,
       game_uuid?:string,
       svr_id?:string,
       contest_address?:number,
  }
  export interface KnockoutGameInfoRes{
       errcode?:number,
       errcodedes?:string,
       cfg_uuid?:string,
       game_uuid?:string,
       state?:number,
       round?:number,
       left_table_count?:number,
       rank?:number,
       score?:number,
       total_player?:number,
  }
  export interface KnockoutRankReq{
       svr_id?:string,
       contest_address?:number,
       cfg_uuid?:string,
       game_uuid?:string,
  }
  export interface KnockoutRankPlayerInfo{
       rid?:number,
       score?:number,
       rank?:number,
       rolename?:string,
       logo?:string,
       sex?:number,
  }
  export interface KnockoutRankRes{
       errcode?:number,
       errcodedes?:string,
       cfg_uuid?:string,
       game_uuid?:string,
       rank_list?:KnockoutRankPlayerInfo[],
  }
  export interface UseCDKEYReq{
       code?:string,
  }
  export interface UseCDKEYRes{
       errcode?:number,
       errcodedes?:string,
       code?:string,
       reward?:AwardItem[],
  }
  export interface GetDuiJiangInfoReq{
       type?:number,
  }
  export interface DuiJiangItemInfo{
       goods_id?:number,
       goods_icon?:string,
       goods_name?:string,
       need_goods_id?:number,
       need_goods_num?:number,
       award?:AwardItem,
  }
  export interface GetDuiJiangInfoRes{
       errcode?:number,
       errcodedes?:string,
       item_list?:DuiJiangItemInfo[],
  }
  export interface UserExtraInfo{
       name?:string,
       phone?:string,
       address?:string,
  }
  export interface DuiJiangReq{
       type?:number,
       goods_id?:number,
       user_extra_info?:UserExtraInfo,
  }
  export interface DuiJiangRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       goods_id?:number,
       now_time?:number,
  }
  export interface RechargeReq{
       version?:Version,
       good_id?:number,
       pay_type?:number,
       option_data?:string,
       ios_pay_order?:string,
  }
  export interface RechargeRes{
       errcode?:number,
       errcodedes?:string,
       order_id?:string,
       pay_type?:number,
       good_id?:number,
       option_data?:string,
       ios_pay_order?:string,
  }
  export interface DeliverGoodNtc{
       order_id?:string,
       option_data?:string,
       awards?:AwardItem[],
  }
  export interface BindAOAReq{
       rid?:number,
  }
  export interface BindAOARes{
       errcode?:number,
       errcodedes?:string,
       actAddress?:string,
       tkey?:string,
  }
  export interface DonateReq{
       goods_id?:number,
       goods_num?:number,
  }
  export interface DonateRes{
       errcode?:number,
       errcodedes?:string,
       goods_id?:number,
       goods_num?:number,
  }
  export interface DonateRecordItem{
       id?:number,
       rid?:number,
       goods_id?:number,
       goods_num?:number,
       update_time?:number,
  }
  export interface DonateRecordSelfReq{
  }
  export interface DonateRecordSelfRes{
       errcode?:number,
       errcodedes?:string,
       list?:DonateRecordItem[],
  }
  export interface DonateRecordAllReq{
       hour24?:number,
       index?:number,
       page_size?:number,
  }
  export interface DonateRecordAllRes{
       errcode?:number,
       errcodedes?:string,
       hour24?:number,
       index?:number,
       size?:number,
       list?:DonateRecordItem[],
  }
  export interface KingCardNtc{
       award_item?:AwardItem,
  }
  export interface DzChangeNtc{
       dz_seat_index?:number,
       change_type?:number,
  }
  export interface DzScoreChangeNtc{
       rid?:number,
       seat_index?:number,
       base_score?:number,
       curscore?:number,
       change_type?:number,
  }
  export interface DzContinueNtc{
       rid?:number,
       seat_index?:number,
       action_timeout?:number,
  }
  export interface DzContinueReq{
       is_dz_continue?:number,
  }
  export interface DzContinueRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface DzContinueResultNtc{
       rid?:number,
       seat_index?:number,
       is_dz_continue?:number,
  }
  export interface BetWinInfo{
       rid?:number,
       winmoney?:number,
  }
  export interface GameEndResultNtc2Watch{
       play_rule_type?:number,
       game_type?:number,
       dz_winmoney?:number,
       winmoney?:number,
       rank_list?:RankPlayerInfo[],
       action_to_time?:number,
       record?:RecordCell[],
       road_node?:RoadNode,
       cards_zhuang?:number[],
       cards_xian?:number[],
       choushui_num?:number,
       dizhu_win_list?:number[],
       player_win_win_list?:number[],
       players_bet_win_list?:BetWinInfo[],
       rank_top_list?:RankPlayerInfo[],
       lucky?:RankPlayerInfo,
  }
  export interface QDZPlayerListNtc{
       qdz_players?:QDZPlayerInfo[],
  }
  export interface GetTableRankListReq{
  }
  export interface GetTableRankListRes{
       errcode?:number,
       errcodedes?:string,
       rank_list?:RankPlayerInfo[],
  }
  export interface BuryingPointReq{
       type_id?:number,
  }
  export interface BuryingPointRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface GetDetailInfoReq{
       room_type?:number,
  }
  export interface WinInfo{
       bet_index?:string,
       bet_num?:number,
       win_num?:number,
  }
  export interface DetailInfo{
       order_id?:string,
       rounds_id?:number,
       validbet?:number,
       total_win?:number,
       end_time?:number,
       win_info_list?:WinInfo[],
  }
  export interface GetDetailInfoRes{
       errcode?:number,
       errcodedes?:string,
       info_list?:DetailInfo[],
  }
  export interface GetClientIcoinRankReq{
       rid?:number,
  }
  export interface IconRankInfo{
       type_id?:number,
       room_type_ids?:number[],
  }
  export interface GetClientIcoinRankRes{
       errcode?:number,
       errcodedes?:string,
       icon_rank_list?:IconRankInfo[],
  }
  export interface GetSlotRankReq{
       game_type?:number,
       room_level?:number,
       type_id?:number,
  }
  export interface SlotRankInfo{
       rank?:number,
       rid?:number,
       rolename?:string,
       multiple?:number,
       update_time?:number,
  }
  export interface GetSlotRankRes{
       errcode?:number,
       errcodedes?:string,
       slot_rank_list?:SlotRankInfo[],
  }
  export interface DoOneSpinReq{
       line_count?:number,
       bets_num?:number,
       room_level?:number,
  }
  export interface ScoreOnWholeMatrix{
       type?:number,
       score?:number,
       multiple?:number,
  }
  export interface ScoreGroupOnOneLine{
       line_id?:number,
       element_id?:number,
       element_count?:number,
       score?:number,
       multiple?:number,
       from_right?:boolean,
  }
  export interface OneRowItems{
       items?:number[],
  }
  export interface DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       bonus_multiple?:number,
       bonus_score_list?:number[],
       bonus_random_score?:number[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       jackpot_win_point?:number,
  }
  export interface SlotBounsScoreReq{
  }
  export interface SlotBounsScoreRes{
       errcode?:number,
       errcodedes?:string,
       score?:number,
  }
  export interface SlotGameConfigReq{
       theme?:number,
       type?:number,
  }
  export interface SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       theme?:number,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       last_spin_bibei_difen?:number,
       history_bibei_record?:number[],
       maryGameInfo?:MaryGameInfo,
       free_spin_info?:SlotFreeSpinInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       bonus_score_list?:number[],
  }
  export interface ShuiHu_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface PlaySingleMaryGameInfo{
       inner_eles?:number[],
       inner_multiple?:number,
       outer_ele?:number,
       outer_multiple?:number,
  }
  export interface MaryGameInfo{
       play_results?:PlaySingleMaryGameInfo[],
       can_play_times?:number,
       multiple?:number,
       score?:number,
       cur_step?:number,
       score_on_lines?:number,
  }
  export interface ShuiHu_MaryGameNextStepReq{
       step?:number,
  }
  export interface ShuiHu_MaryGameNextStepRes{
       errcode?:number,
       errcodedes?:string,
       step?:number,
       is_finished?:boolean,
  }
  export interface ShuiHu_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       maryGameInfo?:MaryGameInfo,
       win_multiple?:number,
       spin_consume?:number,
       score_on_whole_matrix?:ScoreOnWholeMatrix,
       jackpot_win_point?:number,
  }
  export interface ShuiHu_SelectWhetherBibeiReq{
       is_do_bibei?:boolean,
  }
  export interface ShuiHu_SelectWhetherBibeiRes{
       errcode?:number,
       errcodedes?:string,
       is_do_bibei?:boolean,
       win_point?:number,
       history_bibei_record?:number[],
  }
  export interface ShuiHu_DoBibeiReq{
       select?:number,
  }
  export interface ShuiHu_DoBibeiRes{
       errcode?:number,
       errcodedes?:string,
       select?:number,
       dice_1?:number,
       dice_2?:number,
       accumulate_point?:number,
       win_multiple?:number,
       is_select_correct?:boolean,
  }
  export interface RankInfo{
       rank?:number,
       rid?:number,
       rolename?:string,
       photo?:string,
       win_coin?:number,
       vip?:number,
       player_level?:number,
       online_time?:number,
  }
  export interface GetRankInfoReq{
       rid?:number,
       type_id?:number,
  }
  export interface GetRankInfoRes{
       errcode?:number,
       errcodedes?:string,
       rank_list?:RankInfo[],
  }
  export interface GetBankInfoReq{
       rid?:number,
       is_use_for_update?:boolean,
  }
  export interface GetBankInfoRes{
       errcode?:number,
       errcodedes?:string,
       is_need_pwd?:boolean,
       bank_coin?:number,
       is_use_for_update?:boolean,
       is_phone_bind?:boolean,
       is_set_pwd?:boolean,
  }
  export interface OpenBankPwdReq{
       pwd?:string,
  }
  export interface OpenBankPwdRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface BankVercodeReq{
       rid?:number,
  }
  export interface BankVercodeRes{
       errcode?:number,
       errcodedes?:string,
       vercode?:string,
  }
  export interface ModifyBankPwdReq{
       pwd?:string,
       vercode?:string,
  }
  export interface ModifyBankPwdRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface LoginBankReq{
       pwd?:string,
  }
  export interface LoginBankRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface AccessBankReq{
       status?:number,
       coin?:number,
  }
  export interface AccessBankRes{
       errcode?:number,
       errcodedes?:string,
       bank_coin?:number,
  }
  export interface TransferReq{
       transfer_rid?:number,
       coin_num?:number,
  }
  export interface TransferRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface TransferInfo{
       transfer_rid?:number,
       transfer_name?:string,
       transfer_time?:string,
       transfer_coin_num?:number,
       transfer_fee_per?:number,
       from_rid?:number,
       from_name?:string,
       status?:number,
  }
  export interface TransferHistoryReq{
       rid?:number,
  }
  export interface TransferHistoryRes{
       errcode?:number,
       errcodedes?:string,
       transfer_list?:TransferInfo[],
  }
  export interface TransferConfirmationInfoReq{
       rid?:number,
  }
  export interface TransferConfirmationInfoRes{
       errcode?:number,
       errcodedes?:string,
       rid?:number,
       transfer_name?:string,
  }
  export interface CashMoneyReq{
       coin?:number,
  }
  export interface CashMoneyRes{
       errcode?:number,
       errcodedes?:string,
       coin?:number,
  }
  export interface CashRechargeNtc{
       type_id?:number,
       notice_msg?:string,
  }
  export interface FuLinMen_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface FuLinMen_DuiJinYuModel{
       is_duijinyu_model?:boolean,
       remain_free_spin_times?:number,
       coin_num?:number,
       total_win?:number,
  }
  export interface FuLinMen_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       free_spin_total_win?:number,
       is_free_spin_end?:boolean,
       duijinyu_total_win?:number,
       duijinyu_free_spin_time?:number,
       is_duijinyu_start?:boolean,
       is_duijinyu_end?:boolean,
       fumantang_award_point?:number,
  }
  export interface SlotFreeSpinInfo{
       remain_free_spin_times?:number,
       current_accumate_score?:number,
  }
  export interface DuiJinYuInfo{
       duijinyu_free_time?:number,
       last_item_rows?:OneRowItems[],
  }
  export interface FuLinMen_SlotGameConfigReq{
       type?:number,
  }
  export interface FuLinMen_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       duijinyu_info?:DuiJinYuInfo,
       dafu_base_value?:number,
       xiaofu_base_value?:number,
       fumantang_base_multiple?:number,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface FuLinMen_FuManTangAwardPoolReq{
       room_level?:number,
  }
  export interface FuLinMen_FuManTangAwardPoolRes{
       errcode?:number,
       errcodedes?:string,
       fumantang_pool_value?:number,
  }
  export interface JieBa_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface JieBa_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_eles_pos?:number[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       free_spin_total_win?:number,
       is_free_spin_end?:boolean,
       bonus_multiple_array?:OneRowItems[],
       bonus_init_free_times?:number,
       jackpot_win_point?:number,
  }
  export interface JieBa_BonusGameNextStepReq{
       step?:number,
       box_select?:number,
       total_step?:number,
  }
  export interface JieBa_BonusGameNextStepRes{
       errcode?:number,
       errcodedes?:string,
       step?:number,
       is_finished?:boolean,
  }
  export interface JieBa_BonusGameInfo{
       bonus_multiple_array?:OneRowItems[],
       cur_step?:number,
       bonus_init_free_times?:number,
       box_select_array?:number[],
  }
  export interface JieBa_SlotGameConfigReq{
       type?:number,
  }
  export interface JieBa_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       bonus_game_info?:JieBa_BonusGameInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface SanGuo_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface SanGuo_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       bonus_remain_point?:number,
       bonus_start_info?:SanGuo_BonusGameStartInfo,
       win_multiple?:number,
       spin_consume?:number,
  }
  export interface SanGuo_RobotSelectInfo{
       food_select?:number,
       is_success?:number,
       need_time?:number,
  }
  export interface SanGuo_BonusGameStartInfo{
       robotOne?:SanGuo_RobotSelectInfo[],
       robotTwo?:SanGuo_RobotSelectInfo[],
       total_time?:number,
       remain_play_time?:number,
  }
  export interface SanGuo_BonusGameSelectReq{
       food_select?:number,
  }
  export interface SanGuo_BonusGameSelectRes{
       errcode?:number,
       errcodedes?:string,
       food_select?:number,
       is_success?:number,
       need_time?:number,
  }
  export interface SanGuo_BonusGameEndNtc{
       is_max_multiple?:boolean,
       win_point?:number,
       win_multiple?:number,
       bonus_remain_point?:number,
  }
  export interface SanGuo_SlotGameConfigReq{
       type?:number,
  }
  export interface SanGuo_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       bonus_remain_point?:number,
       bonus_start_info?:SanGuo_BonusGameStartInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface RoadNode{
       state?:number,
       is_zhuangdui?:boolean,
       is_xiandui?:boolean,
       is_tianpai?:boolean,
  }
  export interface HHRoadNode{
       state?:number,
       card_type?:number,
  }
  export interface LHRoadNode{
       state?:number,
       card_type?:number,
  }
  export interface PropRoomInfo{
       room_type?:number,
       game_type?:number[],
       is_close_all?:boolean,
  }
  export interface PropRoomNtc{
       limit_room_info?:PropRoomInfo[],
  }
  export interface PropMoneyPageInfo{
       type_id?:number,
       status?:number,
  }
  export interface PropMoneyPageInfoNtc{
       limit_money_page_info?:PropMoneyPageInfo[],
  }
  export interface SlotJackPotPoolValReq{
       req_game_type?:number,
  }
  export interface SlotJackPotPoolValInfo{
       game_type?:number,
       jackpot_val_list?:number[],
       jackpot_val_limit_list?:number[],
  }
  export interface SlotJackPotPoolValRes{
       errcode?:number,
       errcodedes?:string,
       req_game_type?:number,
       info?:SlotJackPotPoolValInfo[],
  }
  export interface SlotSingleRoomJackPotPoolValReq{
       req_game_type?:number,
       req_room_level?:number,
  }
  export interface SlotSingleRoomJackPotPoolValRes{
       errcode?:number,
       errcodedes?:string,
       req_game_type?:number,
       req_room_level?:number,
       jackpot_val?:number,
  }
  export interface LZTanBao_SlotGameConfigReq{
       type?:number,
  }
  export interface LZTanBao_Status_info{
       total_bets_num?:number,
       eliminate_box?:number,
       longzhu_num?:number,
       level?:number,
       max_bets?:number,
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       room_level?:number,
  }
  export interface LZTanBao_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       longzhu_status_info?:LZTanBao_Status_info[],
  }
  export interface LZTanBao_DoOneSpinReq{
       room_level?:number,
       bets_num?:number,
       line_count?:number,
       test_score?:string,
  }
  export interface Pos{
       x?:number,
       y?:number,
  }
  export interface gem_item{
       one_line?:Pos[],
       score?:number,
  }
  export interface MatrixDataInfo{
       matrix_data?:OneRowItems[],
       gem_list?:gem_item[],
  }
  export interface LZTanBao_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       matrix_data_list?:MatrixDataInfo[],
       longzhu_status_info?:LZTanBao_Status_info,
       spin_consume?:number,
       win_multiple?:number,
       win_point?:number,
       jackpot_win_point?:number,
  }
  export interface LZTanBao_DoTanBaoReq{
       jubaopeng_index?:number,
       room_level?:number,
  }
  export interface LZTanBao_DoTanBaoRes{
       errcode?:number,
       errcodedes?:string,
       single_longzhu_coin?:number,
       longzhu_num?:number,
  }
  export interface RRShengCai_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface RRShengCai_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       free_spin_total_win?:number,
       is_free_spin_end?:boolean,
       jackpot_win_point?:number,
       is_need_select_free_type?:boolean,
  }
  export interface RRShengCai_FreeTypeSelectReq{
       room_level?:number,
       free_type?:number,
  }
  export interface RRShengCai_FreeTypeSelectRes{
       errcode?:number,
       errcodedes?:string,
       free_type?:number,
       free_spin_times?:number,
       free_spin_multiple?:number,
  }
  export interface RRShengCai_SlotGameConfigReq{
       type?:number,
  }
  export interface RRShengCai_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       is_need_select_free_type?:boolean,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       free_spin_multiple?:number,
  }
  export interface Line888_SlotGameConfigReq{
       type?:number,
  }
  export interface Line888_Status_info{
       total_win?:number,
  }
  export interface Line888_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       line888_status_info?:Line888_Status_info[],
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface Line888_DoOneSpinReq{
       room_level?:number,
       bets_num?:number,
       line_count?:number,
  }
  export interface Line888_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       ele_id?:number,
       win_free_times?:number,
       win_multiple?:number,
       win_point?:number,
       jackpot_win_point?:number,
       total_win?:number,
       spin_consume?:number,
  }
  export interface Line888_shoufenReq{
       room_level?:number,
  }
  export interface Line888_shoufenRes{
       errcode?:number,
       errcodedes?:string,
       shoufen_coin?:number,
  }
  export interface DJDL_SlotGameConfigReq{
       type?:number,
  }
  export interface DJDL_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface DJDL_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface DJDL_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       items?:number[],
       win_multiple?:number,
       win_point?:number,
       jackpot_win_point?:number,
       spin_consume?:number,
  }
  export interface Line9_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface Line9_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       maryGameInfo?:MaryGameInfo,
       win_multiple?:number,
       spin_consume?:number,
       jackpot_win_point?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
  }
  export interface Line9_MaryGameNextStepReq{
       step?:number,
  }
  export interface Line9_MaryGameNextStepRes{
       errcode?:number,
       errcodedes?:string,
       step?:number,
       is_finished?:boolean,
  }
  export interface YGBH_SlotGameConfigReq{
       type?:number,
  }
  export interface YGBH_TurnGameInfo{
       is_can_turn?:boolean,
       suipian_num?:number,
       bets_num?:number,
       bets_num_list?:number[],
  }
  export interface YGBH_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       theme?:number,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       turnGameInfos?:YGBH_TurnGameInfo[],
       free_spin_info?:SlotFreeSpinInfo,
       free_mode_type?:number,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       is_need_select_free_type?:boolean,
       free_zixi_line_num?:number,
  }
  export interface YGBH_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface YGBH_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       win_multiple?:number,
       spin_consume?:number,
       jackpot_win_point?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
       turnGameInfo?:YGBH_TurnGameInfo,
       is_need_select_free_type?:boolean,
       free_zixi_line_num?:number,
  }
  export interface YGBH_DoTurnReq{
       room_level?:number,
  }
  export interface YGBH_DoTurnRes{
       errcode?:number,
       errcodedes?:string,
       win_multiple?:number,
       win_point?:number,
       jackpot_win_point?:number,
  }
  export interface YGBH_FreeTypeSelectReq{
       room_level?:number,
  }
  export interface YGBH_FreeTypeSelectRes{
       errcode?:number,
       errcodedes?:string,
       free_mode_type?:number,
  }
  export interface JPM_BonusGameInfo{
       can_play_times?:number,
       cur_step?:number,
       total_step?:number,
       score?:number,
       bonus_random_score?:number[],
       picture_index?:number,
  }
  export interface RoleInfo{
       rid?:number,
       rolename?:string,
       logo?:string,
       coin?:number,
  }
  export interface JPM_SlotGameConfigReq{
       type?:number,
  }
  export interface JPM_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       maryGameInfo?:JPM_BonusGameInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       role_info_list?:RoleInfo[],
  }
  export interface JPM_DoOneSpinReq{
       bets_num?:number,
       line_count?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface JPM_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       win_multiple?:number,
       spin_consume?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
       maryGameInfo?:JPM_BonusGameInfo,
       jackpot_win_point?:number,
  }
  export interface JPM_BonusGameNextStepReq{
       step?:number,
       box_select?:number,
  }
  export interface JPM_BonusGameNextStepRes{
       errcode?:number,
       errcodedes?:string,
       step?:number,
       is_finished?:boolean,
  }
  export interface JPM_PlayerChangeNtc{
       role_info_list?:RoleInfo[],
  }
  export interface JPM_StatusReq{
       status?:number,
       room_level?:number,
  }
  export interface JPM_StatusRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface JDQS_SmallGameInfo{
       shot_list?:Pos[],
       kulou_nums?:number[],
       blood_num?:number,
  }
  export interface JDQS_BloodInfo{
       pos?:Pos,
       off_blood_num?:number,
  }
  export interface JDQS_MatrixInfo{
       item_rows?:OneRowItems[],
       score_group_on_lines?:ScoreGroupOnOneLine[],
       win_point?:number,
       jackpot_win_point?:number,
       win_multiple?:number,
       blood_infos?:JDQS_BloodInfo[],
       kulou_num?:number,
       blood_num?:number,
  }
  export interface JDQS_SlotGameConfigReq{
       type?:number,
  }
  export interface JDQS_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       small_game_infos?:JDQS_SmallGameInfo[],
  }
  export interface JDQS_DoOneSpinReq{
       bets_num?:number,
       line_count?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface JDQS_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       matrixs?:JDQS_MatrixInfo[],
       win_point?:number,
       win_free_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
       jackpot_win_point?:number,
       small_game_info?:JDQS_SmallGameInfo,
       free_final_win?:number,
  }
  export interface SMYH_SlotGameConfigReq{
       type?:number,
  }
  export interface SMYH_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface SMYH_DoOneSpinReq{
       bets_num?:number,
       line_count?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface SMYH_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       matrixs?:JDQS_MatrixInfo[],
       win_point?:number,
       win_free_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
       jackpot_win_point?:number,
  }
  export interface WUZETIAN_SlotGameConfigReq{
       type?:number,
  }
  export interface WUZETIAN_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       is_gold_free_model?:boolean,
       gold_free_item_list?:number[],
       bibei_result_list?:number[],
  }
  export interface WUZETIAN_DoOneSpinReq{
       bets_num?:number,
       line_count?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface WUZETIAN_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       win_multiple?:number,
       spin_consume?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
       jackpot_win_point?:number,
       is_gold_free_model?:boolean,
       gold_free_item_list?:number[],
       is_can_bibei?:boolean,
       bibei_result_list?:number[],
       is_gold_free_begin?:boolean,
  }
  export interface WUZETIAN_DoBibeiReq{
       select_color?:number,
       select_id?:number,
  }
  export interface WUZETIAN_DoBibeiRes{
       errcode?:number,
       errcodedes?:string,
       select_color?:number,
       select_id?:number,
       result_color?:number,
       result_id?:number,
       accumulate_point?:number,
       is_select_correct?:boolean,
  }
  export interface WUZETIAN_GiveUpBibeiReq{
  }
  export interface WUZETIAN_GiveUpBibeiRes{
       errcode?:number,
       errcodedes?:string,
       win_point?:number,
       jackpot_win_point?:number,
  }
  export interface CQBY_SlotGameConfigReq{
       type?:number,
  }
  export interface CQBY_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
       win_multiple?:number,
       win_point_all?:number,
       sceneid?:number,
       stageid?:number,
       is_in_small_game?:boolean,
  }
  export interface CQBY_DoOneSpinReq{
       bets_num?:number,
       line_count?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface CQBY_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       win_multiple?:number,
       spin_consume?:number,
       jackpot_win_point?:number,
       is_get_small_game?:boolean,
       wild_mutil?:number,
  }
  export interface CQBY_DoSelectSceneReq{
       select_scene?:number,
  }
  export interface CQBY_DoSelectSceneRes{
       errcode?:number,
       errcodedes?:string,
       select_scene?:number,
  }
  export interface CQBY_DoFightBossReq{
       select_stage?:number,
  }
  export interface CQBY_DoFightBossRes{
       errcode?:number,
       errcodedes?:string,
       win_point?:number,
       jackpot_win_point?:number,
       win_point_all?:number,
       sceneid?:number,
       stageid?:number,
       win_multiple?:number,
       line_win_point?:number,
  }
  export interface CurrentFish{
       rid?:number,
       fish_group?:number,
       fish_flag?:number,
       only_number?:number,
       progress?:number,
       status?:number,
       CategoryBitmask?:string,
       ContactTestBitmask?:string,
  }
  export interface FishPlayerInfo{
       rid?:number,
       pay_times?:number,
       weapon_type?:number,
       coin?:number,
       angle?:number,
       rolename?:string,
       coins?:number,
       index?:number,
  }
  export interface PushFishGroup{
       btide?:boolean,
       only_number?:number,
       fish_group?:number,
  }
  export interface FishWeaponInfo{
       rid?:number,
       game_type?:number,
       pay_times?:number,
       weapon_type?:number,
       coin?:number,
  }
  export interface FishWeapon{
       rid?:number,
       game_type?:number,
       fish_group?:number,
       fish_flag?:number,
       angle?:number,
       pay_times?:number,
       weapon_type?:number,
       lock_fish?:CurrentFish,
       coin?:number,
       only_number?:number,
       x?:number,
       y?:number,
       bitmask?:string,
  }
  export interface FishGeneral{
       ivalue?:number,
       bvalue?:boolean,
  }
  export interface FishDeath{
       rid?:number,
       fish_group?:number,
       fish_flag?:number,
       win_coin?:number,
       body_coin?:number,
       pay_times?:number,
       weapon_type?:number,
       only_number?:number,
       death?:boolean,
  }
  export interface FishOpenFire{
       rid?:number,
       angle?:number,
       coin?:number,
       weapon_type?:number,
       pay_times?:number,
       x?:number,
       y?:number,
       bitmask?:string,
  }
  export interface FishScreenPlayerInfo{
       fishs?:CurrentFish[],
       players?:FishPlayerInfo[],
  }
  export interface FishSpecialDeath{
       only_number?:number,
       fish_flag?:number,
       win_coin?:number,
       special_type?:number,
  }
  export interface FishGroupDeath{
       rid?:number,
       only_number?:number,
       fish_flag?:number,
       game_type?:number,
       deaths?:FishSpecialDeath[],
       pay_times?:number,
       weapon_type?:number,
       win_coin?:number,
       body_coin?:number,
  }
  export interface FISH_GameConfigReq{
       type?:number,
  }
  export interface FISH_GameConfigRes{
       errcode?:number,
       errcodedes?:string,
       theme?:number,
       type?:number,
       array1?:number[],
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface DoFishOperationReq{
       command?:number,
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       request_fish_info?:FishGeneral,
       weapon_info?:FishWeaponInfo,
       open_fire?:FishWeapon,
       attack_fish?:FishWeapon,
       lock_fish?:CurrentFish,
       special_fish_death?:FishGroupDeath,
  }
  export interface DoFishOperationRes{
       command?:number,
       errcode?:number,
       errcodedes?:string,
       fish_info?:FishScreenPlayerInfo,
       weapon_info?:FishWeaponInfo,
       open_fire?:FishOpenFire,
       fish_death?:FishDeath,
       lock_fish?:CurrentFish,
       push_fish_group?:PushFishGroup,
       tide?:FishGeneral,
       special_fish_group_death?:FishGroupDeath,
       special_fish_death?:FishSpecialDeath,
  }
  export interface DoFishKickPlayerLeaveTableNtc{
       msg?:string,
  }
  export interface GFXM_BonusGameInfo{
       bonus_multiple_array?:OneRowItems[],
       cur_step?:number,
       bonus_init_free_times?:number,
       box_select_array?:number[],
  }
  export interface GFXM_SlotGameConfigReq{
       type?:number,
  }
  export interface GFXM_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       bonus_game_info?:GFXM_BonusGameInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface GFXM_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface GFXM_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_eles_pos?:number[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       free_spin_total_win?:number,
       is_free_spin_end?:boolean,
       bonus_multiple_array?:OneRowItems[],
       bonus_init_free_times?:number,
       jackpot_win_point?:number,
  }
  export interface GFXM_BonusGameNextStepReq{
       step?:number,
       box_select?:number,
       total_step?:number,
  }
  export interface GFXM_BonusGameNextStepRes{
       errcode?:number,
       errcodedes?:string,
       step?:number,
       is_finished?:boolean,
  }
  export interface LHPlayerInfo{
       rid?:number,
       rolename?:string,
       logo?:string,
       lucky?:number,
       win_num_20?:number,
       total_score_20?:number,
       coins?:number,
       bigwinner?:number,
       win_point?:number,
       vip_level?:number,
  }
  export interface LHTablePlayerNtc{
       isend?:number,
       list?:LHPlayerInfo[],
       hh_road?:LHRoadNode,
       player_info?:LHPlayerInfo,
  }
  export interface LHAllCardsNtc{
       long_cards?:number[],
       hu_cards?:number[],
  }
  export interface AJDB_SmallItemInfo{
       id?:number,
       isopen?:boolean,
  }
  export interface AJDB_SmallLineInfo{
       infos?:AJDB_SmallItemInfo[],
       mutiple?:number,
  }
  export interface AJDB_SmallGameInfo{
       lines?:AJDB_SmallLineInfo[],
  }
  export interface AJDB_SlotGameConfigReq{
       type?:number,
  }
  export interface AJDB_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       all_smallgames?:AJDB_SmallGameInfo[],
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface AJDB_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface AJDB_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       score_eles_pos?:number[],
       win_multiple?:number,
       spin_consume?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       cur_other_lines?:AJDB_SmallLineInfo[],
       next_other_lines?:AJDB_SmallLineInfo[],
       base_win_point?:number,
  }
  export interface Fruit_Line11_DoOneSpinReq{
       line_count?:number,
       bets_num?:number,
       room_level?:number,
  }
  export interface Fruit_Line11_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       bonus_multiple?:number,
       bonus_score_list?:number[],
       bonus_random_score?:number[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       quanpan_win_point?:number,
       score_eles_pos?:number[],
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
  }
  export interface Fruit_Line11_SlotBounsScoreReq{
  }
  export interface Fruit_Line11_SlotBounsScoreRes{
       errcode?:number,
       errcodedes?:string,
       score?:number,
  }
  export interface BQTP_SlotGameConfigReq{
       type?:number,
  }
  export interface BQTP_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       last_room_level?:number,
       free_spin_info?:SlotFreeSpinInfo,
       room_bet_multiple?:number[],
       room_enter_limit?:number[],
  }
  export interface BQTP_MatrixInfo{
       item_rows?:OneRowItems[],
       score_eles_pos?:number[],
       win_point?:number,
       win_multiple?:number,
  }
  export interface BQTP_DoOneSpinReq{
       bets_num?:number,
       room_level?:number,
       test_score?:string,
  }
  export interface BQTP_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       matrixs?:BQTP_MatrixInfo[],
       remain_free_spin_times?:number,
       win_multiple?:number,
       spin_consume?:number,
       free_spin_total_win?:number,
       is_free_spin_end?:boolean,
  }
  export interface ARSBHZ_SlotGameConfigReq{
       type?:number,
  }
  export interface ARSBHZ_SlotGameConfigRes{
       errcode?:number,
       errcodedes?:string,
       theme?:number,
       type?:number,
       array1?:number[],
       last_spin_line_count?:number,
       last_spin_bets_num?:number,
       free_spin_info?:SlotFreeSpinInfo,
       room_enter_limit?:number,
       item_rows?:OneRowItems[],
  }
  export interface ARSBHZ_DoOneSpinReq{
       bets_num?:number,
       test_score?:string,
  }
  export interface ARSBHZ_DoOneSpinRes{
       errcode?:number,
       errcodedes?:string,
       item_rows?:OneRowItems[],
       win_point?:number,
       win_free_times?:number,
       score_group_on_lines?:ScoreGroupOnOneLine[],
       win_multiple?:number,
       spin_consume?:number,
       jackpot_win_point?:number,
       remain_free_spin_times?:number,
       is_free_spin_end?:boolean,
       free_spin_total_win?:number,
       free_all_times?:number,
  }
  export interface BlackJack21_tablesReq{
       page_index?:number,
       page_size?:number,
  }
  export interface BlackJack21_TableInfo{
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       current_num?:number,
       bet_nums?:number[],
       state?:number,
       logo_list?:string[],
       zhuang_way_list?:string[],
       is_del_table?:number,
       is_new_table?:number,
       game_type?:number,
       limitRange?:number[],
  }
  export interface BlackJack21_tablesRes{
       errcode?:number,
       errcodedes?:string,
       table_list?:BlackJack21_TableInfo[],
  }
  export interface BlackJack21_tablesNtc{
       table_info?:BlackJack21_TableInfo,
  }
  export interface BlackJack21_ClientPage_Req{
       page_index?:number,
  }
  export interface BlackJack21_ClientPage_Res{
       errcode?:number,
       errcodedes?:string,
  }
  export interface BlackJackQuickStartReq{
  }
  export interface BlackJackQuickStartRes{
       errcode?:number,
       errcodedes?:string,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface EnterTableReq{
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       invite_id?:number,
  }
  export interface EnterTableRes{
       errcode?:number,
       errcodedes?:string,
       gameinfo?:GameInfo,
       creator_prompter_type?:number,
  }
  export interface ReenterTableReq{
       version?:Version,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface ReenterTableRes{
       errcode?:number,
       errcodedes?:string,
       gameinfo?:GameInfo,
  }
  export interface SitdownTableReq{
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       roomsvr_seat_index?:number,
  }
  export interface SitdownTableRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface StandupTableReq{
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
  }
  export interface StandupTableRes{
       errcode?:number,
       errcodedes?:string,
  }
  export interface LeaveTableReq{
       version?:Version,
       id?:number,
       roomsvr_id?:string,
       roomsvr_table_address?:number,
       is_switch?:boolean,
  }
  export interface LeaveTableRes{
       errcode?:number,
       errcodedes?:string,
       is_switch?:boolean,
  }
  export interface BlackjackWayReq{
  }
  export interface PlayerWayInfo{
       obj_seat?:number,
       player_way_list?:string[],
  }
  export interface BlackjackWayRes{
       errcode?:number,
       errcodedes?:string,
       banker_way_list?:string[],
       players_way_list?:PlayerWayInfo[],
  }
  export interface BlackjackHistoryReq{
       type_id?:number,
       begin_time?:number,
       end_time?:number,
       page_index?:number,
       page_size?:number,
       id?:number,
  }
  export interface BlackJackWinInfo{
       obj_seat?:number,
       win_num?:number,
       bet_insurance_num?:number,
       win_insurance_nums?:number,
       cards_1?:number[],
       point_1?:number,
       bet_num_1?:number,
       hand_win_num_1?:number,
       victory_1?:string,
       is_double_bet1?:number,
       cards_2?:number[],
       point_2?:number,
       bet_num_2?:number,
       hand_win_num_2?:number,
       victory_2?:string,
       is_double_bet2?:number,
  }
  export interface BlackjackRoundsInfo{
       update_time?:number,
       round_id?:string,
       bet_num?:number,
       win_num?:number,
       coins?:number,
       win_info_list?:BlackJackWinInfo[],
  }
  export interface BlackjackHistoryRes{
       errcode?:number,
       errcodedes?:string,
       players_rounds_list?:BlackjackRoundsInfo[],
       id?:number,
       total_bet?:number,
       total_payout?:number,
       total_win?:number,
  }
}