import g from "../../g";

class NetHelper {
    private getIplistOnce = true;
    private fastestServer: string = "";
    private errCount = 0

    private connTest(server: string, servers201: string[], servers200: string[]): void {
        cc.log("test1=" + server)
        let host = server
        if (server.indexOf("://") !== -1) {
            host = server.substring(server.indexOf("://") + 3)
        }

        if (g.isDev) {
            servers201.push(host);
            return
        }

        let temp = "http://" + host + "/888666/"
        cc.log("test= " + temp)
        let start = Date.now();
        let xhr = new XMLHttpRequest();
        xhr.timeout = 20000;
        xhr.onreadystatechange = (ev) => {
            cc.log("state chg=" + xhr.readyState + ",sta=" + xhr.status)
        }
        xhr.onload = () => {
            if (xhr.status === 201) {
                servers201.push(host);
            } else if (xhr.status === 200) {
                servers200.push(host);
            }
            cc.log(xhr.status + "  " + temp + " opened, costs " + (Date.now() - start))
        }
        xhr.ontimeout = function () {
            cc.log("获取超时:" + temp)
        };
        xhr.onerror = () => {
            this.errCount++
            cc.log(temp + " error! ")
        };
        xhr.open("GET", temp);
        xhr.send();
    }

    getFastestServer(servers: string[]): Promise<string | undefined> {
        return new Promise(async resolve => {
            this.errCount = 0
            let servers200: string[] = [];
            let servers201: string[] = [];
            for (let s of servers) {
                this.connTest(s, servers201, servers200);
            }
            let checkcount = 0;
            let total = servers.length
            let checkTimer
            let okServers = await new Promise<string[]>(resolve => {
                checkTimer = setInterval(() => {
                    checkcount++;
                    if (this.errCount === total || checkcount > 15) {
                        cc.log("全err或超过15了")
                        resolve([])
                        return
                    }
                    let ok = [...servers201, ...servers200];
                    if (this.errCount === total - 1 && ok.length === 1) {
                        cc.log("只有一个没err，ok1个")
                        resolve(ok.slice(0, 1))
                        return
                    }

                    //0-15秒只要两个201返回就返回
                    if (servers201.length >= 2) {
                        cc.log("server201 ok len>=2,len=" + servers201.length)
                        resolve(servers201.slice(0, 2));
                        return;
                    }

                    let t0 = 4
                    let t1 = 8
                    if (checkcount >= t0 && checkcount <= t1) { //t0-t1秒，有任意两个节点返回就返回
                        if (ok.length >= 2) {
                            cc.log(`${t0}~${t1} oklen=${ok.length}`)
                            resolve(ok.slice(0, 2));
                            return;
                        }
                    } else if (checkcount > t1) {//t1-15秒，有任意一个节点返回就返回
                        if (ok.length >= 1) {
                            cc.log(`>${t1} oklen:${ok.length}`)
                            resolve(ok.slice(0, 2));
                            return;
                        }
                    }
                }, 1000);
            })
            cc.log("race over okservers:" + JSON.stringify(okServers))
            clearInterval(checkTimer);
            let rS: string = "";
            if (okServers.length === 2) {
                let idx = (Math.random() >= 0.5) ? 0 : 1;
                rS = okServers[idx];
            } else if (okServers.length === 1) {
                rS = okServers[0];
            }

            if (rS) {
                rS = "ws://" + rS
                resolve(rS);
            } else {
                cc.log("setTimeout no server");
                resolve();
            }
        });
    }
}

export default new NetHelper();