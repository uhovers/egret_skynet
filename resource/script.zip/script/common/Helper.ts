import g from "../g";
import { localeSettingList } from "./localeSettingList";
import GameData from "./net/GameData";
import { nullToZero } from "./util";

let chnNumChar = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"];
let chnUnitSection = ["", "万", "亿", "万亿", "亿亿"];
let chnUnitChar = ["", "十", "百", "千"];

function SectionToChinese(section) {
    let strIns = '', chnStr = '';
    let unitPos = 0;
    let zero = true;
    while (section > 0) {
        let v = section % 10;
        if (v === 0) {
            if (!zero) {
                zero = true;
                chnStr = chnNumChar[v] + chnStr;
            }
        } else {
            zero = false;
            strIns = chnNumChar[v];
            strIns += chnUnitChar[unitPos];
            chnStr = strIns + chnStr;
        }
        unitPos++;
        section = Math.floor(section / 10);
    }
    return chnStr;
}

let add0 = function (m) { return m < 10 ? '0' + m : m };

export function getLength(obj){
    let count = 0;
    for (let i in obj) {
        if (obj.hasOwnProperty(i)) {
            count++;
        }
    }
    return count;　　
}

//文字转换,数字转中文
export function numberToString(number) {
    let num = parseInt(number);
    let isFushu = false
    if(num<0){
        isFushu = true
        num = Math.abs(num)
    }
    if (num==null){
        return "零";
    }
    let unitPos = 0;
    let strIns = '', chnStr = '';
    let needZero = false;

    if (num === 0) {
        return chnNumChar[0];
    }

    while (num > 0) {
        let section = num % 10000;
        if (needZero) {
            chnStr = chnNumChar[0] + chnStr;
        }
        strIns = SectionToChinese(section);
        strIns += (section !== 0) ? chnUnitSection[unitPos] : chnUnitSection[0];
        chnStr = strIns + chnStr;
        needZero = (section < 1000) && (section > 0);
        num = Math.floor(num / 10000);
        unitPos++;
    }
    if(isFushu){
        chnStr = "负"+chnStr
    }
    return chnStr;
}

export function substringForleng(str,length) {
    if (length==null){
        length = 6
    }
    let resultstr = ""
    let l = str.length;
    let blen = 0;
    for (let i = 0; i < l; i++) {
        if ((str.charCodeAt(i) & 0xff00) != 0) {
            blen++;
        }
        blen++;
        resultstr = resultstr + str.charAt(i);
        if (blen >= length){
            break;
        }
    }
    if((l-1)<=resultstr.length){
        return str
    }else if (l > resultstr.length){
        resultstr = resultstr + "..."
    }
    return resultstr;
}

export function numToBigNum(num: number) {
    let sbTS = ',';
    let sbDP = '.';
    if (GameData.tbBaseInfo && GameData.tbBaseInfo.currency && (GameData.tbBaseInfo.currency=='ID2' || GameData.tbBaseInfo.currency=='IDR')) {
        sbTS = '.';
        sbDP = ',';
    }

    let str = ""
    let numstr1 = num.toFixed(2);
    let arr = numstr1.split('.')
    let numstr = arr[0];
    let isFushu = false
    if(numstr.charAt(0)=='-'){
        isFushu = true
        numstr = numstr.substring(1,numstr.length)
    }
    for(let i=0;i<numstr.length;i++){
        str = numstr.charAt(numstr.length - 1 - i) + str;
        if((i+1)%3==0){
            if(i<(numstr.length-1)){
                str = `${sbTS}${str}`;
            }
        }
    }
    if(isFushu){
        str = "-"+str
    }
    // if(arr[1]=="00"){
    //     return str;
    // }
    // if(arr[1].charAt(1)=="0"){
    //     return str+"."+arr[1].charAt(0);
    // }

    return `${str}${sbDP}${arr[1]}`;
}

export function formatTime(shijianchuo) {
    //shijianchuo是整数，否则要parseInt转换
    let time = new Date(shijianchuo);
    let y = time.getFullYear();
    let m = time.getMonth() + 1;
    let d = time.getDate();
    let h = time.getHours();
    let mm = time.getMinutes();
    let s = time.getSeconds();
    return mm + ':' + add0(s);
}

export function formatTimeYear(shijianchuo) {
    //shijianchuo是整数，否则要parseInt转换
    let time = new Date(shijianchuo);
    let y = time.getFullYear();
    let m = time.getMonth() + 1;
    let d = time.getDate();
    let h = time.getHours();
    let mm = time.getMinutes();
    let s = time.getSeconds();
    return y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
}

const localStorage: Storage = cc.sys.localStorage;
export function setItem(key: string, value: any) {
    localStorage.setItem(key, value);
};

export function getItem(key: string, defvalue: any) {
    var value = localStorage.getItem(key);
    if (value == null || value == "") {
        localStorage.setItem(key, defvalue);
        value = defvalue;
    }
    return value
}

let isInteger = function (n: number) {
    return n%1 === 0;
}
let fixedTo = function (num: number, d:number=2) {
    let s = num.toFixed(d)
    // cc.log('===== s: ', s);
    let arr = s.split('')
    let newN = '';
    for (let i = 0; i < 7; i++) {
        const e = arr[i]
        if (newN.length===5) {
            // cc.log(newN.indexOf('.'));
            if (newN.indexOf('.')>0 && e) {
                newN = newN + e;
                break
            } else {
                break
            }
        } else {
            newN = newN + e;
        }
    }
    return newN;
}
let mPow10 = function (d:number) {
    return Math.pow(10, d);
}

let dw = [
    {min: 24, max: 26, num: 21, dw: 'ac'},
    {min: 21, max: 23, num: 18, dw: 'ab'},
    {min: 18, max: 20, num: 15, dw: 'aa'},
    {min: 15, max: 17, num: 12, dw: 't'},
    {min: 12, max: 14, num: 9, dw: 'b'},
    {min: 9, max: 11, num: 6, dw: 'm'},
    {min: 6, max: 8, num: 3, dw: 'k'},
]

export function transGoldNum(gold) {
    let goldNum = nullToZero(gold);
    let goldStr = '' + goldNum;
    // cc.log(goldNum);
    if (!isInteger(goldNum)) {
        return goldStr;
    }
    dw.forEach((ele) => {
        if (goldNum>=mPow10(ele.min-1) && goldNum<mPow10(ele.max)) {
            goldStr = fixedTo(goldNum/mPow10(ele.num)) + ele.dw;
            return goldStr;
        }
    })
    return goldStr;
}
