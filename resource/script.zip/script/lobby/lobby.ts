import { addSingleEvent, tos, toj, fitCanvas, shiftSound, soundCfg, nullToZero, transMoney, loadSprite } from "../common/util";
import NetProxy from "../common/net/NetProxy";
import GameData from "../common/net/GameData";
import { showTip, showLoading, hideLoading, showConfirm } from '../common/ui';
import Base from "../common/Base";
import AppEventManager from "../common/AppEventManager";
import { EVENTTYPE } from "../common/enum";
import { numToBigNum } from '../common/Helper';
import GameInfo from "./gameInfo";
import HjkHistory from "../g-hjk/hjkHistory";
import g from "../g";
import { LangSprite } from "../g-share/resCfg";

enum DISPLAY_STATE_BLACKJACK {
    /** 初始化未有玩家玩耍 */
    INIT_START = 0,      
    /**  等待开始 */
    WAIT_START = 1,      
    /** 投注中 */
    BET_PROGRESS = 2,    
    /** 开牌 */
    KAIPAI_PROGRESS = 3,
    /** 维护中 */
    MAINTENANCE = 4,
}

const {ccclass, property} = cc._decorator;

@ccclass
export default class Lobby extends Base {
    @property(cc.Node)
    canvas: cc.Node = undefined;

    @property({type: cc.Node, tooltip: '菜单节点'})
    private menuBg: cc.Node = undefined;

    @property(cc.Node)
    private touchBg: cc.Node = undefined;

    @property(cc.Sprite)
    private audioSp: cc.Sprite = undefined;

    @property(cc.Sprite)
    private gameInfoSp: cc.Sprite = undefined;

    @property(cc.Sprite)
    private historySp: cc.Sprite = undefined;

    @property(cc.Label)
    money: cc.Label = undefined;

    @property(cc.Node)
    wallet: cc.Node = undefined;

    @property(cc.Node)
    private touchWallet: cc.Node = undefined;

    @property(cc.Node)
    backBtn: cc.Node = undefined;

    @property(cc.Node)
    content: cc.Node = undefined;

    @property(cc.Node)
    roomItem: cc.Node = undefined;

    @property(cc.SpriteFrame)
    private sp: cc.SpriteFrame[] = [];

    @property(cc.Sprite)
    quickStartSp: cc.Sprite = undefined;

    @property(GameInfo)
    private gameInfo: GameInfo = undefined;

    @property(HjkHistory)
    private hjkHistory: HjkHistory = undefined;

    private roomNodes: {[id: number]: {item: cc.Node, data: GameMsg.BlackJack21_TableInfo}} = {};
    private _menuBgPlayingAnim = false;
    private limitLen = 14;

    onLoad(){
        // GameData.tbBaseInfo.coins =0;
        // GameData.tbBaseInfo.e_wallet = 0;

        fitCanvas(this.canvas);
        this.menuBg.scaleY = 0;
        this.touchWallet.scaleY = 0;
    
        this.touchBg.on(cc.Node.EventType.TOUCH_START, ()=>{this.menuAnim();});
        this.touchBg["_touchListener"].setSwallowTouches(false);

        this.touchWallet.on(cc.Node.EventType.TOUCH_START, ()=>{this.walletAnim();});
        this.touchWallet["_touchListener"].setSwallowTouches(false);

        loadSprite(this.quickStartSp, LangSprite.quick_start);
        loadSprite(this.gameInfoSp, LangSprite.lb_info);
        let audioSprite = soundCfg()>0 ? LangSprite.lb_close_audio : LangSprite.lb_open_audio;
        loadSprite(this.audioSp, audioSprite)
        loadSprite(this.historySp, LangSprite.lb_history);

        this.limitLen = g.isLandscape ? 242 : 163
    }

    start(){
        AppEventManager.addEventHandler(this);

        this.roomItem.active = false;
        this.backBtn.active = !g.thirdConfig || !g.thirdConfig.isSingleGame;
        if (g.thirdConfig && g.thirdConfig.isSingleGame && g.thirdConfig.logo!=='') {
            cc.assetManager.loadRemote(g.thirdConfig.logo, (err, text:cc.Texture2D)=>{
                if (!err) {
                    this.backBtn.active = true;
                    let sp = new cc.SpriteFrame(text);
                    this.backBtn.getComponent(cc.Button).transition = cc.Button.Transition.SCALE;
                    this.backBtn.setContentSize(cc.size(155, 30))
                    this.backBtn.getComponent(cc.Sprite).spriteFrame = sp;
                    this.backBtn.getComponent(cc.Widget).updateAlignment();
                    this.money.node.parent.getComponent(cc.Widget).left = 165;
                    this.money.node.parent.getComponent(cc.Widget).updateAlignment();
                }
            })
        }


        this.setMyMoney();

        this.getTableList();

        // 加载游戏场景
        cc.director.preloadScene(g.GAME_SCENE);
    }

    getTableList(){
        NetProxy.BlackJack21_tablesReq((data: GameMsg.BlackJack21_tablesRes) => {
            if (data.errcode==null) {
                this.showRooms(data.table_list);
                AppEventManager.notifyEvent(EVENTTYPE.EVENT_BlackJack21_tablesRes);
            } else {
                // cc.log(data.errcodedes)
                NetProxy.isRepeatNtc = true;
                NetProxy.closeSocket();
                let str: string = i18n.languages[g.language]['g_net_error'] || '';
                let conf = showConfirm({content: str, sure: true});
                conf.sureHandler = () => {
                    showLoading();
                    g.postBackToLobby();
                }
            }
        });
    }

    setMyMoney(){
        this.money.string = numToBigNum(nullToZero(GameData.tbBaseInfo.coins)+nullToZero(GameData.tbBaseInfo.e_wallet));

        this.wallet.getChildByName('item').active = nullToZero(GameData.tbBaseInfo.coins)>0;
        this.wallet.getChildByName('item1').active = nullToZero(GameData.tbBaseInfo.e_wallet)>0;
        this.wallet.getChildByName('item').getChildByName('money').getComponent(cc.Label).string = numToBigNum(nullToZero(GameData.tbBaseInfo.coins));
        this.wallet.getChildByName('item1').getChildByName('money').getComponent(cc.Label).string = numToBigNum(nullToZero(GameData.tbBaseInfo.e_wallet));
    }

    onAppEvent(eventType: EVENTTYPE, data: any){
        if (eventType===EVENTTYPE.EVENT_BlackJack21_tablesNtc) {
            let tabInfo: GameMsg.BlackJack21_TableInfo = data.table_info;
            if (tabInfo.is_del_table===1) {
                let room = this.roomNodes[tabInfo.id];
                if (room && room.item && room.item.isValid) {
                    room.item.active = false;
                    this.roomNodes[tabInfo.id] = undefined;
                }
            } else if(tabInfo.is_new_table===1){
                this.getTableList();
            } else{
                let room = this.roomNodes[tabInfo.id];
                if (room && room.item && room.item.isValid) {
                    tabInfo.limitRange = room.data.limitRange;
                    this.updateItem(room.item, tabInfo);
                }
            }
        }else if (eventType===EVENTTYPE.EVENT_GoodsNtc) {
            this.setMyMoney();
        }
    }

    showRooms(tablelist: GameMsg.BlackJack21_TableInfo[]){
        this.content.removeAllChildren();
        for (let i = 0; i < tablelist.length; i++) {
            let item = cc.instantiate(this.roomItem);
            item.parent = this.content;

            item.active = true;
            let data = tablelist[i];
            this.roomNodes[data.id] = {item: item, data: data};
            this.updateItem(item, data);
        }
    }

    updateItem(item: cc.Node, data: GameMsg.BlackJack21_TableInfo){
        let table = item.getChildByName('table')
        table.children.forEach((p, i) => {
            // let color = data.logo_list[i]==='' ? cc.color(100,100,100) : cc.color(255,255,255);
            // let opactity = data.logo_list[i]==='' ? 150 : 255;
            // p.color = color;
            // p.opacity = opactity;
            p.getChildByName('p_yes').active = data.logo_list[i]!='';
        });

        item.getChildByName('table_id').getChildByName('id').getComponent(cc.Label).string = ''+data.game_type;

        loadSprite(item.getChildByName('bet').getChildByName('dz').getComponent(cc.Sprite), LangSprite.blackjack_limit);

        let limitStr =  data.limitRange.length>1 ? `${transMoney(data.limitRange[0])}-${transMoney(data.limitRange[data.limitRange.length-1])}` : `-`;
        let limit = item.getChildByName('bet').getChildByName('limit')

        limit.getComponent(cc.Label).string = limitStr
        item.getChildByName('bet').getComponent(cc.Layout).updateLayout()
    
        let betNode = item.getChildByName('bet')
        let timer = setTimeout(() => {
            // console.error('=== ', betNode.width);
            if (this.limitLen/betNode.width<0.85) {
                betNode.scaleX = this.limitLen/betNode.width
                betNode.scaleY = 0.85
                // console.error('111111111: ', betNode.scaleX);
            }else{
                betNode.scale = 0.85
                // console.error('222222222: ', betNode.scaleX);
            }
            clearTimeout(timer)
        }, 300);

        let state = item.getChildByName('statebg').getChildByName('state').getComponent(cc.Sprite);
        item.getChildByName('maintain').active = data.state===DISPLAY_STATE_BLACKJACK.MAINTENANCE;
        switch (data.state) {
            case DISPLAY_STATE_BLACKJACK.WAIT_START:
                loadSprite(state, LangSprite.state_resting);
                break;
            case DISPLAY_STATE_BLACKJACK.BET_PROGRESS:
                loadSprite(state, LangSprite.state_beting);
                break;
            case DISPLAY_STATE_BLACKJACK.KAIPAI_PROGRESS:
                loadSprite(state, LangSprite.state_opening);
                break;
            case DISPLAY_STATE_BLACKJACK.MAINTENANCE:
                loadSprite(state, LangSprite.state_maintain);
                break;
            default:
                loadSprite(state, LangSprite.state_resting);
                break;
        }
        
        // 庄家牌路
        let lu = item.getChildByName('data')
        lu.children.forEach(n => { n.active = false; });
        let luData = data.zhuang_way_list;
        for (let i = 0; i < luData.length; i++) {
            if (i>=11*8) break;
            let n: cc.Node;
            if (i<=lu.children.length-1) {
                n = lu.children[i]
            } else {
                n = cc.instantiate(lu.children[0]);
                n.parent = lu;
            }
            n.active = true;
            let sp = n.getChildByName('sp');
            let lb = n.getChildByName('lb');
            if (luData[i]==='BJ' || luData[i]==='B') {
                sp.active = true;
                sp.getComponent(cc.Sprite).spriteFrame = luData[i]==='B' ? this.sp[1] : this.sp[0]; 
                lb.active = false;
            } else {
                sp.active = false;
                lb.active = true;
                lb.getComponent(cc.Label).string = luData[i];
            }
        }

        let handler = new cc.Component.EventHandler();
        handler.target = this.node;
        handler.component = cc.js.getClassName(this);
        handler.handler = "enterGame";
        handler.customEventData = tos(data);
        item.getComponent(cc.Button).clickEvents[0] = handler;
    }

    enterGame(event, custom){
        cc.log('==='+ custom)
        let data: GameMsg.BlackJack21_TableInfo = toj(custom);
        showLoading();
        NetProxy.EnterTableReq(data.id, data.roomsvr_id, data.roomsvr_table_address, (data: GameMsg.EnterTableRes) => {
            if (data.errcode==null) {
                NetProxy.stopReceiveMsg();
                GameData.gameInfo = data.gameinfo;

                g.postEnterRoom();
                cc.director.loadScene(g.GAME_SCENE, () => {hideLoading();});
            } else {
                cc.log(data.errcodedes);
                hideLoading();
                let str = i18n.languages[g.language]['g_room_maintain'] || '';
                showTip(str);
            }
        });
    }

    onDestroy(){
        AppEventManager.removeEventHandler(this);
    }

    private walletAnim() {
        if (this._menuBgPlayingAnim) {
            return;
        }
        this._menuBgPlayingAnim = true;
        let scaleY = this.touchWallet.scaleY===0 ? 1 : 0;
        cc.tween(this.touchWallet).to(0.1, {scaleY: scaleY}).call(()=>{this._menuBgPlayingAnim=false}).start();
    }

    private onClickWallet() {
        if (nullToZero(GameData.tbBaseInfo.coins)<=0 && nullToZero(GameData.tbBaseInfo.e_wallet)<=0) {
            return;
        }
        this.menuBg.scaleY = 0;
        this.walletAnim();
    }

    private onClickBack() {
        this.menuBg.scaleY = 0;
        this.touchWallet.scaleY = 0;
        if (g.thirdConfig && !g.thirdConfig.isSingleGame) {
            g.postBackToLobby();
        }else if(g.thirdConfig && g.thirdConfig.logoUrl && g.thirdConfig.logoUrl!==''){
            // window.location.href = g.thirdConfig.logoUrl;
            window.open(g.thirdConfig.logoUrl, '_blank')
        }
    }

    private menuAnim(){
        this.touchWallet.scaleY = 0;
        if (this._menuBgPlayingAnim) {
            return;
        }
        this._menuBgPlayingAnim = true;
        let scaleY = this.menuBg.scaleY===0 ? 1 : 0;
        cc.tween(this.menuBg).to(0.1, {scaleY: scaleY}).call(()=>{this._menuBgPlayingAnim=false}).start();
    }

    private onClickMenu() {
        this.menuAnim();
        // this.hjkAudio.playBtn1();
    }

    private onClickGameInfo() {
        this.menuAnim();
        // this.hjkAudio.playBtn1();
        this.gameInfo.node.active = true;
        this.gameInfo.init();
    }

    private onClickAudio() {
        shiftSound();
        let audioSprite = soundCfg()>0 ? LangSprite.lb_close_audio : LangSprite.lb_open_audio;
        loadSprite(this.audioSp, audioSprite)
    }

    private onClickHistory() {
        this.menuAnim();
        if (GameData.tbBaseInfo.user_type===-1) {   // 游客
            let str = i18n.languages[g.language]['g_visitors_cannot'] || '';
            showConfirm({ content: str, sure: true });
            return
        }
        this.hjkHistory.node.active = true;
        this.hjkHistory.init();
        // this.hjkAudio.playBtn1();
    }

    private onClickQuickStart() {
        showLoading();
        NetProxy.BlackJackQuickStartReq((data: GameMsg.BlackJackQuickStartRes) => {
            if (data.errcode==null) {
                NetProxy.EnterTableReq(data.id, data.roomsvr_id, data.roomsvr_table_address, (msg: GameMsg.EnterTableRes) => {
                    if (msg.errcode==null) {
                        NetProxy.stopReceiveMsg();
                        GameData.gameInfo = msg.gameinfo;

                        g.postEnterRoom();
                        cc.director.loadScene(g.GAME_SCENE, () => {hideLoading();});
                    } else {
                        cc.log(msg.errcodedes);
                        hideLoading();
                        let str = i18n.languages[g.language]['g_room_maintain'] || '';
                        showTip(str);
                    }
                });
            } else {
                cc.log(data.errcodedes);
                hideLoading();
                let str = i18n.languages[g.language]['g_room_maintain'] || '';
                showTip(str);
            }
        });
    }
}
