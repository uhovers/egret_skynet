import { loadSprite } from "../common/util";
import g from "../g";
import popActionBox from "../g-share/popActionBox";
import { LangSprite } from "../g-share/resCfg";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameInfo extends popActionBox {
    
    @property(cc.Sprite)
    titleSp: cc.Sprite = undefined;

    @property(cc.Sprite)
    infoSp: cc.Sprite = undefined;

    autoDestroy = false;

    start(){
        
    }

    async init(){
        loadSprite(this.titleSp, LangSprite.gameInfo_title);
        let path = g.isLandscape ? LangSprite.help_land : LangSprite.help;
        await loadSprite(this.infoSp, path)
        this.infoSp.getComponent(cc.Widget).updateAlignment();
        this.openAnim(() => {
            this.titleSp.getComponent(cc.Widget).updateAlignment();
        });        
    }
}
