import HjkAudio from "../g-hjk/hjkAudio";

const { ccclass, property } = cc._decorator;

enum STYLE { Normal, Alert }

@ccclass
export default class Ticker extends cc.Component {

    @property(HjkAudio)
    audio: HjkAudio = undefined;

    @property(cc.Sprite)
    private spriteTimer: cc.Sprite = undefined;

    @property(cc.Node)
    bgAni: cc.Node = undefined

    @property(cc.Label)
    lab: cc.Label = undefined

    @property({ type: cc.Enum(STYLE) })
    private style: STYLE = STYLE.Alert

    private totalTime: number = 0;
    private proTimer;
    private scaleNum = 0;

    timeEndHandler: () => void;
    isPlayAudio = false;

    onLoad() {
        this.scaleNum = this.bgAni.scale
    }

    show(time: number, isAudio=false): void {
        this.hide();
        this.isPlayAudio = isAudio;
        this.node.active = true
        this.spriteTimer.node.color = cc.Color.GREEN;
        this.spriteTimer.fillRange = 1;
  
        let t = Math.round(time)
        this.totalTime = t;
        this.lab.string = t.toString()
        this.lab.node.color = cc.Color.GREEN;
        this.lab.node.scale = 1;
        this.unschedule(this.cd)
        this.schedule(this.cd, 1, t, 1)

        if (this.proTimer) this.unschedule(this.proTimer);
        let r1 = this.isApple() ? 0.0166666 / t : 0.016666666 / t;
        let interval = this.isApple() ? 0.01222 : 0.0161;
        this.schedule(this.proTimer = () => {
            this.spriteTimer.fillRange -= r1;
            // let ratio = Math.abs(this.spriteTimer.fillRange);
            // let r = Math.min(255, (1-ratio) * 2 * 255);
            // let g = Math.min(255, ratio * 2 * 255);
            // this.spriteTimer.node.color = cc.color(r, g, 0);
        }, interval);
        this.node.stopAllActions()
    }

    /**
     * 判断是否为苹果设备
     */
    private isApple() {
        let info = navigator.userAgent.toLowerCase();
        // console.log(info);
        return Boolean(info.match(/iphone|ipod|ipad/ig));
    }

    hide(): void {
        this.timeEndHandler = undefined;
        this.unschedule(this.cd)
        this.unschedule(this.proTimer);
        this.node.stopAllActions()
        this.node.active = false;
        this.lab.node.stopAllActions()
        this.lab.node.scale = 1;
        if (this.bgAni) {
            this.bgAni.stopAllActions()
            this.bgAni.opacity = 255
            this.bgAni.scale = this.scaleNum;
        }
        this.spriteTimer.fillRange = 0;
    }

    private cd() {
        let t = +this.lab.string || 0
        t--
        t = Math.max(t, 0)
        
        switch (this.style) {
            case STYLE.Normal:
                if (t > 0 && this.node.active) {
                    this.lab.string = t.toString()
                }
                break
            case STYLE.Alert:
                this.lab.node.scale = 1;
                if (t <= 3) {
                    this.spriteTimer.node.color = cc.Color.RED;
                    this.lab.node.color = cc.Color.RED;
                    this.lab.node.stopAllActions()
                    this.lab.node.opacity = 255
                    this.lab.node.scale = 1;
                    if (t != 0 && this.isPlayAudio){
                        this.audio.timeCountDown();
                    }
                    this.lab.node.runAction(cc.sequence(cc.scaleTo(0.1, 1.5), cc.scaleTo(0.1, 1)))
                }
                this.lab.string = t.toString()
                break
        }
        if (t<=0) {
            if (this.timeEndHandler) {
                this.timeEndHandler();
                this.timeEndHandler = undefined;
            }
            this.hide();
        }
    }
}
