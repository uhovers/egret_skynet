import Base from "../common/Base";
import AppEventManager from "../common/AppEventManager";
import Game from "./game";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameEvent<T extends Game> extends Base {

    protected game: T;

    onLoad(){
        AppEventManager.addEventHandler(this)
    }

    init(g: T){
        this.game = g;
    }

    onDestroy(){
        AppEventManager.removeEventHandler(this)
    }
}
