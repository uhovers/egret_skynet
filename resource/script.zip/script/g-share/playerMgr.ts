import Player from "./player";
import Game from "./game";

const {ccclass, property} = cc._decorator;

@ccclass
export default class PlayerMgr<T1 extends Player, T2 extends Game> extends cc.Component {
    @property({ type: [Player], tooltip: "玩家节点组"})
    protected players: T1[] = [];

    protected game: T2;

    /**
     * 
     * @param g T2
     */
    setGame(g: T2){
        this.game = g;
        this.players.forEach((player, i) => {
            player.seatlb = i;
            player.init(this.game);
        });
    }

}
