const {ccclass, property} = cc._decorator;

@ccclass
export default class ButtonSafe extends cc.Component {

    @property({type: cc.Float, tooltip: '按钮保护时间,指定间隔只能点击一次'})
    private safeTime = 0.5;

    @property({tooltip: '按钮保护模式,冷却时间是否可点击'})
    private isEnable = false;

    private touching = false;

    private clickEvents: cc.Component.EventHandler[] = [];

    start () {
        let button = this.getComponent(cc.Button);
        if (!button) return;

        this.clickEvents = button.clickEvents;
        this.node.on('click', () => {
            if (this.isEnable) {
                button.interactable = false;
                this.scheduleOnce(() => {
                    button.interactable = true;
                }, this.safeTime);
            } else {
                if (this.touching) return;
                button.clickEvents = [];
                this.touching = true;
                this.scheduleOnce(() => {
                    this.touching = false;
                    button.clickEvents = this.clickEvents;
                }, this.safeTime);
            }
        }, this);
    }
}
