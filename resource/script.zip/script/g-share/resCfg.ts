import g from "../g";

export let LangSprite = {
    // help
    help_land: `help_land`,
    help: `help`,

    // button
    btx_1: `btn_label/btx_1`,
    double_btn1: `btn_label/double_btn1`,
    hit_btn1: `btn_label/hit_btn1`,
    split_btn1: `btn_label/split_btn1`,
    stand_btn1: `btn_label/stand_btn1`,
    tx_1: `btn_label/tx_1`,
    quick_start: `btn_label/quick_start`,

    // label
    banker: `label/banker`,
    beting_fail: `label/beting_fail`,
    beting_success: `label/beting_success`,
    blackjack_limit: `label/blackjack_limit`,
    blackjack_xinxi_id: `label/blackjack_xinxi_id`,
    blackjack_xinxi_juhao: `label/blackjack_xinxi_juhao`,
    blackjack_xinxi_jushu: `label/blackjack_xinxi_jushu`,
    blackjack_ziti_baoxian: `label/blackjack_ziti_baoxian`,
    blackjack_ziti_btn_zuoxia: `label/blackjack_ziti_btn_zuoxia`,
    blackjack_ziti_dizhu: `label/blackjack_ziti_dizhu`,
    blackjack_ziti_jiesuan_he: `label/blackjack_ziti_jiesuan_he`,
    blackjack_ziti_jiesuan_shu: `label/blackjack_ziti_jiesuan_shu`,
    blackjack_ziti_jiesuan_ying: `label/blackjack_ziti_jiesuan_ying`,
    blackjack_ziti_tips: `label/blackjack_ziti_tips`,
    gameInfo_title: `label/gameInfo_title`,
    last_round: `label/last_round`,
    lb_back: `label/lb_back`,
    lb_close_audio: `label/lb_close_audio`,
    lb_history: `label/lb_history`,
    lb_info: `label/lb_info`,
    lb_open_audio: `label/lb_open_audio`,
    result_lose: `label/result_lose`,
    result_surrender: `label/result_surrender`,
    result_win: `label/result_win`,
    state_beting: `label/state_beting`,
    state_bx: `label/state_bx`,
    state_maintain: `label/state_maintain`,
    state_opening: `label/state_opening`,
    state_resting: `label/state_resting`,
    state_tx: `label/state_tx`,
    state_xz: `label/state_xz`,
}

