import { addSingleEvent } from "../common/util";
import Base from "../common/Base";

const {ccclass, property} = cc._decorator;

@ccclass
export default class popActionBox extends Base {
    @property(cc.Node)
    protected nodeBg: cc.Node = undefined;

    @property(cc.Node)
    protected nodeBox: cc.Node = undefined;

    @property(cc.Button)
    protected btnClose: cc.Button = undefined;

    private bgOpacity:number;
    autoDestroy = false;

    protected onLoad(){
        if (this.btnClose) {
            let handler = new cc.Component.EventHandler();
            handler.target = this.node;
            handler.component = cc.js.getClassName(this);
            handler.handler = 'onClickClose';
            addSingleEvent(this.btnClose, handler);
        }
        if (this.nodeBg) {
            this.nodeBg.active = false;
            this.bgOpacity = this.nodeBg.opacity;
        }
        this.nodeBox.active = false;
    }

    protected start(){
        this.openAnim()
    }

    openAnim(cb?:Function){
        this.node.active = true;
        this.node.position = cc.Vec3.ZERO;
        let animTime = 0.3;
        if (this.nodeBg) {
            this.nodeBg.active = true;
            this.nodeBg.opacity = 0;
            this.nodeBg.runAction(cc.fadeTo(animTime, this.bgOpacity))
        }
        this.nodeBox.active = true;
        this.nodeBox.scale = 0;
        this.nodeBox.runAction(cc.sequence(
            cc.scaleTo(animTime, 1, 1).easing(cc.easeBackOut()),
            cc.callFunc(() => {
                if (cb) {
                    cb();
                }
            })
        ));
    }

    closeAnim(cb?: Function){
        let animTime = 0.3;
        if (this.nodeBg) {
            this.nodeBg.runAction(cc.fadeTo(animTime, 0))
        }
        this.nodeBox.runAction(cc.sequence(
            cc.scaleTo(animTime, 0),
            cc.callFunc(() => {
                if (cb && typeof cb === "function")
                    cb();
                this.node.active = false;
                if (this.autoDestroy) {
                    this.node.removeFromParent(true);
                    this.node.destroy();
                }
            })
        ));
    }

    protected onClickClose(){
        this.closeAnim()
    }

}