import { soundCfg } from "../common/util";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Audio extends cc.Component {

    @property({type: cc.AudioClip})
    private tickerClip: cc.AudioClip = undefined;

    play(clip: cc.AudioClip, loop = false) {
        if (soundCfg())
            return cc.audioEngine.play(clip, loop, 1);
    }

    stop(id: number) {
        cc.audioEngine.stop(id);
    }

    timeCountDown(){
        this.play(this.tickerClip);
    }
}
