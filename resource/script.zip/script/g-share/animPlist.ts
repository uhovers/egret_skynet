import { AnimName } from "../common/enum";

function PrefixInteger(num, length) {
    return (Array(length).join('0') + num).slice(-length);
}

const {ccclass, property} = cc._decorator;

@ccclass
export default class AnimPlist extends cc.Component {

    @property(cc.SpriteAtlas)
    private spriteAtlas: cc.SpriteAtlas[] = [];

    @property(cc.Animation)
    animSp: cc.Animation = undefined;

    animState: cc.AnimationState = undefined;

    initAnims(){
        for (let i = 0; i < this.spriteAtlas.length; i++) {
            let atlas = this.spriteAtlas[i];
            // cc.log(atlas.name);
            this.creatorAnimation(atlas.getSpriteFrames(), atlas.name)
        }
    }

    /**
     * 创建动画帧
     * @param {*} WrapMode 动画循环模式（单次循环）
     * @param {*} name 动画名字
     */
    private creatorAnimation(frames: cc.SpriteFrame[], name: string){
        // console.log(frames);

        let clip = cc.AnimationClip.createWithSpriteFrames(frames, frames.length);      //创建一组动画剪辑
        clip.wrapMode = cc.WrapMode.Normal;     //设置播放模式
        clip.name = name;       //设置名字
        clip.speed = 0.65
        // clip.duration = 0.05
        // clip.sample = 0.05;
        this.animSp.addClip(clip);       //添加动画帧到动画组件中

        this.animSp.on('finished', this.onFinished, this);
    }

    playAnim(name: string){
        this.animState = this.animSp.play(name);
    }

    getAnim(name: string){
        let clips = this.animSp.getClips();
        let clip: cc.AnimationClip;
        for (let i = 0; i < clips.length; i++) {
            const c = clips[i];
            if (c.name===name) {
                clip = c;
                break;
            }
        }
        return clip;
    }

    private onFinished(event: cc.Event.EventCustom){
        console.log('event: ', event, this.animState.name);
    }

}
