import { CardsPoint } from "../common/enum";

const {ccclass, property} = cc._decorator;

enum TurningState {
    None,
    ToFront,
    ToBack
}

@ccclass
export default class PokerCard extends cc.Component {

    back: cc.Node;
    _front: cc.Node;

    get front(){
        if (!this._front) {
            this._front = this.node.getChildByName('front');
        }
        return this._front;
    }
    private _loaded: boolean;
    private _value: number;
    private _isFaceUp: boolean;
    private _turningState: TurningState;
    private _turningDuration = 0.4;

    get value(){
        return this._value;
    }
    set value(v: number) {
        this._value = v;
    }
    get isFaceUp() {
        return !this.isTurning && this._isFaceUp;
    }
    get isFaceDown() {
        return !this.isTurning && !this._isFaceUp;
    }
    get isTurning() {
        return this._turningState !== TurningState.None;
    }
    get turningDuration() {
        return this._turningDuration;
    }
    private _shouldShowFront: boolean;
    get shouldShowFront() {
        return this._shouldShowFront;
    }
    set shouldShowFront(val) {
        this._shouldShowFront = this._shouldShowFront || val;
    }
    
    /**
     * 卡牌点数
     * @readonly
     * @memberof PokerCard
     */
    get point(){
        return CardsPoint[this._value];
    }

    onLoad () {
        this._front = this.node.getChildByName('front');
        this.back = this.node.getChildByName('back');

        this._loaded = true;
        this.node.emit("loaded");
    }

    turn(toFront=true, doAnim=true, scale=1){
        if (!toFront && this.shouldShowFront) {
            return Promise.resolve();
        }
        if (!this._loaded) {
            this.node.once('loaded', () => {
                this.turn(toFront, doAnim);
            });
            return Promise.resolve();
        }
        let changeScale = scale;
        return new Promise<void>(resolve => {
            this._turningState = toFront ? TurningState.ToFront : TurningState.ToBack;
            if (doAnim) {
                let tweenDuration = this._turningDuration / 2;
                this.node.runAction(cc.sequence(
                    cc.scaleTo(tweenDuration, 0, changeScale),
                    cc.callFunc(() => {
                        this.front.active = toFront;
                        this.back.active = !toFront;
                    }),
                    cc.scaleTo(tweenDuration, changeScale, changeScale),
                    cc.callFunc(() => {
                        this._turningState = TurningState.None;
                        this._isFaceUp = toFront;
                        resolve();
                    })
                ))
            } else {
                this.node.scale = changeScale;
                this.front.active = toFront;
                this.back.active = !toFront;
                this._turningState = TurningState.None;
                this._isFaceUp = toFront;
                resolve();
            }
        });
    }

    stopTurn(){
        this.node.stopAllActions();
    }

    discard(doAnim=true, scale){
        this._shouldShowFront = false;
        return this.turn(false, doAnim, scale)
    }
}
