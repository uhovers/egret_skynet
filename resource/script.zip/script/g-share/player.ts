import Game from "./game";

const {ccclass, property} = cc._decorator;

@ccclass
export default abstract class Player extends cc.Component {

    @property(cc.Label)
    protected lSeat: cc.Label = undefined;

    @property(cc.Sprite)
    protected sAvatar: cc.Sprite = undefined;

    @property(cc.Label)
    protected lName: cc.Label = undefined;

    @property(cc.Label)
    protected lMoney: cc.Label = undefined;

    abstract game: Game;
    seat: number;   // 布局次序

    /**
     *服务器次序
    *
    * @memberof Player
    */
    pos: number; 

    isDealer = false;

    onLoad(){
        
    }

    init(game: Game){
        this.game = game;
        this.setBtn();
    }
    
    public set seatlb(seat : number) {
        this.seat = seat;
        this.isDealer = seat===7
        // if (!this.isDealer) {
        //     this.lSeat.string = ''+seat
        // }
    }
    
    setBtn(){
        let btn = this.node.getComponent(cc.Button)
        if (btn) {
            btn.target = this.node;
            let handler = new cc.Component.EventHandler();
            handler.target = this.node;
            handler.component = cc.js.getClassName(this);
            handler.handler = "onClickPlayer";
            btn.clickEvents.push(handler);
        }
    }

    setBtnInteractable(interactable=true){
        let btn = this.node.getComponent(cc.Button)
        if (btn) {
            btn.interactable = interactable;
        }
    }

    protected onClickPlayer() {
        console.log('seat: '+this.seat);
    }
}
