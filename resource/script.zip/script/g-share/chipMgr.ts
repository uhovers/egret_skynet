const {ccclass, property} = cc._decorator;

let transChipName = function(money: number){
    if (money<100000) {
        return ''+money;
    } else if(money < 1000000) {
        return money/1000+'k';
    }else{
        return money/1000000+'m';
    }
}

@ccclass
export default class ChipMgr extends cc.Component {

    @property(cc.Node)
    private chipBtn: cc.Node = undefined;

    @property(cc.Node)
    private smallChip: cc.Node = undefined;

    @property(cc.Node)
    private res: cc.Node = undefined;

    @property(cc.Node)
    private resIcon: cc.Node = undefined;

    @property(cc.Node)
    private small: cc.Node = undefined;

    private chips = [0.5, 1, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 300000, 500000, 1000000, 2000000, 3000000, 5000000, 10000000, 20000000, 30000000, 50000000, 100000000, 200000000, 300000000, 500000000];

    private chipColor: {[value: number]: string} = {
        0.1: '#1d97d0',
        0.2: '#029b75',
        0.5: '#79b617',
        1: '#c9990a',
        2: '#d93e3d',
        5: '#c428a1',
        10: '#7302b6',
        20: '#4360b8',
        50: '#27ae93',
        100: '#a8b430',
        200: '#d1a622',
        500: '#e05d09'
    }

    getChipBtn(value: number, select?: boolean){
        let chip = cc.instantiate(this.chipBtn)
        chip.getChildByName('frame').getComponent(cc.Sprite).spriteFrame = this.getChipSpByVal(value);
        return chip;
    }

    getChipSpByVal(val: number, isIcon=false){
        let sp: cc.Node;
        if (isIcon) {
            sp = this.resIcon.getChildByName('chip_'+transChipName(val));
        } else {
            sp = this.res.getChildByName('chip_'+transChipName(val));
        }
        if (!sp) {
            cc.warn('查找的筹码不存在：' + val);
            // cc.log(this.chips);
            for (let i = 0; i < this.chips.length; i++) {
                if (this.chips[i]>=val || i===this.chips.length-1) {
                    cc.warn('相近的值val: ', this.chips[i]);
                    let tmp = this.chips[i]
                    if (this.chips[i]!==val) {
                        tmp = this.chips[i-1] ? this.chips[i-1] : tmp
                    }
                    cc.log('name: ', 'chip_'+transChipName(tmp));
                    if (isIcon) {
                        sp = this.resIcon.getChildByName('chip_'+transChipName(tmp));
                    } else {
                        sp = this.res.getChildByName('chip_'+transChipName(tmp));
                    }
                    break;
                }
            }
        }
        return sp.getComponent(cc.Sprite).spriteFrame;
    }

    getSmallChip(val: number){
        let chip = cc.instantiate(this.smallChip);
        chip.getComponent(cc.Sprite).spriteFrame = this.getSmallSpByVal(val);
        return chip;
    }

    getSmallSpByVal(val: number){
        let sp = this.small.getChildByName('small_chip_'+transChipName(val));
        if (sp) {
            return sp.getComponent(cc.Sprite).spriteFrame;
        }
        return undefined;
    }

    /**
     * 转换筹码
     * @param num 
     */
    transChips(num: number) {
        let totalNum = num;
        let list = [];
        if (totalNum <= 0) return list;
        
        let idx = this.chips.length-1
        let curNum = totalNum
        while (curNum>0 && idx>=0) {
            if (curNum>=this.chips[idx]) {
                let count = Math.floor(curNum/this.chips[idx]);
                for (let i = 0; i < count; i++) {
                list.push(this.chips[idx]);
                }
                curNum = curNum%this.chips[idx];
            }else{
                if (list.length===0 && curNum<0.5) {
                    list.push(0.5);
                    curNum = 0;
                    break;
                }
            }
            idx--;
        }
        return list;
    }
}
