import PokerCard from "./pokerCard";

const {ccclass, property} = cc._decorator;

@ccclass
export default class PokerMgr extends cc.Component {

    @property(cc.Node)
    private resources: cc.Node = undefined;

    @property(cc.Node)
    private poker: cc.Node = undefined;

    start () {
        this.resources.active = false;
    }

    private getBack(){
        let base = cc.instantiate(this.poker);
        base.getChildByName('front').active = false;
        base.getChildByName('back').active = true;
        return base;
    }

    private updateCard(card: cc.Node, key: number){
        let baseFront = card.getChildByName('front');
        let baseBack = card.getChildByName('back');

        let isFace = key!==99;
        baseFront.active = isFace;
        baseBack.active = !isFace;
        if (!isFace) return;

        baseFront.getComponent(cc.Sprite).spriteFrame = this.getSpByKey(key);
    }

    private getCard(key: number){
        if (key===99) {
            return this.getBack();
        }
        let base = cc.instantiate(this.poker)
        this.updateCard(base, key);
        return base;
    }

    private setCard(card: cc.Node, key: number){
        if(!card) return;

        this.updateCard(card, key);
    }

    setPokerValue(key: number, isLook?: boolean, callBack?: Function, isAnim=true){
        let pokerKey = this.poker.getChildByName('key')
        let pokerBack = this.poker.getChildByName('back');
        pokerBack.active = true;
        if (!isLook) {
            // if (callBack) callBack();
            return
        }
        if (!isAnim) {
            pokerBack.active = false;
            pokerKey.active = true;
            pokerKey.getComponent(cc.Sprite).spriteFrame = this.getSpByKey(key);
            if (callBack) callBack();
            return
        }

        this.poker.is3DNode = true;
        let t = cc.tween;
        t(this.poker)
        .delay(0)
        .to(0.2, {eulerAngles: cc.v3(0, 90, 0)})
        .call(()=>{
            pokerBack.active = false;
            pokerKey.active = true;
            pokerKey.getComponent(cc.Sprite).spriteFrame = this.getSpByKey(key);
        })
        .call(()=>{
            if (callBack) {
                callBack();
            }
        })
        .to(0.2, {eulerAngles: cc.v3(0, 0, 0)})
        .start()
    }

    overCards(callBack?: Function){
        let pokerKey = this.poker.getChildByName('key')
        let pokerBack = this.poker.getChildByName('back');
        
        this.poker.is3DNode = true;
        let t = cc.tween;
        t(this.poker)
        .delay(0)
        .to(0.2, {eulerAngles: cc.v3(0, 90, 0)})
        .call(()=>{
            pokerBack.active = true;
            pokerKey.active = false;
        })
        .call(()=>{
            if (callBack) {
                callBack();
            }
        })
        .to(0.1, {eulerAngles: cc.v3(0, 0, 0)})
        .start()
    }

    getSpByKey(key: number){
        return this.resources.getChildByName('blackjack_card_'+key).getComponent(cc.Sprite).spriteFrame;
    }

    getPoker(data: number){
        let node = this.getCard(data);
        node.getComponent(PokerCard).value = data;
        return node;
    }

    setPoker(card: cc.Node, data: number){
        this.setCard(card, data);
        card.getComponent(PokerCard).value = data;
    }

}
