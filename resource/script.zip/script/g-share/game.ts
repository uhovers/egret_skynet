import PlayerMgr from "./playerMgr";
import Player from "./player";
import GameEvent from "./gameEvent";

const {ccclass, property} = cc._decorator;

@ccclass
export default abstract class Game extends cc.Component {

    @property(cc.Node)
    public nodeCanvas: cc.Node = undefined;

    @property({type: PlayerMgr})
    abstract playerMgr: PlayerMgr<Player, Game> = undefined;

    start () {

    }

    // update (dt) {}
}
