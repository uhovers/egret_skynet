import { DevStatus, SAVEKEY } from "./common/enum";
import { SERVER_NODE } from "./common/cfg";
import { getItem, setItem } from "./common/Helper";

export interface LoginConfig {
    channelId: number,
    subchannelId: number,
    userId: number,
    token: string,
    wallet: string,
    lang?: string,
    isSingleGame?: number,
    logo?: string,
    logoUrl?: string
};

class GlobalVal {

    // 修改当前开发状态；
    _dev = DevStatus.LOCAL_DEV;

    /** 版本号 */
    hotVer: string = "1.1.36";

    /** 默认语言 */
    defaultLang = "en_us";

    private _language = "en_us";
    
    set language(v : string) {
        this._language = v;
    }

    get language(){
        return this._language;
    }

    private _thirdCfg: LoginConfig = undefined;

    set thirdConfig(cfg: LoginConfig) {
        this._thirdCfg = cfg;
    }

    get thirdConfig(){
        return this._thirdCfg;
    }

    get udid() : number {
        // let _udid = getItem(SAVEKEY.DEVICEONLY, '')
        // _udid = _udid.length>0 ? _udid : this.getDeviceOnlyID();
        let _udid = this.thirdConfig.userId;
        return _udid;
    }

    private _udid: string
    /** 获取udid */
    private getDeviceOnlyID() {
        if (!this._udid) {
            this._udid = this.getNewUUID();
            setItem(SAVEKEY.DEVICEONLY, this._udid);
        }
        return this._udid;
    }

    private getNewUUID(): string {
        let d = Date.now()
        let uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
            let r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === "x" ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    }
    
    get gameServers() {
        let serverCfg = window._ServerCfg
        // cc.log('serverCfg: ', serverCfg);
        if (serverCfg && serverCfg.server && serverCfg.server.length>0) {
            return serverCfg.server;
        }
        return SERVER_NODE[this._dev];
    }

    /**
     *是否为开发模式
     */
    get isDev() {
        return this._dev!==DevStatus.OFFICIAL;
    }

    errorMsg: string;

    curBetLimit: number = 0;
    
    get version() {
        return {
            platform: 2,
            channel: this.thirdConfig.channelId,
            version: this.hotVer,
            authtype: 1,
            regfrom: 1,
        }
    }

    /** 是否横屏 */
    isLandscape: boolean = false;

    START_SCENE = 'start';
    LOBBY_SCENE = 'lobby';
    GAME_SCENE = 'game';
    
    setScene(){
        this.START_SCENE = this.isLandscape ? 'start_landscape' : 'start';
        this.LOBBY_SCENE = this.isLandscape ? 'lobby_landscape' : 'lobby';
        this.GAME_SCENE = this.isLandscape ? 'game_landscape' : 'game';
    }

    postBackToLobby(){
        cc.assetManager.releaseAll();

        parent.postMessage({
            msg: "backToLobby"
        }, "*");
    }

    postEnterRoom(){
        parent.postMessage({
            msg: "enterRoom"
        }, "*");
    }

    postLeaveRoom(){
        parent.postMessage({
            msg: "leaveRoom"
        }, "*");
    }
}

export default new GlobalVal();